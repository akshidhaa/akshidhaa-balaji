import { useState, useEffect } from 'react'
import axios from 'axios'

export default function NeighborhoodChallenges({ countryId }) {
    const [challenges, setChallenges] = useState([])

    useEffect(() => {
        if (!countryId) return;
        axios.get(`/api/neighborhood-challenges?country=${countryId}`)
            .then(res => setChallenges(res.data))
            .catch(err => console.error(err))
    }, [countryId])

    return (
        <div className="widget-panel">
            <h3>🏘️ Neighborhood Challenges</h3>
            <p className="subtitle">Compete with local groups!</p>

            <div className="leaderboard-list" style={{ marginTop: '10px' }}>
                {challenges.map((c, i) => (
                    <div key={c.id} style={{
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                        padding: '12px', borderBottom: '1px solid var(--border-color)',
                        background: i === 0 ? 'var(--accent-soft)' : 'transparent',
                        borderRadius: '8px',
                        marginBottom: '4px'
                    }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                            <span style={{ fontWeight: '800', color: i === 0 ? 'var(--accent)' : 'var(--text-secondary)', fontSize: '1.1rem' }}>#{c.rank}</span>
                            <div>
                                <div style={{ fontWeight: '700', color: 'var(--text-primary)' }}>{c.name}</div>
                                <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{c.action}</div>
                            </div>
                        </div>
                        <div style={{ fontWeight: '800', color: 'var(--accent)' }}>{c.score} pts</div>
                    </div>
                ))}
            </div>


        </div>
    )
}
