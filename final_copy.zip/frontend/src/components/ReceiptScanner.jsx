import { useState } from 'react'
import axios from 'axios'
import { Bar } from 'react-chartjs-2'
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend
);

export default function ReceiptScanner() {
    const [analyzing, setAnalyzing] = useState(false)
    const [result, setResult] = useState(null)

    const handleFileUpload = (e) => {
        const file = e.target.files[0]
        if (!file) return

        setAnalyzing(true)
        setResult(null)

        const formData = new FormData()
        formData.append('file', file)

        axios.post('/api/scan-receipt', formData, {
            headers: { 'Content-Type': 'multipart/form-data' }
        })
            .then(res => {
                setResult(res.data)
                setAnalyzing(false)
            })
            .catch(err => {
                console.error("Full Error Object:", err)
                setAnalyzing(false)

                let debugMsg = "Failed to analyze receipt.\n"
                if (err.response) {
                    debugMsg += `Status: ${err.response.status}\n`
                    debugMsg += `Data: ${JSON.stringify(err.response.data)}\n`
                } else if (err.request) {
                    debugMsg += "No response received from server (Network Error?)\n"
                } else {
                    debugMsg += `Error: ${err.message}\n`
                }

                const friendlyMsg = err.response?.data?.suggestion || err.response?.data?.error
                alert(friendlyMsg ? `Error: ${friendlyMsg}` : debugMsg)
            })
    }

    const chartData = result ? {
        labels: ['Carbon (kg)', 'Water (L)'],
        datasets: [{
            label: 'Footprint',
            data: [result.carbon_footprint_kg, result.water_footprint_liters],
            backgroundColor: ['#e74c3c', '#3498db']
        }]
    } : null

    return (
        <div className="widget-panel">
            <h3>🧾 AI Receipt Scanner</h3>
            {!result ? (
                <div style={{ textAlign: 'center', padding: '2.5rem 1rem', border: '2px dashed var(--border-color)', borderRadius: '16px', background: 'var(--bg-color)' }}>
                    <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        style={{ display: 'none' }}
                        id="receipt-upload"
                    />
                    <label htmlFor="receipt-upload" className="btn-upload" style={{ cursor: 'pointer', display: 'inline-block', background: 'var(--accent)', color: 'white', padding: '10px 20px', borderRadius: '30px', fontWeight: 'bold', boxShadow: '0 4px 15px var(--accent-soft)' }}>
                        {analyzing ? '🔍 Analyzing...' : '📸 Snap Receipt'}
                    </label>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '15px', fontWeight: '500' }}>
                        Gemini AI will analyze items and carbon impact.
                    </p>
                </div>
            ) : (
                <div className="scan-results">
                    <div className="badge-result" style={{
                        background: result.eco_score === 'High' ? '#e74c3c' : result.eco_score === 'Moderate' ? '#f1c40f' : '#2ecc71',
                        color: 'white', padding: '5px 10px', borderRadius: '4px', textAlign: 'center', marginBottom: '10px'
                    }}>
                        Eco-Impact: {result.eco_score}
                    </div>

                    <p><strong>Detected:</strong> {result.items_detected.join(", ")}</p>

                    <div style={{ height: '150px', marginBottom: '10px' }}>
                        <Bar options={{ maintainAspectRatio: false }} data={chartData} />
                    </div>

                    <div className="tip-box">
                        💡 <strong>Suggestion:</strong> {result.suggestion}
                    </div>

                    <button onClick={() => setResult(null)} style={{ marginTop: '10px', width: '100%', padding: '8px' }}>
                        Scan Another
                    </button>
                </div>
            )}
        </div>
    )
}
