import { LayoutDashboard, Zap, Activity, Trophy, Globe, MessageSquare, TrendingUp, Sparkles } from 'lucide-react'
import ActionLog from './ActionLog'
import ImpactStats from './ImpactStats'
import EcoTipsCarousel from './EcoTipsCarousel'
import StreakBadges from './StreakBadges'
import CountriesWidget from './CountriesWidget'
import Leaderboard from './Leaderboard'
import Coach from './Coach'
import SustainabilityQuiz from './SustainabilityQuiz'

export default function Dashboard({ dashboardData, aiSummary, selectedCountryId, setSelectedCountryId }) {
    return (
        <div className="fade-in">
            {/* AI Premium Header */}
            <div className="ai-header-premium">
                <div style={{ background: 'var(--accent)', padding: '1rem', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Sparkles size={32} color="white" />
                </div>
                <div>
                    <div className="ai-insight-badge">
                        <Activity size={12} />
                        Live Eco-Analysis
                    </div>
                    <h1 style={{ color: 'white', margin: 0, fontSize: '2rem' }}>Personal Impact Dashboard</h1>
                    <p style={{ color: 'rgba(255,255,255,0.7)', margin: 0 }}>
                        Intelligent sustainability tracking powered by Gemini 3 Flash.
                    </p>
                </div>
            </div>

            <div className="bento-grid">
                {/* Main Content Area (Column 1-8) */}
                <div className="bento-col-8" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

                    {/* Top Row of Stats */}
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '1.5rem' }}>
                        <ImpactStats stats={dashboardData?.impact_stats} aiInsight={aiSummary?.impact_insight} />
                        <EcoTipsCarousel tips={dashboardData?.tips} aiInsight={aiSummary?.coach_tip} />
                    </div>

                    {/* Action Logging Section */}
                    <div className="premium-card" style={{ padding: 0 }}>
                        <div style={{ padding: '1.5rem', borderBottom: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', gap: '12px' }}>
                            <Zap size={20} className="text-accent" />
                            <h3 style={{ margin: 0 }}>Sustainability Log</h3>
                        </div>
                        <ActionLog aiInsight={aiSummary?.action_insight} />
                    </div>

                    {/* Achievements */}
                    <StreakBadges badges={dashboardData?.badges} aiInsight={aiSummary?.achievement_insight} />

                    {/* Daily Eco Quiz */}
                    <SustainabilityQuiz />
                </div>

                {/* Sidebar Area (Column 9-12) */}
                <div className="bento-col-4" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

                    {/* Region Selector */}
                    <div className="premium-card">
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '1.5rem' }}>
                            <Globe size={20} color="var(--accent)" />
                            <h3 style={{ margin: 0 }}>Region Focus</h3>
                        </div>
                        <CountriesWidget
                            selectedCountryId={selectedCountryId}
                            setSelectedCountryId={setSelectedCountryId}
                            aiInsight={aiSummary?.live_status_insight}
                        />
                    </div>

                    {/* Competitive Leaderboard */}
                    <div className="premium-card">
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '1.5rem' }}>
                            <Trophy size={20} color="#f59e0b" />
                            <h3 style={{ margin: 0 }}>Leaderboard</h3>
                        </div>
                        <Leaderboard aiInsight={aiSummary?.leaderboard_insight} />
                    </div>

                    {/* AI Coach Mini */}
                    <div className="premium-card" style={{ padding: 0, flex: 1, display: 'flex', flexDirection: 'column' }}>
                        <div style={{ padding: '1.5rem', borderBottom: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', gap: '10px' }}>
                            <MessageSquare size={20} color="var(--accent)" />
                            <h3 style={{ margin: 0 }}>Eco-Coach</h3>
                        </div>
                        <div style={{ padding: '1rem', flex: 1, display: 'flex', flexDirection: 'column' }}>
                            <Coach />
                        </div>
                    </div>
                </div>
            </div>

            <style dangerouslySetInnerHTML={{
                __html: `
                .text-accent { color: var(--accent); }
                .dashboard-layout { display: block; } /* Override old layout */
            `}} />
        </div>
    )
}
