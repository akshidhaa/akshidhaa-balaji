import { useState, useEffect } from 'react'
import { Lightbulb, MessageCircle } from 'lucide-react'

export default function EcoTipsCarousel({ tips, aiInsight }) {
    const [currentIndex, setCurrentIndex] = useState(0)

    useEffect(() => {
        if (!tips || tips.length === 0) return;
        const interval = setInterval(() => {
            setCurrentIndex((prev) => (prev + 1) % tips.length)
        }, 5000)
        return () => clearInterval(interval)
    }, [tips])

    if (!tips || tips.length === 0) return null;

    return (
        <div className="premium-card fade-in" style={{
            background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            color: 'white',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            border: 'none'
        }}>
            <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '1.25rem' }}>
                    <Lightbulb size={20} color="white" />
                    <h3 style={{ margin: 0, color: 'white', fontSize: '1.1rem' }}>Daily Eco Tip</h3>
                </div>

                <div style={{
                    minHeight: '80px',
                    display: 'flex',
                    alignItems: 'center',
                    fontSize: '1.15rem',
                    fontWeight: '600',
                    lineHeight: '1.5',
                    textAlign: 'left'
                }}>
                    "{tips[currentIndex]}"
                </div>

                <div style={{ display: 'flex', gap: '6px', marginTop: '1.5rem', justifyContent: 'flex-start' }}>
                    {tips.map((_, idx) => (
                        <div key={idx} style={{
                            width: idx === currentIndex ? '24px' : '6px',
                            height: '6px',
                            borderRadius: '10px',
                            background: idx === currentIndex ? 'white' : 'rgba(255,255,255,0.3)',
                            transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)'
                        }}></div>
                    ))}
                </div>
            </div>

            {aiInsight && (
                <div style={{
                    marginTop: '2rem',
                    padding: '1rem',
                    background: 'rgba(255,255,255,0.15)',
                    backdropFilter: 'blur(4px)',
                    borderRadius: '12px',
                    fontSize: '0.85rem',
                    border: '1px solid rgba(255,255,255,0.2)',
                    display: 'flex',
                    gap: '10px'
                }}>
                    <MessageCircle size={16} style={{ flexShrink: 0, marginTop: '2px' }} />
                    <div>
                        <span style={{ fontWeight: '800', display: 'block', marginBottom: '4px', fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>AI Coach Suggestion</span>
                        {aiInsight}
                    </div>
                </div>
            )}
        </div>
    )
}
