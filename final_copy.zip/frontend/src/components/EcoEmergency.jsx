import { useState, useEffect } from 'react'
import axios from 'axios'

export default function EcoEmergency({ countryId }) {
    const [reporting, setReporting] = useState(false)
    const [reportForm, setReportForm] = useState({ name: '', group: '', details: '' })
    const [submitted, setSubmitted] = useState(false)
    const [emergencyData, setEmergencyData] = useState(null)

    useEffect(() => {
        if (!countryId) return;
        axios.get(`/api/eco-emergency?country=${countryId}`)
            .then(res => setEmergencyData(res.data))
            .catch(err => console.error(err))
    }, [countryId])

    const handleSubmit = (e) => {
        e.preventDefault()
        // Simulate API call
        console.log("Reporting Emergency:", reportForm)
        setSubmitted(true)
        setTimeout(() => {
            setSubmitted(false)
            setReporting(false)
            setReportForm({ name: '', group: '', details: '' })
        }, 3000)
    }

    if (!emergencyData) return null

    if (reporting) {
        return (
            <div className="widget-panel emergency-panel">
                <h3>🚨 Report Emergency</h3>
                {submitted ? (
                    <div style={{ padding: '20px', textAlign: 'center', color: '#27ae60' }}>
                        <div style={{ fontSize: '2rem' }}>✅</div>
                        <p>Report sent to authorities!</p>
                    </div>
                ) : (
                    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                        <input
                            type="text"
                            placeholder="Your Name"
                            required
                            value={reportForm.name}
                            onChange={e => setReportForm({ ...reportForm, name: e.target.value })}
                        />
                        <input
                            type="text"
                            placeholder="Local Group"
                            value={reportForm.group}
                            onChange={e => setReportForm({ ...reportForm, group: e.target.value })}
                        />
                        <textarea
                            placeholder="Emergency Details..."
                            required
                            rows="3"
                            value={reportForm.details}
                            onChange={e => setReportForm({ ...reportForm, details: e.target.value })}
                            style={{
                                width: '100%', padding: '10px', borderRadius: '8px',
                                border: '1px solid var(--border-color)', background: 'var(--card-bg)',
                                color: 'var(--text-primary)', fontFamily: 'inherit'
                            }}
                        ></textarea>
                        <div style={{ display: 'flex', gap: '10px' }}>
                            <button type="button" onClick={() => setReporting(false)} style={{ flex: 1, padding: '10px', background: 'var(--bg-color)', color: 'var(--text-primary)', border: '1px solid var(--border-color)', borderRadius: '8px', cursor: 'pointer', fontWeight: '600' }}>Cancel</button>
                            <button type="submit" style={{ flex: 1, padding: '10px', background: '#e74c3c', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', boxShadow: '0 4px 15px rgba(231, 76, 60, 0.3)' }}>SEND SOS</button>
                        </div>
                    </form>
                )}
            </div>
        )
    }

    return (
        <div className="widget-panel emergency-panel">
            <h3>🚨 Eco Emergency Mode</h3>

            {emergencyData.type && (
                <div style={{
                    background: '#e74c3c', color: 'white', padding: '10px',
                    borderRadius: '6px', marginBottom: '10px', textAlign: 'center', fontWeight: 'bold'
                }}>
                    ⚠️ {emergencyData.type} - {emergencyData.severity} Severity
                </div>
            )}

            <div className="safety-tips">
                <strong>🛡️ Survival Tips:</strong>
                <ul style={{ paddingLeft: '1.2rem', marginTop: '5px', fontSize: '0.9rem' }}>
                    {emergencyData.tips && emergencyData.tips.map((tip, i) => (
                        <li key={i} style={{ marginBottom: '5px' }}>{tip}</li>
                    ))}
                </ul>
            </div>

            <div className="status-meter" style={{ marginTop: '15px', textAlign: 'center' }}>
                <div style={{ fontSize: '0.7rem', fontWeight: '800', color: 'var(--text-secondary)', marginBottom: '8px', letterSpacing: '0.05em' }}>REGIONAL SAFETY STATUS</div>
                <div className="meter-bar" style={{ height: '12px', background: 'var(--border-color)', borderRadius: '6px', overflow: 'hidden' }}>
                    <div style={{ width: '75%', height: '100%', background: 'linear-gradient(90deg, #e74c3c 0%, #f1c40f 100%)' }}></div>
                    {/* Visual only for now */}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', marginTop: '2px' }}>
                    <span>Safe</span>
                    <span>Hazardous</span>
                </div>
            </div>

            <button
                onClick={() => setReporting(true)}
                style={{ marginTop: '15px', background: '#c0392b', color: 'white', width: '100%', padding: '10px', border: 'none', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' }}
            >
                Report Emergency
            </button>
        </div>
    )
}
