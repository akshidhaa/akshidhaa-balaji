import { useState, useEffect } from 'react'
import axios from 'axios'
import SDGList from './SDGList'
import LiveMeter from './LiveMeter'
import ChartsContainer from './ChartsContainer'
import { Search, Globe, MapPin, Award, ArrowLeft } from 'lucide-react'

export default function CountryProfileWidget() {
    const [activeTab, setActiveTab] = useState('overview')
    const [view, setView] = useState('list')
    const [countries, setCountries] = useState([])
    const [selectedCountryId, setSelectedCountryId] = useState(null)
    const [countryDetail, setCountryDetail] = useState(null)
    const [loading, setLoading] = useState(true)
    const [searchTerm, setSearchTerm] = useState('')

    const REGIONAL_LEADERS = {
        'BTN': 'Asia',
        'SUR': 'Americas',
        'GRL': 'Americas',
        'SWE': 'Europe',
        'GAB': 'Africa',
        'NZL': 'Oceania'
    };

    // Fetch List
    useEffect(() => {
        axios.get('/api/countries')
            .then(res => {
                setCountries(res.data)
                setLoading(false)
            })
            .catch(err => {
                console.error(err)
                setLoading(false)
            })
    }, [])

    // Fetch Detail
    useEffect(() => {
        if (selectedCountryId) {
            setLoading(true)
            axios.get(`/api/country-profile/${selectedCountryId}`)
                .then(res => {
                    setCountryDetail(res.data)
                    setLoading(false)
                    setView('detail')
                })
                .catch(err => {
                    console.error(err)
                    setLoading(false)
                })
        }
    }, [selectedCountryId])

    const filteredCountries = countries.filter(c =>
        c.name.toLowerCase().includes(searchTerm.toLowerCase())
    )

    if (view === 'list') {
        return (
            <div className="fade-in" style={{ position: 'relative' }}>
                {/* Visual Background Decoration */}
                <div style={{
                    position: 'absolute', top: '-10%', right: '-5%', width: '300px', height: '300px',
                    background: 'var(--accent)', opacity: 0.05, filter: 'blur(100px)', borderRadius: '50%', zIndex: -1
                }}></div>
                <div style={{
                    position: 'absolute', bottom: '10%', left: '-5%', width: '400px', height: '400px',
                    background: '#3b82f6', opacity: 0.05, filter: 'blur(100px)', borderRadius: '50%', zIndex: -1
                }}></div>

                <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
                    <div className="ai-insight-badge">
                        <Globe size={14} />
                        Global Intelligence
                    </div>
                    <h2 style={{ fontSize: '2.5rem', fontWeight: '800', color: 'var(--text-primary)', marginBottom: '1rem', letterSpacing: '-0.02em' }}>
                        Global Sustainability Profiles
                    </h2>
                    <p style={{ color: 'var(--text-secondary)', maxWidth: '600px', margin: '0 auto' }}>
                        Explore real-time environmental performance and SDG implementation progress across 200+ nations.
                    </p>
                </div>

                {/* Search */}
                <div style={{
                    maxWidth: '600px',
                    margin: '0 auto 3rem auto',
                    display: 'flex',
                    alignItems: 'center',
                    background: 'var(--card-bg)',
                    padding: '12px 24px',
                    borderRadius: '99px',
                    boxShadow: 'var(--shadow-md)',
                    border: '1px solid var(--border-color)',
                    transition: 'var(--transition)'
                }}>
                    <Search size={20} color="var(--text-secondary)" />
                    <input
                        type="text"
                        placeholder="Search for a country..."
                        style={{ border: 'none', background: 'transparent', marginLeft: '12px', fontSize: '1rem', width: '100%', outline: 'none', color: 'var(--text-primary)' }}
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>

                {loading ? (
                    <div style={{ textAlign: 'center', padding: '5rem', color: 'var(--text-secondary)' }}>
                        <div className="loading-spinner"></div>
                        Gathering satellite intelligence...
                    </div>
                ) : (
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1.5rem' }}>
                        {filteredCountries.map((country, idx) => (
                            <div
                                key={country.id}
                                onClick={() => setSelectedCountryId(country.id)}
                                className="premium-card"
                                style={{
                                    cursor: 'pointer',
                                    textAlign: 'left',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    gap: '12px',
                                    borderTop: `4px solid ${['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6', '#ef4444'][idx % 5]}`
                                }}
                            >
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                                    <img
                                        src={country.flag}
                                        alt={country.name}
                                        style={{ width: '48px', height: '32px', objectFit: 'cover', borderRadius: '4px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}
                                    />
                                    <div style={{
                                        padding: '4px 10px',
                                        background: 'var(--accent-soft)',
                                        borderRadius: '8px',
                                        fontSize: '0.7rem',
                                        fontWeight: '800',
                                        color: 'var(--accent)'
                                    }}>
                                        SCORE: {country.score}
                                    </div>
                                </div>

                                <div>
                                    <h3 style={{ fontSize: '1.25rem', fontWeight: '800', color: 'var(--text-primary)', margin: '0 0 4px 0' }}>{country.name}</h3>
                                    {REGIONAL_LEADERS[country.id] ? (
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--accent)', fontSize: '0.8rem', fontWeight: '700' }}>
                                            <Award size={12} />
                                            {REGIONAL_LEADERS[country.id]} Leader
                                        </div>
                                    ) : (
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-secondary)', fontSize: '0.8rem' }}>
                                            <MapPin size={12} />
                                            {country.region || 'Global'} Region
                                        </div>
                                    )}
                                </div>

                                <div style={{
                                    marginTop: 'auto',
                                    paddingTop: '12px',
                                    borderTop: '1px solid var(--border-color)',
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'center'
                                }}>
                                    <span style={{ fontSize: '0.75rem', fontWeight: '600', color: 'var(--text-secondary)' }}>View Detailed Report</span>
                                    <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: 'var(--accent-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)' }}>
                                        →
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        )
    }

    // DETAIL VIEW
    return (
        <div className="fade-in" style={{ paddingBottom: '5rem' }}>
            <button
                onClick={() => { setView('list'); setSelectedCountryId(null); setCountryDetail(null); setActiveTab('overview'); }}
                style={{
                    marginBottom: '2rem',
                    background: 'var(--bg-color)',
                    border: '1px solid var(--border-color)',
                    padding: '8px 16px',
                    borderRadius: '12px',
                    cursor: 'pointer',
                    fontSize: '0.9rem',
                    color: 'var(--text-primary)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontWeight: '600',
                    transition: 'var(--transition)'
                }}
            >
                <ArrowLeft size={16} /> Back to Network
            </button>

            {loading || !countryDetail ? (
                <div style={{ textAlign: 'center', padding: '5rem', color: 'var(--text-secondary)' }}>Analyzing nation data...</div>
            ) : (
                <div className="profile-content">
                    {/* Header: Flag & Title */}
                    <div className="premium-card" style={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        alignItems: 'center',
                        gap: '2.5rem',
                        marginBottom: '2rem',
                        background: 'var(--ai-header-bg)',
                        border: 'none',
                        color: 'white'
                    }}>
                        <img
                            src={countryDetail.flag_url}
                            alt={countryDetail.name}
                            style={{ width: '180px', borderRadius: '12px', boxShadow: 'var(--shadow-lg)', border: '4px solid rgba(255,255,255,0.1)' }}
                        />
                        <div style={{ flex: 1 }}>
                            <div className="ai-insight-badge" style={{ background: 'rgba(255,255,255,0.1)', color: 'white' }}>
                                {REGIONAL_LEADERS[countryDetail.id] ? <Award size={12} /> : <MapPin size={12} />}
                                {REGIONAL_LEADERS[countryDetail.id] ? `${REGIONAL_LEADERS[countryDetail.id]} Leader` : `${countryDetail.region || 'Global'} Profile`}
                            </div>
                            <h1 style={{ fontSize: '3.5rem', fontWeight: '800', margin: '0 0 12px 0', letterSpacing: '-0.03em', color: 'white' }}>{countryDetail.name}</h1>
                            <div style={{ display: 'flex', gap: '15px' }}>
                                <div style={{ background: 'rgba(255,255,255,0.1)', padding: '8px 16px', borderRadius: '12px', fontSize: '0.85rem' }}>
                                    Global Rank: <strong style={{ color: 'var(--accent)' }}>#{countryDetail.rank}</strong>
                                </div>
                                <div style={{ background: 'rgba(255,255,255,0.1)', padding: '8px 16px', borderRadius: '12px', fontSize: '0.85rem' }}>
                                    Eco-Score: <strong style={{ color: 'var(--accent)' }}>{countryDetail.score}</strong>
                                </div>
                            </div>
                        </div>
                        <div style={{ flexShrink: 0, width: '100%', maxWidth: '300px' }}>
                            <LiveMeter status={countryDetail.live_meter.status} score={countryDetail.live_meter.score} />
                        </div>
                    </div>

                    {/* Tab Navigation */}
                    <div style={{ display: 'flex', gap: '8px', marginBottom: '2rem', background: 'var(--card-bg)', padding: '6px', borderRadius: '14px', border: '1px solid var(--border-color)', width: 'fit-content' }}>
                        {['overview', 'indicators'].map(tab => (
                            <button
                                key={tab}
                                onClick={() => setActiveTab(tab)}
                                style={{
                                    background: activeTab === tab ? 'var(--accent)' : 'transparent',
                                    border: 'none',
                                    padding: '10px 24px',
                                    fontSize: '0.9rem',
                                    fontWeight: '700',
                                    cursor: 'pointer',
                                    color: activeTab === tab ? 'white' : 'var(--text-secondary)',
                                    borderRadius: '10px',
                                    transition: 'var(--transition)',
                                    textTransform: 'capitalize'
                                }}
                            >
                                {tab}
                            </button>
                        ))}
                    </div>

                    {/* TAB CONTENT: OVERVIEW */}
                    {activeTab === 'overview' && (
                        <div className="fade-in">
                            <div className="premium-card" style={{ marginBottom: '2rem' }}>
                                <h3 style={{ fontSize: '1.5rem', fontWeight: '800', marginBottom: '1rem', color: 'var(--text-primary)' }}>Executive Summary</h3>
                                <p style={{ fontSize: '1.1rem', color: 'var(--text-secondary)', lineHeight: '1.8' }}>{countryDetail.description}</p>
                            </div>

                            {/* Stats Row */}
                            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.5rem', marginBottom: '3rem' }}>
                                <StatCard label="Sustainability Score" value={countryDetail.score} color="#10b981" />
                                <StatCard label="International Standing" value={`Rank #${countryDetail.rank}`} color="#8b5cf6" />
                                <StatCard label="Spillover Impact" value="72.0" color="#f59e0b" />
                                <StatCard label="Network Performance" value="85.1%" color="#3b82f6" />
                            </div>

                            {/* Visualizations */}
                            <div className="premium-card">
                                <h3 style={{ fontSize: '1.5rem', fontWeight: '800', marginBottom: '2rem', color: 'var(--text-primary)' }}>Impact Visualizations</h3>
                                <ChartsContainer data={countryDetail.charts} />
                            </div>
                        </div>
                    )}

                    {/* TAB CONTENT: INDICATORS */}
                    {activeTab === 'indicators' && (
                        <div className="fade-in">
                            <div className="premium-card">
                                <h3 style={{ fontSize: '1.5rem', fontWeight: '800', marginBottom: '1rem', color: 'var(--text-primary)' }}>SDG Matrix & Trajectory</h3>
                                <p style={{ color: 'var(--text-secondary)', marginBottom: '2rem' }}>
                                    Deep-dive analysis into the 17 Sustainable Development Goals. Each indicator reflects real-world policy outcomes and community efforts.
                                </p>
                                <SDGList sdgs={countryDetail.sdg_performance} />
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    )
}

function StatCard({ label, value, color }) {
    return (
        <div className="premium-card" style={{ borderLeft: `6px solid ${color}` }}>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '8px', fontWeight: '800', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</div>
            <div style={{ fontSize: '2.5rem', fontWeight: '800', color: 'var(--text-primary)', lineHeight: '1' }}>{value}</div>
        </div>
    )
}
