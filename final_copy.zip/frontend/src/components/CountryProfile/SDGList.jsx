import { useState } from 'react';

const statusColors = {
    "SDG Achieved": "#28a745",
    "Challenges Remain": "#ffc107",
    "Significant Challenges": "#fd7e14",
    "Major Challenges": "#dc3545",
    "Regression": "#000000",
    "Information Unavailable": "#6c757d"
};

export default function SDGList({ sdgs }) {
    const [expandedSdg, setExpandedSdg] = useState(null);

    const toggleExpand = (id) => {
        setExpandedSdg(expandedSdg === id ? null : id);
    };

    return (
        <div className="sdg-list-container">
            {sdgs.map((sdg) => (
                <div key={sdg.id} style={{ marginBottom: '20px', background: 'var(--card-bg)', borderRadius: '15px', boxShadow: 'var(--shadow-sm)', border: '1px solid var(--border-color)', overflow: 'hidden' }}>
                    {/* Header Row */}
                    <div
                        onClick={() => toggleExpand(sdg.id)}
                        style={{
                            padding: '20px',
                            display: 'flex',
                            alignItems: 'center',
                            cursor: 'pointer',
                            justifyContent: 'space-between',
                            background: expandedSdg === sdg.id ? 'var(--accent-soft)' : 'transparent',
                            transition: 'background 0.3s'
                        }}
                    >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
                            <div style={{
                                width: '50px',
                                height: '50px',
                                background: sdg.color,
                                color: 'white',
                                borderRadius: '10px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontWeight: 'bold',
                                fontSize: '1.2rem'
                            }}>
                                {sdg.id}
                            </div>
                            <div>
                                <h4 style={{ margin: 0, fontSize: '1.1rem', color: 'var(--text-primary)' }}>{sdg.title}</h4>
                                <span style={{ fontSize: '0.9rem', color: sdg.color, fontWeight: '700' }}>{sdg.status}</span>
                            </div>
                        </div>
                        <div style={{ color: 'var(--text-secondary)' }}>
                            {expandedSdg === sdg.id ? '▲' : '▼'}
                        </div>
                    </div>

                    {/* Detailed Indicators */}
                    {expandedSdg === sdg.id && (
                        <div style={{ padding: '20px', borderTop: '1px solid var(--border-color)', background: 'var(--bg-color)' }}>
                            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}>
                                {sdg.specific_indicators && sdg.specific_indicators.map((ind, index) => (
                                    <div key={index} style={{ display: 'flex', gap: '15px', alignItems: 'flex-start' }}>
                                        <div style={{
                                            minWidth: '12px',
                                            height: '12px',
                                            borderRadius: '50%',
                                            background: ind.color,
                                            marginTop: '6px'
                                        }} title={ind.status}></div>
                                        <div>
                                            <div style={{ fontWeight: '600', color: 'var(--text-primary)', marginBottom: '5px' }}>
                                                {ind.name}
                                                <span style={{ marginLeft: '10px', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                                                    {ind.icon} {ind.status}
                                                </span>
                                            </div>
                                            <div style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', fontStyle: 'italic', lineHeight: '1.4' }}>
                                                "{ind.scenario}"
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            ))}

            {/* Legend */}
            <div style={{ marginTop: '30px', padding: '20px', background: 'var(--card-bg)', borderRadius: '10px', border: '1px solid var(--border-color)', display: 'flex', flexWrap: 'wrap', gap: '20px', justifyContent: 'center' }}>
                {Object.entries(statusColors).map(([status, color]) => (
                    <div key={status} style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                        <span style={{ width: '12px', height: '12px', borderRadius: '50%', background: color }}></span>
                        {status}
                    </div>
                ))}
            </div>
        </div>
    )
}
