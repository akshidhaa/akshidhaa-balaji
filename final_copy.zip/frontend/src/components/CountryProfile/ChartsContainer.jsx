import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Line, Bar } from 'react-chartjs-2';

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    Title,
    Tooltip,
    Legend
);

export default function ChartsContainer({ data }) {
    if (!data) return null;

    const commonOptions = {
        responsive: true,
        plugins: {
            legend: { position: 'top' },
        },
    };

    const coalData = {
        labels: data.labels,
        datasets: [
            {
                label: 'Coal Dependency (%)',
                data: data.datasets.coal_dependency,
                borderColor: '#e74c3c',
                backgroundColor: 'rgba(231, 76, 60, 0.5)',
            }
        ]
    };

    const renewData = {
        labels: data.labels,
        datasets: [
            {
                label: 'Renewable Adoption (%)',
                data: data.datasets.renewable_adoption,
                borderColor: '#2ecc71',
                backgroundColor: 'rgba(46, 204, 113, 0.5)',
            }
        ]
    };

    const hydrogenData = {
        labels: data.labels,
        datasets: [
            {
                label: 'Green Hydrogen (GW)',
                data: data.datasets.green_hydrogen,
                backgroundColor: '#3498db',
            }
        ]
    };

    const forestData = {
        labels: data.labels,
        datasets: [
            {
                label: 'Forest Cover (Index)',
                data: data.datasets.forest_cover,
                borderColor: '#27ae60',
                backgroundColor: 'rgba(39, 174, 96, 0.2)',
                fill: true,
            }
        ]
    };

    const waterData = {
        labels: data.labels,
        datasets: [
            {
                label: 'Water Efficiency (Index)',
                data: data.datasets.water_efficiency,
                backgroundColor: '#3498db',
            }
        ]
    };

    const carbonData = {
        labels: data.labels,
        datasets: [
            {
                label: 'Carbon Sequestration (Mt)',
                data: data.datasets.carbon_sequestration,
                borderColor: '#8e44ad',
                backgroundColor: 'rgba(142, 68, 173, 0.2)',
                fill: true,
                tension: 0.4
            }
        ]
    };

    return (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}>
            <div style={{ background: 'white', padding: '15px', borderRadius: '15px', boxShadow: '0 5px 15px rgba(0,0,0,0.05)' }}>
                <h4 style={{ textAlign: 'center', marginBottom: '10px' }}>Coal Dependency Trend</h4>
                <Line options={commonOptions} data={coalData} />
            </div>
            <div style={{ background: 'white', padding: '15px', borderRadius: '15px', boxShadow: '0 5px 15px rgba(0,0,0,0.05)' }}>
                <h4 style={{ textAlign: 'center', marginBottom: '10px' }}>Renewable Adoption</h4>
                <Line options={commonOptions} data={renewData} />
            </div>
            <div style={{ background: 'white', padding: '15px', borderRadius: '15px', boxShadow: '0 5px 15px rgba(0,0,0,0.05)' }}>
                <h4 style={{ textAlign: 'center', marginBottom: '10px' }}>Green Hydrogen Growth</h4>
                <Bar options={commonOptions} data={hydrogenData} />
            </div>
            <div style={{ background: 'white', padding: '15px', borderRadius: '15px', boxShadow: '0 5px 15px rgba(0,0,0,0.05)' }}>
                <h4 style={{ textAlign: 'center', marginBottom: '10px' }}>Forest Cover Stability</h4>
                <Line options={commonOptions} data={forestData} />
            </div>
            <div style={{ background: 'white', padding: '15px', borderRadius: '15px', boxShadow: '0 5px 15px rgba(0,0,0,0.05)' }}>
                <h4 style={{ textAlign: 'center', marginBottom: '10px' }}>Water Efficiency Index</h4>
                <Bar options={commonOptions} data={waterData} />
            </div>
            <div style={{ background: 'white', padding: '15px', borderRadius: '15px', boxShadow: '0 5px 15px rgba(0,0,0,0.05)' }}>
                <h4 style={{ textAlign: 'center', marginBottom: '10px' }}>Carbon Sequestration Trend</h4>
                <Line options={commonOptions} data={carbonData} />
            </div>
        </div>
    )
}
