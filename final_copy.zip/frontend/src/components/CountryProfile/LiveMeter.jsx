export default function LiveMeter({ status, score }) {
    // Map score (0-100) to angle (-90 to 90 degrees)
    const angle = (score / 100) * 180 - 90;

    const sections = [
        { color: '#e74c3c', start: -90, end: -45, label: 'Not Safe' },
        { color: '#e67e22', start: -45, end: 0, label: 'Hazardous' },
        { color: '#f1c40f', start: 0, end: 45, label: 'Better' },
        { color: '#2ecc71', start: 45, end: 90, label: 'Safe' }
    ];

    // Determine current section color based on score
    let currentColor = '#bdc3c7';
    if (score < 25) currentColor = '#e74c3c';
    else if (score < 50) currentColor = '#e67e22';
    else if (score < 75) currentColor = '#f1c40f';
    else currentColor = '#2ecc71';

    // Helper to calculate SVG path for arc
    const describeArc = (x, y, radius, startAngle, endAngle) => {
        const start = polarToCartesian(x, y, radius, endAngle);
        const end = polarToCartesian(x, y, radius, startAngle);
        const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
        return [
            "M", start.x, start.y,
            "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y
        ].join(" ");
    };

    const polarToCartesian = (centerX, centerY, radius, angleInDegrees) => {
        const angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;
        return {
            x: centerX + (radius * Math.cos(angleInRadians)),
            y: centerY + (radius * Math.sin(angleInRadians))
        };
    };

    return (
        <div style={{ textAlign: 'center', background: 'white', padding: '20px', borderRadius: '20px', boxShadow: '0 10px 30px rgba(0,0,0,0.08)', width: '100%', maxWidth: '280px' }}>
            <h4 style={{ color: '#7f8c8d', marginBottom: '20px', letterSpacing: '1px', fontSize: '0.9rem' }}>LIVE METER READER</h4>

            <div style={{ position: 'relative', width: '220px', height: '120px', margin: '0 auto' }}>
                <svg viewBox="0 0 220 120" width="100%" height="100%">
                    {/* Gauge Segments */}
                    {sections.map((section, index) => (
                        <path
                            key={index}
                            d={describeArc(110, 110, 100, section.start, section.end)}
                            fill="none"
                            stroke={section.color}
                            strokeWidth="30"
                        />
                    ))}

                    {/* Needle */}
                    <g style={{ transition: 'transform 1s ease-out', transformOrigin: '110px 110px', transform: `rotate(${angle}deg)` }}>
                        <path d="M 110 110 L 110 20" stroke="#2c3e50" strokeWidth="6" strokeLinecap="round" />
                        <circle cx="110" cy="110" r="8" fill="#2c3e50" />
                    </g>
                </svg>

                {/* Score & Label Overlay */}
                <div style={{ position: 'absolute', bottom: '0', left: '0', right: '0', textAlign: 'center' }}>
                    <div style={{ fontSize: '2rem', fontWeight: '800', color: currentColor }}>{score}</div>
                    <div style={{ fontSize: '1rem', fontWeight: 'bold', color: currentColor, textTransform: 'uppercase' }}>{status}</div>
                </div>
            </div>

            <p style={{ marginTop: '20px', fontSize: '0.85rem', color: '#bdc3c7' }}>
                Real-time sustainability index
            </p>
        </div>
    )
}
