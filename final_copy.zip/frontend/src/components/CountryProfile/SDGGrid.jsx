import { useState } from 'react';

export default function SDGGrid({ sdgs }) {
    const [selectedSdg, setSelectedSdg] = useState(null);

    return (
        <div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(60px, 1fr))', gap: '10px', marginTop: '20px' }}>
                {sdgs.map((sdg) => (
                    <div
                        key={sdg.id}
                        title={sdg.title}
                        onClick={() => setSelectedSdg(sdg)}
                        style={{
                            background: sdg.color,
                            color: 'white',
                            padding: '10px',
                            borderRadius: '8px',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '0.8rem',
                            fontWeight: 'bold',
                            cursor: 'pointer',
                            boxShadow: selectedSdg?.id === sdg.id ? '0 0 0 3px #333' : '0 2px 5px rgba(0,0,0,0.1)',
                            transform: selectedSdg?.id === sdg.id ? 'scale(1.1)' : 'scale(1)',
                            transition: 'all 0.2s ease'
                        }}
                    >
                        <div style={{ fontSize: '1.2rem' }}>{sdg.id}</div>
                    </div>
                ))}
            </div>

            {selectedSdg && (
                <div style={{
                    marginTop: '20px',
                    padding: '15px',
                    background: '#f8f9fa',
                    borderRadius: '8px',
                    borderLeft: `5px solid ${selectedSdg.color}`,
                    animation: 'fadeIn 0.3s'
                }}>
                    <h4 style={{ margin: '0 0 5px 0', color: '#2c3e50' }}>
                        SDG {selectedSdg.id}: {selectedSdg.title}
                    </h4>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '5px' }}>
                        <span style={{
                            background: selectedSdg.color,
                            color: 'white',
                            padding: '2px 8px',
                            borderRadius: '4px',
                            fontSize: '0.8rem'
                        }}>
                            {selectedSdg.status}
                        </span>
                    </div>
                    <p style={{ margin: 0, fontSize: '0.9rem', color: '#555' }}>
                        {selectedSdg.description || "Status details unavailable."}
                    </p>
                </div>
            )}

            {/* Legend based on user request */}
            <div style={{ marginTop: '20px', fontSize: '0.75rem', color: '#666', display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><span style={{ width: 10, height: 10, borderRadius: '50%', background: '#28a745' }}></span> Achieved</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><span style={{ width: 10, height: 10, borderRadius: '50%', background: '#ffc107' }}></span> Challenges</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><span style={{ width: 10, height: 10, borderRadius: '50%', background: '#fd7e14' }}></span> Significant</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><span style={{ width: 10, height: 10, borderRadius: '50%', background: '#dc3545' }}></span> Major</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><span style={{ width: 10, height: 10, borderRadius: '50%', background: '#000000' }}></span> Regression</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><span style={{ width: 10, height: 10, borderRadius: '50%', background: '#6c757d' }}></span> Unavailable</div>
            </div>
        </div>
    )
}
