import React, { useState, useEffect } from 'react';
import RankingTable from './RankingTable';
import CountryPopper from './CountryPopper';
import axios from 'axios';

export default function RankingsWidget() {
    const [rankings, setRankings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [sortBy, setSortBy] = useState('overall');
    const [region, setRegion] = useState('All');
    const [search, setSearch] = useState('');
    const [selectedCountryId, setSelectedCountryId] = useState(null);

    const sdgOptions = [
        { value: 'overall', label: 'Overall Score' },
        ...Array.from({ length: 17 }, (_, i) => ({ value: `sdg_${i + 1}`, label: `SDG ${i + 1}` }))
    ];

    const regions = ['All', 'Africa', 'Americas', 'Asia', 'Europe', 'Oceania'];

    useEffect(() => {
        fetchRankings();
    }, [sortBy, region, search]);

    const fetchRankings = async () => {
        setLoading(true);
        try {
            const response = await axios.get('http://127.0.0.1:5000/api/rankings', {
                params: {
                    sort_by: sortBy,
                    region: region,
                    search: search
                }
            });
            setRankings(response.data);
        } catch (error) {
            console.error("Error fetching rankings:", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto', animation: 'fadeIn 0.5s' }}>
            <div style={{ marginBottom: '30px' }}>
                <h1 style={{ fontSize: '2rem', color: 'var(--primary)', marginBottom: '10px' }}>Global Sustainability Rankings</h1>
                <p style={{ color: 'var(--text-secondary)' }}>Compare performance across 200+ countries on overall sustainability and specific SDGs.</p>
            </div>

            {/* Controls */}
            <div style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '15px',
                marginBottom: '20px',
                padding: '20px',
                background: 'var(--card-bg)',
                borderRadius: '8px',
                boxShadow: 'var(--shadow-sm)',
                alignItems: 'center'
            }}>
                {/* SDG Dropdown */}
                <div style={{ flex: '1 1 200px' }}>
                    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 'bold', color: 'var(--text-secondary)', marginBottom: '5px' }}>
                        Rank By
                    </label>
                    <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                        style={{ width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid var(--border-color)', background: 'var(--bg-color)', color: 'var(--text-primary)' }}
                    >
                        {sdgOptions.map(opt => (
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                        ))}
                    </select>
                </div>

                {/* Region Filter */}
                <div style={{ flex: '1 1 150px' }}>
                    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 'bold', color: 'var(--text-secondary)', marginBottom: '5px' }}>
                        Region
                    </label>
                    <select
                        value={region}
                        onChange={(e) => setRegion(e.target.value)}
                        style={{ width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid var(--border-color)', background: 'var(--bg-color)', color: 'var(--text-primary)' }}
                    >
                        {regions.map(r => (
                            <option key={r} value={r}>{r}</option>
                        ))}
                    </select>
                </div>

                {/* Search */}
                <div style={{ flex: '2 1 300px' }}>
                    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 'bold', color: 'var(--text-secondary)', marginBottom: '5px' }}>
                        Search Country
                    </label>
                    <input
                        type="text"
                        placeholder="Type to search..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        style={{ width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid var(--border-color)', background: 'var(--bg-color)', color: 'var(--text-primary)' }}
                    />
                </div>
            </div>

            <RankingTable
                rankings={rankings}
                loading={loading}
                selectedSdg={sortBy}
                onCountryClick={(id) => setSelectedCountryId(id)}
            />

            {selectedCountryId && (
                <CountryPopper
                    countryId={selectedCountryId}
                    onClose={() => setSelectedCountryId(null)}
                />
            )}
        </div>
    );
}
