import React from 'react';

export default function RankingTable({ rankings, loading, onCountryClick, selectedSdg }) {
    if (loading) {
        return <div style={{ padding: '20px', textAlign: 'center' }}>Loading rankings...</div>;
    }

    if (!rankings || rankings.length === 0) {
        return <div style={{ padding: '20px', textAlign: 'center' }}>No countries found.</div>;
    }

    // Helper to get color for score
    const getScoreColor = (score) => {
        if (score >= 80) return '#28a745';
        if (score >= 70) return '#ffc107';
        if (score >= 60) return '#fd7e14';
        if (score >= 40) return '#dc3545';
        return '#000000';
    };

    return (
        <div style={{ overflowX: 'auto', background: 'var(--card-bg)', borderRadius: '8px', boxShadow: 'var(--shadow-sm)' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '600px' }}>
                <thead>
                    <tr style={{ borderBottom: '2px solid var(--border-color)', background: 'var(--bg-color)' }}>
                        <th style={{ padding: '15px', textAlign: 'left', width: '80px', color: 'var(--text-secondary)' }}>Rank</th>
                        <th style={{ padding: '15px', textAlign: 'left', color: 'var(--text-secondary)' }}>Country</th>
                        <th style={{ padding: '15px', textAlign: 'left', color: 'var(--text-secondary)' }}>Region</th>
                        <th style={{ padding: '15px', textAlign: 'right', width: '120px', color: 'var(--text-secondary)' }}>
                            {selectedSdg === 'overall' ? 'Overall Score' : `${selectedSdg.replace('_', ' ').toUpperCase()} Score`}
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {rankings.map((country) => (
                        <tr
                            key={country.id}
                            onClick={() => onCountryClick(country.id)}
                            style={{
                                borderBottom: '1px solid var(--border-color)',
                                cursor: 'pointer',
                                transition: 'background 0.2s',
                                color: 'var(--text-primary)'
                            }}
                            className="ranking-row"
                            onMouseEnter={(e) => e.currentTarget.style.background = 'var(--nav-btn-hover)'}
                            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                        >
                            <td style={{ padding: '15px', fontWeight: 'bold', color: 'var(--text-primary)' }}>
                                #{country.rank_view}
                            </td>
                            <td style={{ padding: '15px' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                    <img
                                        src={country.flag}
                                        alt={country.name}
                                        style={{ width: '30px', height: '20px', objectFit: 'cover', borderRadius: '2px', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }}
                                    />
                                    <span style={{ fontWeight: '600', color: 'var(--text-primary)' }}>{country.name}</span>
                                </div>
                            </td>
                            <td style={{ padding: '15px', color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
                                {country.region}
                            </td>
                            <td style={{ padding: '15px', textAlign: 'right', fontWeight: 'bold' }}>
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '8px' }}>
                                    <span style={{ color: getScoreColor(country[selectedSdg === 'overall' ? 'overall_score' : selectedSdg]) }}>
                                        {country[selectedSdg === 'overall' ? 'overall_score' : selectedSdg]}
                                    </span>
                                    {/* Mini Progress Bar */}
                                    <div style={{ width: '50px', height: '6px', background: 'var(--border-color)', borderRadius: '3px', overflow: 'hidden' }}>
                                        <div style={{
                                            width: `${country[selectedSdg === 'overall' ? 'overall_score' : selectedSdg]}%`,
                                            height: '100%',
                                            background: getScoreColor(country[selectedSdg === 'overall' ? 'overall_score' : selectedSdg])
                                        }} />
                                    </div>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
