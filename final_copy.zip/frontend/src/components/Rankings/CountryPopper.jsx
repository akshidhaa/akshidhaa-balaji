import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import SDGGrid from '../CountryProfile/SDGGrid'; // Reuse existing component!
import axios from 'axios';

export default function CountryPopper({ countryId, onClose }) {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!countryId) return;

        const fetchData = async () => {
            setLoading(true);
            try {
                // Reuse the country profile detail endpoint
                const response = await axios.get(`http://127.0.0.1:5000/api/country-profile/${countryId}`);
                setData(response.data);
            } catch (error) {
                console.error("Error fetching country detail:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [countryId]);


    if (!countryId) return null;

    return (
        <div style={{
            position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
            background: 'rgba(0,0,0,0.5)', zIndex: 1000,
            display: 'flex', justifyContent: 'center', alignItems: 'center'
        }} onClick={onClose}>
            <div style={{
                background: 'white', width: '90%', maxWidth: '800px', maxHeight: '90vh',
                borderRadius: '12px', padding: '0', overflowY: 'auto', position: 'relative',
                boxShadow: '0 5px 20px rgba(0,0,0,0.2)', animation: 'slideIn 0.3s'
            }} onClick={e => e.stopPropagation()}>

                {/* Header */}
                <div style={{ padding: '20px', borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    {loading ? <span>Loading...</span> : (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                            <img src={data.flag_url} alt={data.name} style={{ height: '40px', borderRadius: '4px' }} />
                            <div>
                                <h2 style={{ margin: 0, color: '#2c3e50' }}>{data.name}</h2>
                                <span style={{ color: '#666', fontSize: '0.9rem' }}>{data.region}</span>
                            </div>
                        </div>
                    )}
                    <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer' }}>&times;</button>
                </div>

                {loading ? (
                    <div style={{ padding: '40px', textAlign: 'center' }}>Loading details...</div>
                ) : (
                    <div style={{ padding: '20px' }}>
                        {/* Energy Mix Stats (New X/Y Metrics) */}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '30px' }}>
                            <div style={{ background: '#f0fff4', padding: '15px', borderRadius: '12px', border: '1px solid #c3e6cb' }}>
                                <div style={{ fontSize: '0.8rem', fontWeight: 'bold', color: '#666', textTransform: 'uppercase' }}>Renewables</div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '5px' }}>
                                    <span style={{ fontSize: '1.5rem' }}>☀️</span>
                                    <span style={{ fontSize: '2rem', fontWeight: 'bold', color: '#27ae60' }}>{data.energy_mix?.renewables.current}%</span>
                                </div>
                            </div>
                            <div style={{ background: '#fff5f5', padding: '15px', borderRadius: '12px', border: '1px solid #f5c6cb' }}>
                                <div style={{ fontSize: '0.8rem', fontWeight: 'bold', color: '#666', textTransform: 'uppercase' }}>Coal Dep.</div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '5px' }}>
                                    <span style={{ fontSize: '1.5rem' }}>🏭</span>
                                    <span style={{ fontSize: '2rem', fontWeight: 'bold', color: '#e74c3c' }}>{data.energy_mix?.coal.current}%</span>
                                </div>
                            </div>
                        </div>

                        {/* 5-Year Trend Graph */}
                        <div style={{ marginBottom: '30px' }}>
                            <h3 style={{ fontSize: '0.9rem', fontWeight: 'bold', color: '#7f8c8d', marginBottom: '15px', textTransform: 'uppercase' }}>5-Year Trend</h3>
                            <div style={{ height: '200px' }}>
                                <Line data={{
                                    labels: ['2019', '2020', '2021', '2022', '2023'],
                                    datasets: [
                                        {
                                            label: 'Renewables',
                                            data: data.energy_mix?.renewables.history || [],
                                            borderColor: '#2ecc71',
                                            backgroundColor: 'transparent',
                                            borderWidth: 3,
                                            tension: 0.4,
                                            pointRadius: 4,
                                            pointBackgroundColor: '#2ecc71'
                                        },
                                        {
                                            label: 'Coal Dep.',
                                            data: data.energy_mix?.coal.history || [],
                                            borderColor: '#e74c3c',
                                            backgroundColor: 'transparent',
                                            borderWidth: 3,
                                            tension: 0.4,
                                            pointRadius: 4,
                                            pointBackgroundColor: '#e74c3c'
                                        }
                                    ]
                                }} options={{
                                    maintainAspectRatio: false,
                                    plugins: { legend: { display: false } }, // Hide legend to match clean look
                                    scales: {
                                        y: { beginAtZero: true, grid: { color: '#f0f0f0' } },
                                        x: { grid: { display: false } }
                                    }
                                }} />
                            </div>
                        </div>

                        {/* SDG Grid */}
                        <div>
                            <h3 style={{ fontSize: '1.1rem', marginBottom: '15px', color: '#333' }}>SDG Performance</h3>
                            <SDGGrid sdgs={data.sdg_performance} />
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
