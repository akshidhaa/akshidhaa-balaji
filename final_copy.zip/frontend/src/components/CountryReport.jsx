import { useState, useEffect } from 'react'
import axios from 'axios'

export default function CountryReport({ country, onBack }) {
    const [report, setReport] = useState(null)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        if (!country) return;
        setLoading(true)
        axios.get(`/api/country-report/${country.id}`)
            .then(res => {
                setReport(res.data)
                setLoading(false)
            })
            .catch(err => {
                console.error(err)
                setLoading(false)
            })
    }, [country])

    if (!country) return null;

    if (loading) {
        return (
            <div style={{ padding: '50px', textAlign: 'center', color: 'var(--text-secondary)' }}>
                <h2 style={{ color: 'var(--text-primary)' }}>Loading Report for {country.name}...</h2>
            </div>
        )
    }

    if (!report) {
        return (
            <div style={{ padding: '50px', textAlign: 'center', color: '#e74c3c' }}>
                <h2>Failed to load report.</h2>
                <button onClick={onBack} style={{ marginTop: '20px' }}>Go Back</button>
            </div>
        )
    }

    return (
        <div className="country-report-container" style={{ animation: 'fadeIn 0.5s', paddingBottom: '50px' }}>
            {/* Header / Nav */}
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
                <button
                    onClick={onBack}
                    style={{
                        background: 'none', border: 'none', cursor: 'pointer',
                        fontSize: '1.2rem', color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '5px'
                    }}
                >
                    ← Back to Map
                </button>
            </div>

            {/* Hero Section */}
            <div style={{
                position: 'relative',
                height: '400px',
                borderRadius: '20px',
                overflow: 'hidden',
                boxShadow: '0 10px 30px rgba(0,0,0,0.2)',
                marginBottom: '40px'
            }}>
                <img
                    src={report.hero_image}
                    alt={report.title}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    onError={(e) => e.target.src = 'https://via.placeholder.com/1200x400?text=Sustainability+Report'} // Fallback
                />
                <div style={{
                    position: 'absolute', bottom: '0', left: '0', right: '0',
                    background: 'linear-gradient(to top, rgba(0,0,0,0.8), transparent)',
                    padding: '40px'
                }}>
                    <h1 style={{ color: 'white', fontSize: '3rem', margin: '0', textShadow: '0 2px 4px rgba(0,0,0,0.5)' }}>{report.title}</h1>
                    <div style={{ display: 'flex', gap: '15px', marginTop: '10px' }}>
                        <span style={{ background: '#2ecc71', color: 'white', padding: '5px 15px', borderRadius: '20px', fontWeight: 'bold' }}>
                            {country.status}
                        </span>
                        <span style={{ background: 'rgba(255,255,255,0.2)', color: 'white', padding: '5px 15px', borderRadius: '20px', backdropFilter: 'blur(5px)' }}>
                            Score: {country.score}/100
                        </span>
                    </div>
                </div>
            </div>

            <div className="report-content" style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '40px' }}>
                {/* Main Content */}
                <div>
                    <section style={{ marginBottom: '40px' }}>
                        <h2 style={{ fontSize: '2rem', marginBottom: '15px', color: 'var(--text-primary)' }}>Executive Summary</h2>
                        <p style={{ fontSize: '1.2rem', lineHeight: '1.8', color: 'var(--text-secondary)' }}>{report.description}</p>
                    </section>

                    {report.sections.map((section, index) => (
                        <section key={index} style={{ marginBottom: '40px', background: 'var(--card-bg)', padding: '30px', borderRadius: '15px', boxShadow: 'var(--shadow-md)', border: '1px solid var(--border-color)' }}>
                            <div style={{ display: 'flex', gap: '30px', alignItems: 'center', flexDirection: index % 2 === 0 ? 'row' : 'row-reverse' }}>
                                <div style={{ flex: 1 }}>
                                    <h3 style={{ fontSize: '1.5rem', marginBottom: '15px', color: 'var(--accent)' }}>{section.title}</h3>
                                    <p style={{ fontSize: '1.1rem', lineHeight: '1.7', color: 'var(--text-secondary)' }}>{section.content}</p>
                                </div>
                                <div style={{ flex: 1 }}>
                                    <img
                                        src={section.image}
                                        alt={section.title}
                                        style={{ width: '100%', borderRadius: '10px', boxShadow: '0 5px 15px rgba(0,0,0,0.1)' }}
                                        onError={(e) => e.target.src = 'https://via.placeholder.com/600x400?text=Section+Image'}
                                    />
                                </div>
                            </div>
                        </section>
                    ))}
                </div>

                {/* Sidebar Stats */}
                <div>
                    <div style={{ background: 'var(--primary)', color: 'white', padding: '30px', borderRadius: '20px', position: 'sticky', top: '20px' }}>
                        <h3 style={{ borderBottom: '1px solid rgba(255,255,255,0.2)', paddingBottom: '15px', marginBottom: '20px' }}>Key Metrics</h3>

                        <div style={{ marginBottom: '25px' }}>
                            <div style={{ fontSize: '0.9rem', opacity: 0.8, marginBottom: '5px' }}>RENEWABLE SHARE</div>
                            <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#2ecc71' }}>{report.stats.renewable_share}</div>
                        </div>

                        <div style={{ marginBottom: '25px' }}>
                            <div style={{ fontSize: '0.9rem', opacity: 0.8, marginBottom: '5px' }}>FOREST COVER</div>
                            <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#27ae60' }}>{report.stats.forest_cover}</div>
                        </div>

                        <div style={{ marginBottom: '25px' }}>
                            <div style={{ fontSize: '0.9rem', opacity: 0.8, marginBottom: '5px' }}>CO2 PER CAPITA</div>
                            <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#e74c3c' }}>{report.stats.emissions_per_capita}</div>
                        </div>

                        <div style={{ marginTop: '30px', paddingTop: '20px', borderTop: '1px solid rgba(255,255,255,0.2)' }}>
                            <div style={{ fontSize: '0.9rem', opacity: 0.8, marginBottom: '10px' }}>MAJOR CHALLENGES</div>
                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
                                {country.issues.map((issue, i) => (
                                    <span key={i} style={{ background: 'rgba(231, 76, 60, 0.2)', color: '#ffadad', padding: '5px 10px', borderRadius: '5px', fontSize: '0.85rem' }}>
                                        {issue}
                                    </span>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
