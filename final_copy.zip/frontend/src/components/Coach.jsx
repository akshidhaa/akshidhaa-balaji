import { useState, useRef, useEffect } from 'react'
import axios from 'axios'
import { Mic, MicOff, Square, Send, Sparkles } from 'lucide-react'

export default function Coach() {
    const [query, setQuery] = useState('')
    const [messages, setMessages] = useState([
        { role: 'coach', text: "Hello! I'm your AI Eco-Coach. Ask me anything about sustainable living! 🌿" }
    ])
    const [loading, setLoading] = useState(false)
    const [isListening, setIsListening] = useState(false)
    const messagesEndRef = useRef(null)
    const recognitionRef = useRef(null)

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
    }

    useEffect(() => {
        scrollToBottom()
    }, [messages])

    // Initialize Speech Recognition
    useEffect(() => {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
        if (SpeechRecognition) {
            recognitionRef.current = new SpeechRecognition()
            recognitionRef.current.continuous = false
            recognitionRef.current.interimResults = false
            recognitionRef.current.lang = 'en-US'

            recognitionRef.current.onresult = (event) => {
                const transcript = event.results[0][0].transcript
                setQuery(transcript)
                setIsListening(false)
                handleVoiceQuery(transcript)
            }

            recognitionRef.current.onerror = (event) => {
                console.error("Speech recognition error", event.error)
                setIsListening(false)
            }

            recognitionRef.current.onend = () => {
                setIsListening(false)
            }
        }
    }, [])

    const speakText = (text) => {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel()
            const utterance = new SpeechSynthesisUtterance(text)
            utterance.lang = 'en-US'
            utterance.rate = 1.0
            utterance.pitch = 1.0
            window.speechSynthesis.speak(utterance)
        }
    }

    const toggleListening = () => {
        if (isListening) {
            recognitionRef.current?.stop()
        } else {
            setQuery('')
            recognitionRef.current?.start()
            setIsListening(true)
        }
    }

    const askCoach = async (e) => {
        if (e) e.preventDefault()
        if (!query.trim()) return

        const textToSubmit = query
        setQuery('')
        await processQuery(textToSubmit)
    }

    const handleVoiceQuery = async (transcript) => {
        if (!transcript.trim()) return
        await processQuery(transcript)
    }

    const processQuery = async (text) => {
        const userMsg = { role: 'user', text: text }
        setMessages(prev => [...prev, userMsg])
        setLoading(true)

        try {
            const res = await axios.post('/api/eco-coach', { query: text })
            const responseText = res.data.coach_response
            setMessages(prev => [...prev, { role: 'coach', text: responseText }])
            speakText(responseText)
        } catch (err) {
            console.error(err)
            const errorMsg = "I'm having trouble connecting to the green grid. Try again later! 🔌"
            setMessages(prev => [...prev, { role: 'coach', text: errorMsg }])
            speakText(errorMsg)
        }
        setLoading(false)
    }

    return (
        <div className="fade-in" style={{ flex: 1, height: '100%', display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--accent)' }}>
                    <Sparkles size={16} />
                    <span style={{ fontWeight: '800', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>AI Assistant</span>
                </div>
                {window.speechSynthesis.speaking && (
                    <button
                        onClick={() => window.speechSynthesis.cancel()}
                        style={{ background: 'var(--accent-soft)', border: 'none', color: 'var(--accent)', cursor: 'pointer', borderRadius: '8px', padding: '4px 8px', display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.7rem', fontWeight: '700' }}
                    >
                        <Square size={12} fill="currentColor" /> STOP VOICE
                    </button>
                )}
            </div>

            {/* Chat History */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '4px', display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '1rem' }}>
                {messages.map((msg, idx) => (
                    <div key={idx} style={{
                        alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start',
                        maxWidth: '85%',
                        background: msg.role === 'user' ? 'var(--primary)' : 'var(--bg-color)',
                        color: msg.role === 'user' ? 'white' : 'var(--text-primary)',
                        padding: '12px 16px',
                        borderRadius: '16px',
                        borderBottomRightRadius: msg.role === 'user' ? '4px' : '16px',
                        borderBottomLeftRadius: msg.role === 'coach' ? '4px' : '16px',
                        fontSize: '0.85rem',
                        lineHeight: '1.5',
                        boxShadow: 'var(--shadow-sm)',
                        border: msg.role === 'coach' ? '1px solid var(--border-color)' : 'none'
                    }}>
                        {msg.text}
                    </div>
                ))}
                {loading && (
                    <div style={{ alignSelf: 'flex-start', background: 'var(--bg-color)', padding: '12px 16px', borderRadius: '16px', color: 'var(--text-secondary)', fontSize: '0.8rem', border: '1px solid var(--border-color)' }}>
                        Deep thinking... 🍃
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <form onSubmit={askCoach} style={{ display: 'flex', gap: '8px', alignItems: 'center', background: 'var(--bg-color)', padding: '6px', borderRadius: '99px', border: '1px solid var(--border-color)' }}>
                <button
                    type="button"
                    onClick={toggleListening}
                    style={{
                        background: isListening ? '#ef4444' : 'transparent',
                        color: isListening ? 'white' : 'var(--text-secondary)',
                        border: 'none',
                        borderRadius: '50%',
                        width: '36px',
                        height: '36px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        transition: 'all 0.3s ease',
                        animation: isListening ? 'pulse 1.5s infinite' : 'none'
                    }}
                >
                    {isListening ? <MicOff size={18} /> : <Mic size={18} />}
                </button>

                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder={isListening ? "Listening..." : "Message your coach..."}
                    style={{
                        flex: 1,
                        padding: '8px 4px',
                        background: 'transparent',
                        border: 'none',
                        color: 'var(--text-primary)',
                        outline: 'none',
                        fontSize: '0.9rem'
                    }}
                    disabled={loading}
                />

                <button
                    type="submit"
                    disabled={loading || !query.trim()}
                    style={{
                        background: 'var(--accent)', color: 'white', border: 'none', borderRadius: '50%', width: '36px', height: '36px',
                        cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                        opacity: (loading || !query.trim()) ? 0.4 : 1, transition: 'var(--transition)'
                    }}
                >
                    <Send size={16} />
                </button>
            </form>

            <style dangerouslySetInnerHTML={{
                __html: `
                @keyframes pulse {
                    0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4); }
                    70% { transform: scale(1.1); box-shadow: 0 0 0 8px rgba(239, 68, 68, 0); }
                    100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
                }
            `}} />
        </div>
    )
}
