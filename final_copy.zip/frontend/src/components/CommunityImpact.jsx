import { useState, useEffect } from 'react'
import axios from 'axios'
import { LeafIcon, DropIcon, WindIcon } from './Icons'

export default function CommunityImpact({ countryId }) {
    const [impact, setImpact] = useState(null)

    useEffect(() => {
        if (!countryId) return;
        axios.get(`/api/community-impact?country=${countryId}`)
            .then(res => setImpact(res.data))
            .catch(err => console.error(err))
    }, [countryId])

    if (!impact) return <div className="widget-panel">Loading Impact...</div>

    return (
        <div className="widget-panel">
            <h3>🤝 Community Impact</h3>
            <p className="subtitle">Collective action in your region.</p>

            <div className="impact-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginTop: '15px' }}>
                <div className="impact-card" style={{ background: 'var(--accent-soft)', padding: '15px', borderRadius: '12px', textAlign: 'center', border: '1px solid var(--accent)' }}>
                    <div style={{ color: 'var(--accent)', marginBottom: '5px' }}><LeafIcon /></div>
                    <div style={{ fontSize: '1.4rem', fontWeight: '800', color: 'var(--text-primary)' }}>{impact.trees_planted.toLocaleString()}</div>
                    <div style={{ fontSize: '0.75rem', fontWeight: '600', color: 'var(--text-secondary)', textTransform: 'uppercase' }}>Trees Planted</div>
                </div>
                <div className="impact-card" style={{ background: 'rgba(52, 152, 219, 0.1)', padding: '15px', borderRadius: '12px', textAlign: 'center', border: '1px solid #3498db' }}>
                    <div style={{ color: '#3498db', marginBottom: '5px' }}><DropIcon /></div>
                    <div style={{ fontSize: '1.4rem', fontWeight: '800', color: 'var(--text-primary)' }}>{impact.plastic_avoided_kg.toLocaleString()}</div>
                    <div style={{ fontSize: '0.75rem', fontWeight: '600', color: 'var(--text-secondary)', textTransform: 'uppercase' }}>kg Plastic Saved</div>
                </div>
                <div className="impact-card" style={{ background: 'rgba(241, 196, 15, 0.1)', padding: '15px', borderRadius: '12px', textAlign: 'center', border: '1px solid #f1c40f' }}>
                    <div style={{ color: '#f1c40f', marginBottom: '5px' }}><WindIcon /></div>
                    <div style={{ fontSize: '1.4rem', fontWeight: '800', color: 'var(--text-primary)' }}>{impact.co2_saved_tons}</div>
                    <div style={{ fontSize: '0.75rem', fontWeight: '600', color: 'var(--text-secondary)', textTransform: 'uppercase' }}>Tons CO₂ Reduced</div>
                </div>
                <div className="impact-card" style={{ background: 'rgba(142, 68, 173, 0.1)', padding: '15px', borderRadius: '12px', textAlign: 'center', border: '1px solid #8e44ad' }}>
                    <div style={{ fontSize: '1.5rem', marginBottom: '5px' }}>🦸</div>
                    <div style={{ fontSize: '1.4rem', fontWeight: '800', color: 'var(--text-primary)' }}>{impact.volunteers}</div>
                    <div style={{ fontSize: '0.75rem', fontWeight: '600', color: 'var(--text-secondary)', textTransform: 'uppercase' }}>Active Volunteers</div>
                </div>
            </div>

            <button style={{ marginTop: '15px', background: '#2c3e50', width: '100%' }}>View Full Map</button>
        </div>
    )
}
