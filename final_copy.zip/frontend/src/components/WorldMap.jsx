import { useState, useEffect } from 'react'
import { MapContainer, TileLayer, GeoJSON } from 'react-leaflet'

export default function WorldMap({ data, onCountryClick, selectedSdg, activeTab }) {
    const [geoJsonData, setGeoJsonData] = useState(null)
    const [activeFilter, setActiveFilter] = useState(null) // Track active filter

    useEffect(() => {
        // Fetch a lightweight GeoJSON of world countries
        fetch('https://raw.githubusercontent.com/johan/world.geo.json/master/countries.geo.json')
            .then(res => res.json())
            .then(data => setGeoJsonData(data))
            .catch(err => console.error("Error loading map data:", err))
    }, [])

    const getColor = (country) => {
        // Mode 1: SDG Specific Coloring (Numeric Score 0-100)
        if (selectedSdg) {
            const score = country[selectedSdg]; // e.g., country.sdg_1
            if (score === undefined) return '#ecf0f1'; // No data

            // Gradient Logic (Red -> Yellow -> Green)
            if (score >= 80) return '#27ae60'; // Green
            if (score >= 70) return '#2ecc71'; // Light Green
            if (score >= 60) return '#f1c40f'; // Yellow
            if (score >= 50) return '#e67e22'; // Orange
            if (score >= 40) return '#e74c3c'; // Red
            return '#c0392b'; // Dark Red
        }

        // Mode 2: General Status Coloring (Text)
        const status = country.status ? country.status.trim() : '';
        switch (status) {
            case '1.5°C Paris Compatible': return '#2ecc71';
            case 'Almost Sufficient': return '#f1c40f';
            case 'Insufficient': return '#e67e22';
            case 'Highly Insufficient': return '#e74c3c';
            case 'Critically Insufficient': return '#2c3e50';
            default: return '#bdc3c7';
        }
    }

    const getFeatureStyle = (feature) => {
        const countryData = data.find(c => c.id === feature.id)
        let color = '#ecf0f1'
        let opacity = 0.7
        let weight = 1

        if (countryData) {
            color = getColor(countryData)

            // Filtering Logic (Only applies in Status Mode)
            if (!selectedSdg && activeFilter && countryData.status !== activeFilter) {
                color = '#ecf0f1'
                opacity = 0.3
            } else if (!selectedSdg && activeFilter && countryData.status === activeFilter) {
                weight = 2 // Highlight match
                opacity = 0.9
            }
        } else {
            // If filter is active, dim non-data countries even more
            if (activeFilter) opacity = 0.1
        }

        return {
            fillColor: color,
            weight: weight,
            opacity: 1,
            color: 'white',
            dashArray: '3',
            fillOpacity: opacity,
            transition: 'all 0.3s ease' // Smooth transition
        }
    }

    const onEachFeature = (feature, layer) => {
        const countryName = feature.properties.name
        const countryData = data.find(c => c.id === feature.id)

        if (countryData) {
            const label = selectedSdg
                ? `${countryName}: ${countryData[selectedSdg]} (SDG ${selectedSdg.split('_')[1]})`
                : `${countryName}: ${countryData.status}`;

            layer.bindTooltip(label, { sticky: true })

            // Only add interactivity if not filtered out (or if it matches filter)
            // Actually, we keep click active but visually dim
            layer.on({
                click: () => onCountryClick(countryData)
            })
        } else {
            layer.bindTooltip(countryName, { sticky: true })
        }
    }

    const categories = [
        { label: 'Critically Insufficient', color: '#2c3e50', status: 'Critically Insufficient' }, // Black/Dark
        { label: 'Highly Insufficient', color: '#e74c3c', status: 'Highly Insufficient' }, // Red
        { label: 'Insufficient', color: '#e67e22', status: 'Insufficient' }, // Orange
        { label: 'Almost Sufficient', color: '#f1c40f', status: 'Almost Sufficient' }, // Yellow
        { label: '1.5°C Paris Compatible', color: '#2ecc71', status: '1.5°C Paris Compatible' } // Green
    ]

    return (
        <div className="world-map-container" style={{ position: 'relative', height: '600px', width: '100%', borderRadius: '20px', overflow: 'hidden', border: '1px solid #ddd', display: 'flex', flexDirection: 'column' }}>

            {/* Map Area */}
            <div style={{ flex: 1, width: '100%', position: 'relative' }}>
                <MapContainer center={[20, 0]} zoom={2} scrollWheelZoom={false} style={{ height: '100%', width: '100%' }}>
                    <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
                        url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
                    />
                    {geoJsonData && (
                        <GeoJSON
                            key={activeFilter || 'all'} // Force re-render on filter change to apply styles correctly
                            data={geoJsonData}
                            style={getFeatureStyle}
                            onEachFeature={onEachFeature}
                        />
                    )}
                </MapContainer>
            </div>

            {/* STATUS LEGEND: Only show in Action Status Mode */}
            {activeTab === 'action_status' && (
                <div className="legend-bar" style={{
                    background: 'white',
                    padding: '15px 20px',
                    borderTop: '1px solid #eee',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '10px',
                    zIndex: 1000
                }}>
                    <div style={{ fontSize: '0.85rem', fontWeight: 'bold', color: '#7f8c8d', marginBottom: '5px' }}>FILTER BY SD ACTION STATUS</div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        {categories.map((cat) => {
                            const isActive = activeFilter === cat.status
                            return (
                                <button
                                    key={cat.status}
                                    onClick={() => setActiveFilter(isActive ? null : cat.status)} // Toggle
                                    style={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        width: '100%',
                                        padding: '12px 20px',
                                        borderRadius: '50px', // Rounded bars
                                        border: 'none',
                                        background: cat.color,
                                        color: 'white',
                                        cursor: 'pointer',
                                        fontSize: '0.9rem',
                                        fontWeight: '600',
                                        boxShadow: isActive ? 'inset 0 3px 8px rgba(0,0,0,0.3)' : '0 4px 6px rgba(0,0,0,0.1)',
                                        transform: isActive ? 'scale(0.98)' : 'scale(1)',
                                        transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
                                        opacity: (activeFilter && !isActive) ? 0.6 : 1
                                    }}
                                >
                                    <span style={{ textTransform: 'uppercase', letterSpacing: '0.5px' }}>{cat.label}</span>

                                    {/* Arrow Vector */}
                                    <span style={{
                                        fontSize: '1.2rem',
                                        transition: 'transform 0.3s ease',
                                        transform: isActive ? 'rotate(180deg)' : 'rotate(0deg)' // Down when active (if starting up) or toggle visual
                                    }}>
                                        {isActive ? '▼' : '›'}
                                    </span>
                                </button>
                            )
                        })}
                    </div>
                </div>
            )}

            {/* SDG LEGEND: Only show in SDG Goals Mode */}
            {activeTab === 'sdg_goals' && (
                <div className="legend-bar-sdg" style={{
                    background: 'white',
                    padding: '20px',
                    borderTop: '1px solid #eee',
                    zIndex: 1000
                }}>
                    <div style={{ fontSize: '0.85rem', fontWeight: 'bold', color: '#7f8c8d', marginBottom: '10px' }}>SDG PERFORMANCE SCORE (0-100)</div>

                    {/* Gradient Bar */}
                    <div style={{
                        height: '20px',
                        borderRadius: '10px',
                        background: 'linear-gradient(to right, #c0392b 0%, #e74c3c 40%, #f1c40f 60%, #2ecc71 80%, #27ae60 100%)',
                        marginBottom: '10px',
                        position: 'relative'
                    }} />

                    {/* Labels */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', color: '#555', fontWeight: 'bold' }}>
                        <span>CRITICAL (&lt;40)</span>
                        <span>CHALLENGES (40-60)</span>
                        <span>MODERATE (60-70)</span>
                        <span>ON TRACK (&gt;80)</span>
                    </div>
                </div>
            )}
        </div>
    )
}
