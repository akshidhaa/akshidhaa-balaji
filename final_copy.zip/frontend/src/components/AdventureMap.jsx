import { useState, useEffect, useCallback } from 'react'
import axios from 'axios'

export default function AdventureMap() {
    const [worldState, setWorldState] = useState(null)
    const [gameState, setGameState] = useState('LOADING') // LOADING, LOBBY, PLAYING, LEVEL_OVER, GAME_OVER
    const [currentLevelIdx, setCurrentLevelIdx] = useState(0)
    const [points, setPoints] = useState(0)
    const [timeLeft, setTimeLeft] = useState(0)
    const [tempTrees, setTempTrees] = useState([])
    const [totalPoints, setTotalPoints] = useState(0)
    const [totalTime, setTotalTime] = useState(0)
    const [showTryAgain, setShowTryAgain] = useState(false);
    const [lastLevelPoints, setLastLevelPoints] = useState(0);
    const [levelTimes, setLevelTimes] = useState([]); // Track time per level

    const levelSuccessSound = 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3';
    const finalVictorySound = 'https://assets.mixkit.co/active_storage/sfx/2013/2013-preview.mp3';
    const failSound = 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3';

    const treeEmojis = ["🌳", "🌲", "🌸", "🌴", "🍀"];

    // Fetch adventure configuration from backend
    useEffect(() => {
        axios.get('/api/adventure')
            .then(res => {
                setWorldState(res.data)
                setGameState('LOBBY')
            })
            .catch(err => console.error(err))
    }, [])

    const startLevel = () => {
        const level = worldState.levels[currentLevelIdx]
        setPoints(0)
        setTimeLeft(level.time_limit)
        setGameState('PLAYING')
    }

    const plantTree = useCallback(() => {
        if (gameState !== 'PLAYING') return;

        const newPoints = points + 10;
        setPoints(newPoints);

        const newTree = {
            id: Date.now(),
            type: treeEmojis[Math.floor(Math.random() * treeEmojis.length)],
            x: Math.random() * 80 + 10,
            y: Math.random() * 50 + 40,
        };
        setTempTrees(prev => [...prev, newTree]);

        // Check if level target reached
        const target = worldState.levels[currentLevelIdx].target;
        if (newPoints >= target) {
            handleLevelComplete(true);
        }
    }, [gameState, points, currentLevelIdx, worldState]);

    useEffect(() => {
        const handleKeyDown = (e) => {
            if (e.code === 'Space') {
                e.preventDefault();
                plantTree();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [plantTree]);

    // Timer logic
    useEffect(() => {
        let timerId;
        if (gameState === 'PLAYING' && timeLeft > 0) {
            timerId = setInterval(() => {
                setTimeLeft(prev => prev - 1);
                setTotalTime(prev => prev + 1);
            }, 1000);
        } else if (timeLeft === 0 && gameState === 'PLAYING') {
            handleLevelComplete(false);
        }
        return () => clearInterval(timerId);
    }, [gameState, timeLeft]);

    const handleLevelComplete = (success) => {
        if (success) {
            const finalPointsForLevel = points;
            const newTotalPoints = totalPoints + finalPointsForLevel;
            setTotalPoints(newTotalPoints);
            setTotalPoints(newTotalPoints);
            setPoints(0);

            // Record time taken
            const timeLimit = worldState.levels[currentLevelIdx].time_limit;
            const timeTaken = timeLimit - timeLeft;
            setLevelTimes(prev => [...prev, { level: currentLevelIdx + 1, time: timeTaken }]);

            // Play level complete sound
            const audio = new Audio(levelSuccessSound);
            audio.play().catch(e => console.log("Sound blocked"));

            if (currentLevelIdx + 1 < worldState.levels.length) {
                setGameState('LEVEL_OVER');
            } else {
                finishGame(newTotalPoints);
            }
        } else {
            // Failure logic
            const audio = new Audio(failSound);
            audio.play().catch(e => console.log("Sound blocked"));
            setShowTryAgain(true);
            setGameState('LEVEL_OVER'); // Borrow layout but show Try Again
        }
    };

    const finishGame = (finalTotalPoints) => {
        setGameState('GAME_OVER');
        const audio = new Audio(finalVictorySound);
        audio.play().catch(e => console.log("Sound blocked by browser"));

        axios.post('/api/adventure/score', {
            total_points: finalTotalPoints,
            total_time: totalTime,
            trees: tempTrees
        });
    };

    if (gameState === 'LOADING') return <div className="card">Entering the Forest...</div>

    const currentLevel = worldState.levels[currentLevelIdx];

    return (
        <div className="card forest-game-container" style={{ background: '#0f2027', color: 'white', position: 'relative', minHeight: '600px', overflow: 'hidden' }}>

            {/* HUD */}
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px', zIndex: 10, position: 'relative' }}>
                <div>
                    <h2 style={{ margin: 0, color: '#2ecc71' }}>🌳 5-Second Tree Plant Challenge</h2>
                    <div style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>Level {currentLevelIdx + 1}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '1.5rem', color: '#f1c40f' }}>Points: {points} / {currentLevel.target}</div>
                    <div style={{ fontSize: '1.2rem', color: timeLeft < 3 ? '#ff4757' : '#fff' }}>⏱️ Time: {timeLeft}s</div>
                </div>
            </div>

            {/* Game Area */}
            <div className="forest-viewport" style={{
                position: 'relative',
                height: '450px',
                background: 'linear-gradient(to bottom, #1e3c72, #2a5298, #2ecc71)',
                borderRadius: '15px',
                marginTop: '10px',
                boxShadow: 'inset 0 0 50px rgba(0,0,0,0.5)'
            }}>
                <div style={{ position: 'absolute', bottom: 0, width: '100%', height: '150px', background: 'linear-gradient(to bottom, #2ecc71, #27ae60)', borderRadius: '0 0 15px 15px' }}></div>

                {tempTrees.map((tree) => (
                    <div key={tree.id} className="tree-instance" style={{
                        position: 'absolute',
                        left: `${tree.x}%`,
                        bottom: `${100 - tree.y}%`,
                        fontSize: '3.5rem',
                        animation: 'popIn 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards',
                        zIndex: Math.floor(tree.y)
                    }}>
                        {tree.type}
                    </div>
                ))}

                {gameState === 'PLAYING' && (
                    <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', opacity: 0.2, fontSize: '3rem', pointerEvents: 'none' }}>
                        HIT SPACE BAR!
                    </div>
                )}
            </div>

            {/* Overlays */}
            {(gameState === 'LOBBY' || gameState === 'LEVEL_OVER') && (
                <div className="game-overlay">
                    <div className="overlay-content">
                        {showTryAgain ? (
                            <>
                                <h2 style={{ color: '#ff4757' }}>Oops! Time's Up</h2>
                                <p style={{ fontSize: '1.1rem' }}>You didn't reach the target. Don't give up!</p>
                                <button className="start-btn" onClick={() => {
                                    setShowTryAgain(false);
                                    setShowTryAgain(false);
                                    setPoints(0);
                                    setTimeLeft(worldState.levels[currentLevelIdx].time_limit);
                                    setGameState('PLAYING');
                                }} style={{ background: '#ff4757' }}>
                                    TRY AGAIN 🔄
                                </button>
                            </>
                        ) : (
                            <>
                                <h2>{gameState === 'LOBBY' ? 'Ready to Plant?' : '✅ Level Complete!'}</h2>

                                {gameState === 'LEVEL_OVER' && (
                                    <div style={{ margin: '15px 0', padding: '15px', background: '#e8f8f5', borderRadius: '10px', borderLeft: '5px solid #2ecc71', textAlign: 'left' }}>
                                        <strong>Did you know?</strong>
                                        <p style={{ margin: '5px 0 0 0', fontSize: '1rem', color: '#16a085' }}>
                                            {[
                                                "Great job! Trees absorb CO2 and release oxygen, helping us breathe cleaner air.",
                                                "Amazing! Forests play a crucial role in preventing soil erosion and controlling floods.",
                                                "Fantastic! Healthy forests provide a home for 80% of the world's terrestrial biodiversity."
                                            ][currentLevelIdx] || "Every tree planted counts towards a greener future!"}
                                        </p>
                                    </div>
                                )}

                                <p style={{ fontSize: '1.1rem', background: 'rgba(0,0,0,0.05)', padding: '15px', borderRadius: '10px' }}>
                                    {gameState === 'LOBBY'
                                        ? worldState.levels[currentLevelIdx]?.rule
                                        : (worldState.levels[currentLevelIdx + 1] ? `Next: ${worldState.levels[currentLevelIdx + 1].rule}` : "Final Stage Complete!")
                                    }
                                </p>
                                <button className="start-btn" onClick={() => {
                                    if (gameState === 'LEVEL_OVER') setCurrentLevelIdx(prev => prev + 1);
                                    startLevel();
                                }}>
                                    {gameState === 'LOBBY' ? 'START GAME' : 'NEXT LEVEL ❯'}
                                </button>
                            </>
                        )}
                    </div>
                </div>
            )}

            {gameState === 'GAME_OVER' && (
                <div className="game-overlay" style={{ background: 'rgba(46, 204, 113, 0.9)' }}>
                    <div className="overlay-content" style={{ color: '#2c3e50', padding: '30px' }}>
                        <h1 style={{ fontSize: '2.5rem', margin: '0 0 10px 0', color: '#2ecc71' }}>🎉 CONGRATULATIONS!</h1>
                        <p style={{ fontSize: '1.5rem' }}>You are a Master Forest Guardian!</p>
                        <hr style={{ width: '100%', opacity: 0.1, margin: '20px 0' }} />

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', margin: '20px 0' }}>
                            <div className="stat-card">
                                <small>TOTAL POINTS</small>
                                <div style={{ color: '#27ae60' }}>{totalPoints + points}</div>
                            </div>
                            <div className="stat-card">
                                <small>TOTAL TIME</small>
                                <div style={{ color: '#27ae60' }}>{totalTime}s</div>
                            </div>
                        </div>

                        <div style={{
                            background: '#f1f2f6',
                            padding: '20px',
                            borderRadius: '15px',
                            margin: '20px 0',
                            borderLeft: '5px solid #2ecc71',
                            textAlign: 'left'
                        }}>
                            <h3 style={{ margin: '0 0 10px 0', color: '#2f3542' }}>🌿 Join the Green Revolution!</h3>
                            <p style={{ fontSize: '1rem', color: '#57606f', lineHeight: '1.4' }}>
                                Hey there! Come join me and plant trees as a game! Let's create afforestation awareness together. Every digital tree reflects the potential for a real one. 🌳✨
                            </p>
                        </div>

                        <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', margin: '20px 0' }}>
                            <button
                                onClick={() => {
                                    const shareText = `Hey! Join me in saving the planet! 🌍💚\n\nI just scored ${totalPoints + points} points in ${totalTime}s on the Eco-Adventure game!\n\nLet's save the planet together:\nhttps://cooler-disabilities-latter-reserves.trycloudflare.com/game`;
                                    window.open(`https://wa.me/?text=${encodeURIComponent(shareText)}`, '_blank');
                                }}
                                style={{ background: '#25D366', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '50px', cursor: 'pointer', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px' }}
                            >
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
                                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                                </svg>
                                WhatsApp
                            </button>
                            <button
                                onClick={() => {
                                    const shareUrl = "https://cooler-disabilities-latter-reserves.trycloudflare.com/game";
                                    const shareTitle = `Join me in saving the planet! I scored ${totalPoints + points} points on the Eco-Adventure game. Let's make a difference together! 🌍💚`;
                                    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}&title=${encodeURIComponent(shareTitle)}`, '_blank');
                                }}
                                style={{ background: '#0077B5', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '50px', cursor: 'pointer', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px' }}
                            >
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
                                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                                </svg>
                                LinkedIn
                            </button>
                            <button
                                onClick={() => {
                                    const shareText = `Hey! Let's save the planet together! 🌍💚\n\nI scored ${totalPoints + points} points in ${totalTime}s on the Eco-Adventure game!\n\nJoin me and make a difference:\nhttps://cooler-disabilities-latter-reserves.trycloudflare.com/game`;
                                    alert(`Copy this to your Instagram Bio or Story:\n\n${shareText}`);
                                }}
                                style={{ background: 'linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%)', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '50px', cursor: 'pointer', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px' }}
                            >
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
                                    <path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z" />
                                </svg>
                                Instagram
                            </button>
                        </div>

                        <div style={{
                            background: 'rgba(46, 204, 113, 0.1)',
                            padding: '12px',
                            borderRadius: '10px',
                            fontSize: '0.85rem',
                            color: 'var(--text-primary)',
                            border: '1px solid var(--accent)',
                            marginTop: '10px',
                            textAlign: 'center'
                        }}>
                            <strong>✅ Barrier-Free Live Link Active!</strong><br />
                            Your friends can now join the revolution directly using the links above.
                        </div>

                        <button className="start-btn" onClick={() => window.location.reload()} style={{ background: '#2ecc71', color: 'white' }}>
                            PLAY AGAIN
                        </button>
                    </div>
                </div>
            )}

            {/* Performance History */}
            {levelTimes.length > 0 && (
                <div className="timing-board">
                    <h3 style={{ margin: '0 0 10px 0', color: '#2c3e50', fontSize: '1.1rem' }}>⏱️ Level Performance</h3>
                    {levelTimes.map((entry, idx) => (
                        <div key={idx} className="timing-item">
                            <span>Level {entry.level}</span>
                            <strong>{entry.time}s</strong>
                        </div>
                    ))}
                </div>
            )}

            <style>{`
                @keyframes popIn {
                    0% { transform: scale(0) rotate(-20deg); opacity: 0; }
                    100% { transform: scale(1) rotate(0); opacity: 1; }
                }

                .timing-board {
                    margin-top: 20px;
                    background: white;
                    padding: 15px;
                    border-radius: 10px;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
                }
                .timing-item {
                    display: flex;
                    justify-content: space-between;
                    padding: 8px 0;
                    border-bottom: 1px solid #eee;
                    color: #2c3e50;
                }
                .timing-item:last-child { border-bottom: none; }
                .game-overlay {
                    position: absolute;
                    top: 0; left: 0; width: 100%; height: 100%;
                    background: rgba(0,0,0,0.85);
                    display: flex; justify-content: center; align-items: center;
                    z-index: 100;
                    backdrop-filter: blur(8px);
                }
                .overlay-content {
                    background: white;
                    color: #2c3e50;
                    padding: 40px;
                    border-radius: 20px;
                    text-align: center;
                    max-width: 500px;
                    width: 90%;
                    box-shadow: 0 20px 40px rgba(0,0,0,0.4);
                    border: 4px solid #2ecc71;
                }
                .start-btn {
                    margin-top: 20px;
                    padding: 15px 40px;
                    font-size: 1.2rem;
                    font-weight: bold;
                    border: none;
                    border-radius: 50px;
                    background: #2ecc71;
                    color: white;
                    cursor: pointer;
                    transition: transform 0.2s, box-shadow 0.2s;
                }
                .start-btn:hover {
                    transform: scale(1.05);
                    box-shadow: 0 10px 20px rgba(46, 204, 113, 0.4);
                }
                .stat-card {
                    background: rgba(0,0,0,0.08);
                    padding: 20px;
                    border-radius: 15px;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                }
                .stat-card div {
                    font-size: 2rem;
                    font-weight: 900;
                    color: #27ae60;
                }
                .tree-instance { filter: drop-shadow(0 5px 10px rgba(0,0,0,0.4)); }
            `}</style>
        </div>
    )
}
