import { useState } from 'react'
import axios from 'axios'
import { PlusCircle, Sparkles, CheckCircle2, Search, Calculator, Flame } from 'lucide-react'

export default function ActionLog({ aiInsight }) {
    const [mode, setMode] = useState('preset') // 'preset' or 'calculate'
    const [action, setAction] = useState('')
    const [impact, setImpact] = useState(0)
    const [productQuery, setProductQuery] = useState('')
    const [calculating, setCalculating] = useState(false)
    const [calcResult, setCalcResult] = useState(null)
    const [message, setMessage] = useState('')
    const [isSubmitting, setIsSubmitting] = useState(false)

    const actionPoints = {
        'recycled_bottle': 10,
        'bike_commute': 50,
        'meatless_meal': 40,
        'planted_tree': 100,
        'energy_saving': 30
    }

    const handleActionChange = (e) => {
        const selected = e.target.value
        setAction(selected)
        setImpact(actionPoints[selected] || 0)
    }

    const handleCalculate = async () => {
        if (!productQuery) return
        setCalculating(true)
        setCalcResult(null)
        try {
            const res = await axios.post('/api/calculate-impact', { product: productQuery })
            setCalcResult(res.data)
            setImpact(res.data.suggested_xp)
            setAction(`custom_${productQuery}`)
        } catch (err) {
            console.error(err)
            setMessage("Failed to calculate impact.")
        }
        setCalculating(false)
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        if (!action) return;

        setIsSubmitting(true)
        try {
            const res = await axios.post('/api/actions', {
                user_id: 'current_user',
                action: action,
                impact: impact,
                is_custom: mode === 'calculate',
                product_name: productQuery
            })
            setMessage(res.data.message)
            resetForm()
            setTimeout(() => setMessage(''), 4000)
        } catch (err) {
            console.error(err)
            setMessage("Failed to log action.")
        }
        setIsSubmitting(false)
    }

    const resetForm = () => {
        setAction('')
        setImpact(0)
        setProductQuery('')
        setCalcResult(null)
    }

    return (
        <div style={{ padding: '1.5rem' }}>
            <div style={{ display: 'flex', gap: '10px', marginBottom: '1.5rem' }}>
                <button
                    onClick={() => { setMode('preset'); resetForm(); }}
                    style={{
                        flex: 1, padding: '10px', borderRadius: '8px', border: 'none',
                        background: mode === 'preset' ? 'var(--accent)' : 'var(--bg-hover)',
                        color: mode === 'preset' ? 'white' : 'var(--text-secondary)',
                        fontWeight: '600', cursor: 'pointer', transition: '0.3s'
                    }}
                >
                    Common Actions
                </button>
                <button
                    onClick={() => { setMode('calculate'); resetForm(); }}
                    style={{
                        flex: 1, padding: '10px', borderRadius: '8px', border: 'none',
                        background: mode === 'calculate' ? 'var(--accent)' : 'var(--bg-hover)',
                        color: mode === 'calculate' ? 'white' : 'var(--text-secondary)',
                        fontWeight: '600', cursor: 'pointer', transition: '0.3s'
                    }}
                >
                    Calculate Product
                </button>
            </div>

            {aiInsight && !calcResult && (
                <div style={{ marginBottom: '1.5rem', padding: '1rem', background: 'var(--accent-soft)', borderRadius: '12px', border: '1px solid var(--accent)', display: 'flex', gap: '10px', alignItems: 'start' }}>
                    <Sparkles size={18} color="var(--accent)" style={{ marginTop: '2px' }} />
                    <p style={{ margin: 0, fontSize: '0.9rem', color: 'var(--text-primary)', lineHeight: '1.4' }}>
                        {aiInsight}
                    </p>
                </div>
            )}

            {calcResult && (
                <div style={{ marginBottom: '1.5rem', padding: '1.25rem', background: 'var(--accent-soft)', borderRadius: '12px', border: '1px solid var(--accent)', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontWeight: '800', fontSize: '1.1rem', color: 'var(--text-primary)' }}>{calcResult.product}</span>
                        <span style={{
                            fontSize: '0.7rem',
                            padding: '4px 10px',
                            borderRadius: '20px',
                            background: calcResult.status_text === 'SUSTAINABLE' ? '#22c55e' :
                                calcResult.status_text === 'NOT SUSTAINABLE' ? '#ef4444' : '#f59e0b',
                            color: 'white',
                            fontWeight: '800',
                            textTransform: 'uppercase',
                            letterSpacing: '0.05em'
                        }}>
                            {calcResult.status_text}
                        </span>
                    </div>

                    <div style={{ display: 'flex', gap: '20px' }}>
                        <div style={{ flex: 1 }}>
                            <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: '700', textTransform: 'uppercase' }}>Footprint</div>
                            <div style={{ fontSize: '1.2rem', fontWeight: '800', color: 'var(--text-primary)' }}>{calcResult.carbon_footprint_kg}kg</div>
                        </div>
                        <div style={{ flex: 1 }}>
                            <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: '700', textTransform: 'uppercase' }}>XP Reward</div>
                            <div style={{
                                fontSize: '1.2rem',
                                fontWeight: '800',
                                color: calcResult.suggested_xp > 0 ? 'var(--accent)' : '#ef4444'
                            }}>
                                {calcResult.suggested_xp > 0 ? `+${calcResult.suggested_xp}` : '0'} XP
                            </div>
                        </div>
                    </div>

                    <div style={{
                        padding: '10px',
                        background: 'rgba(255,255,255,0.7)',
                        borderRadius: '8px',
                        fontSize: '0.9rem',
                        color: 'var(--text-primary)',
                        lineHeight: '1.4',
                        borderLeft: `4px solid ${calcResult.suggested_xp > 0 ? 'var(--accent)' : '#ef4444'}`,
                        boxShadow: '0 2px 4px rgba(0,0,0,0.05)'
                    }}>
                        {calcResult.tip}
                    </div>

                    <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontStyle: 'italic', opacity: 0.6 }}>
                        Matched with: {calcResult.matched_with}
                    </div>
                </div>
            )}


            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                {mode === 'preset' ? (
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 180px', gap: '1rem' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                            <label style={{ fontSize: '0.8rem', fontWeight: '700', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                                Activity Type
                            </label>
                            <select
                                value={action}
                                onChange={handleActionChange}
                                required={mode === 'preset'}
                                style={{ padding: '12px', borderRadius: '10px', border: '1px solid var(--border-color)', background: 'var(--bg-color)', color: 'var(--text-primary)', outline: 'none', cursor: 'pointer' }}
                            >
                                <option value="">Choose an action...</option>
                                <option value="recycled_bottle">Recycle Plastic Bottle</option>
                                <option value="bike_commute">Bike Commute</option>
                                <option value="meatless_meal">Plant-Based Meal</option>
                                <option value="planted_tree">Tree Planting</option>
                                <option value="energy_saving">Energy Conservation</option>
                            </select>
                        </div>

                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                            <label style={{ fontSize: '0.8rem', fontWeight: '700', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                                XP Benefit
                            </label>
                            <div style={{
                                padding: '12px',
                                background: action ? 'var(--accent-soft)' : 'var(--bg-color)',
                                border: `1px solid ${action ? 'var(--accent)' : 'var(--border-color)'}`,
                                borderRadius: '10px',
                                fontWeight: '800',
                                color: action ? 'var(--accent)' : 'var(--text-secondary)',
                                textAlign: 'center',
                                transition: 'all 0.3s ease'
                            }}>
                                {impact > 0 ? `+ ${impact} XP` : '---'}
                            </div>
                        </div>
                    </div>
                ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                            <label style={{ fontSize: '0.8rem', fontWeight: '700', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                                Search Product
                            </label>
                            <div style={{ display: 'flex', gap: '10px' }}>
                                <input
                                    type="text"
                                    placeholder="e.g. Beef, Banana, Laptop..."
                                    value={productQuery}
                                    onChange={(e) => setProductQuery(e.target.value)}
                                    style={{ flex: 1, padding: '12px', borderRadius: '10px', border: '1px solid var(--border-color)', background: 'var(--bg-color)', color: 'var(--text-primary)', outline: 'none' }}
                                />
                                <button
                                    type="button"
                                    onClick={handleCalculate}
                                    disabled={!productQuery || calculating}
                                    style={{ padding: '0 20px', borderRadius: '10px', background: 'var(--accent)', color: 'white', border: 'none', fontWeight: '700', cursor: 'pointer' }}
                                >
                                    {calculating ? '...' : <Calculator size={18} />}
                                </button>
                            </div>
                        </div>
                        {impact > 0 && (
                            <div style={{ alignSelf: 'flex-end', fontSize: '0.9rem', fontWeight: '800', color: 'var(--accent)' }}>
                                Potential Reward: +{impact} XP
                            </div>
                        )}
                    </div>
                )}

                <button
                    type="submit"
                    disabled={!action || isSubmitting}
                    style={{
                        background: isSubmitting ? 'var(--text-secondary)' : 'var(--accent)',
                        color: 'white',
                        border: 'none',
                        padding: '14px',
                        borderRadius: '12px',
                        fontWeight: '700',
                        fontSize: '1rem',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '10px',
                        transition: 'var(--transition)',
                        opacity: !action ? 0.5 : 1
                    }}
                >
                    {isSubmitting ? 'Recording...' : (
                        <>
                            <PlusCircle size={20} />
                            Log Sustainability Effort
                        </>
                    )}
                </button>
            </form>

            {message && (
                <div style={{
                    marginTop: '1.25rem',
                    padding: '12px',
                    background: 'var(--accent-soft)',
                    color: 'var(--accent)',
                    borderRadius: '10px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontSize: '0.9rem',
                    fontWeight: '700',
                    border: '1px solid var(--accent)',
                    animation: 'fadeIn 0.3s ease'
                }}>
                    <CheckCircle2 size={18} />
                    {message}
                </div>
            )}
        </div>
    )
}
