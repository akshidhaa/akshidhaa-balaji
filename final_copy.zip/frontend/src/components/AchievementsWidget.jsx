import { useState, useEffect } from 'react'
import axios from 'axios'

export default function AchievementsWidget({ countryId }) {
    const [achievements, setAchievements] = useState([])

    useEffect(() => {
        if (!countryId) return;
        axios.get(`/api/dashboard-preview?country=${countryId}`)
            .then(res => {
                // Filter for INCOMPLETE achievements
                const incomplete = res.data.badges.filter(b => !b.completed)
                setAchievements(incomplete)
            })
            .catch(err => console.error(err))
    }, [countryId])

    return (
        <div className="widget-panel">
            <h3>🎯 Goals & Achievements</h3>
            <p className="subtitle">Unlock these badges!</p>

            <div className="achievements-list" style={{ marginTop: '10px' }}>
                {achievements.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: '10px', color: '#7f8c8d' }}>
                        🎉 All caught up! Amazing work!
                    </div>
                ) : (
                    achievements.map((a, i) => (
                        <div key={i} style={{
                            display: 'flex', alignItems: 'center', gap: '15px',
                            padding: '12px', borderBottom: '1px solid var(--border-color)',
                            background: 'var(--bg-color)', borderRadius: '12px', marginBottom: '8px',
                            border: '1px solid var(--border-color)'
                        }}>
                            <div style={{ fontSize: '2rem', filter: 'grayscale(100%)', opacity: 0.4 }}>{a.icon}</div>
                            <div>
                                <div style={{ fontWeight: '700', color: 'var(--text-primary)' }}>{a.name}</div>
                                <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: '1.4' }}>{a.desc}</div>
                                <div style={{
                                    fontSize: '0.65rem', color: '#f59e0b', fontWeight: '900',
                                    marginTop: '4px', textTransform: 'uppercase', letterSpacing: '0.05em',
                                    display: 'flex', alignItems: 'center', gap: '4px'
                                }}>
                                    🔒 Locked Milestone
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>

            <button style={{ marginTop: '15px', background: '#8e44ad', width: '100%' }}>View All Milestones</button>
        </div>
    )
}
