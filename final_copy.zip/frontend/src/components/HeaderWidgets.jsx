import { useState } from 'react'
import { ReceiptIcon, UsersIcon, TrophyIcon, SirenIcon, MedalIcon } from './Icons'
import ReceiptScanner from './ReceiptScanner'
import CommunityImpact from './CommunityImpact'
import NeighborhoodChallenges from './NeighborhoodChallenges'
import EcoEmergency from './EcoEmergency'
import AchievementsWidget from './AchievementsWidget'

export default function HeaderWidgets({ selectedCountryId, activeTab }) {
    const [activeWidget, setActiveWidget] = useState(null)

    if (activeTab !== 'dashboard') return null;

    const toggleWidget = (widgetName) => {
        if (activeWidget === widgetName) {
            setActiveWidget(null)
        } else {
            setActiveWidget(widgetName)
        }
    }

    return (
        <div className="header-widgets-container" style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
            {/* Toolbar Icons */}
            <div className="widgets-toolbar" style={{ display: 'flex', gap: '15px', padding: '0 15px', borderLeft: '1px solid #eee', marginLeft: '15px' }}>
                <button
                    onClick={() => toggleWidget('receipt')}
                    title="Scan Receipt"
                    className={activeWidget === 'receipt' ? 'active' : ''}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '5px', borderRadius: '50%', transition: 'background 0.2s', backgroundColor: activeWidget === 'receipt' ? '#eee' : 'transparent' }}
                >
                    <ReceiptIcon />
                </button>
                <button
                    onClick={() => toggleWidget('impact')}
                    title="Community Impact"
                    className={activeWidget === 'impact' ? 'active' : ''}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '5px', borderRadius: '50%', transition: 'background 0.2s', backgroundColor: activeWidget === 'impact' ? '#eee' : 'transparent' }}
                >
                    <UsersIcon />
                </button>
                <button
                    onClick={() => toggleWidget('challenges')}
                    title="Neighborhood Challenges"
                    className={activeWidget === 'challenges' ? 'active' : ''}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '5px', borderRadius: '50%', transition: 'background 0.2s', backgroundColor: activeWidget === 'challenges' ? '#eee' : 'transparent' }}
                >
                    <TrophyIcon />
                </button>
                <button
                    onClick={() => toggleWidget('emergency')}
                    title="Eco Emergency"
                    className={activeWidget === 'emergency' ? 'active' : ''}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '5px', borderRadius: '50%', transition: 'background 0.2s', backgroundColor: activeWidget === 'emergency' ? '#eee' : 'transparent' }}
                >
                    <SirenIcon />
                </button>
                <button
                    onClick={() => toggleWidget('achievements')}
                    title="Achievements"
                    className={activeWidget === 'achievements' ? 'active' : ''}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '5px', borderRadius: '50%', transition: 'background 0.2s', backgroundColor: activeWidget === 'achievements' ? '#eee' : 'transparent' }}
                >
                    <MedalIcon />
                </button>
            </div>

            {/* Dropdown Panel */}
            {activeWidget && (
                <div className="widget-dropdown" style={{
                    position: 'fixed',
                    top: '80px',
                    right: '20px',
                    width: '350px',
                    maxHeight: 'calc(100vh - 100px)',
                    overflowY: 'auto',
                    background: 'var(--card-bg)', // Should be respected if !important isn't overriding or vice versa
                    backdropFilter: 'blur(12px)',
                    borderRadius: '12px',
                    boxShadow: '0 10px 30px rgba(0,0,0,0.15)',
                    border: '1px solid rgba(255,255,255,0.5)',
                    padding: '20px',
                    zIndex: 10000,
                    animation: 'slideDown 0.2s ease-out'
                }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                        <span style={{ fontWeight: '800', color: 'var(--text-secondary)', fontSize: '0.7rem', letterSpacing: '0.1em' }}>TOOLKIT</span>
                        <button onClick={() => setActiveWidget(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.2rem' }}>×</button>
                    </div>

                    {activeWidget === 'receipt' && <ReceiptScanner />}
                    {activeWidget === 'impact' && <CommunityImpact countryId={selectedCountryId} />}
                    {activeWidget === 'challenges' && <NeighborhoodChallenges countryId={selectedCountryId} />}
                    {activeWidget === 'emergency' && <EcoEmergency countryId={selectedCountryId} />}
                    {activeWidget === 'achievements' && <AchievementsWidget countryId={selectedCountryId} />}
                </div>
            )}
        </div>
    )
}
