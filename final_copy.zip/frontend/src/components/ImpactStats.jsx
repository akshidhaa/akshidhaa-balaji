import { Droplets, Leaf, TrendingUp } from 'lucide-react'

export default function ImpactStats({ stats, aiInsight }) {
    if (!stats) return null;

    return (
        <div className="premium-card fade-in">
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '1.5rem' }}>
                <TrendingUp size={20} color="var(--accent)" />
                <h3 style={{ margin: 0, fontSize: '1.1rem' }}>My Environmental Impact</h3>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
                <div style={{ background: 'var(--accent-soft)', padding: '1.5rem', borderRadius: '12px', textAlign: 'center' }}>
                    <div style={{ color: 'var(--accent)', marginBottom: '8px', display: 'flex', justifyContent: 'center' }}>
                        <Leaf size={24} />
                    </div>
                    <div style={{ fontSize: '2rem', fontWeight: '800', color: 'var(--text-primary)', lineHeight: 1 }}>
                        {stats.co2_saved}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '4px', fontWeight: '600' }}>
                        KG CO₂ SAVED
                    </div>
                </div>

                <div style={{ background: 'rgba(59, 130, 246, 0.1)', padding: '1.5rem', borderRadius: '12px', textAlign: 'center' }}>
                    <div style={{ color: '#3b82f6', marginBottom: '8px', display: 'flex', justifyContent: 'center' }}>
                        <Droplets size={24} />
                    </div>
                    <div style={{ fontSize: '2rem', fontWeight: '800', color: 'var(--text-primary)', lineHeight: 1 }}>
                        {stats.water_conserved}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '4px', fontWeight: '600' }}>
                        LITERS WATER
                    </div>
                </div>
            </div>

            {aiInsight && (
                <div style={{ background: 'var(--bg-color)', padding: '1rem', borderRadius: '12px', fontSize: '0.85rem', color: 'var(--text-secondary)', border: '1px solid var(--border-color)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--accent)', fontWeight: '700', marginBottom: '4px' }}>
                        <TrendingUp size={14} />
                        AI ANALYSIS
                    </div>
                    {aiInsight}
                </div>
            )}
        </div>
    )
}
