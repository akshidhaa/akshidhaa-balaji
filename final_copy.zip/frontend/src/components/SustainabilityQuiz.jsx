import { useState, useEffect } from 'react'
import { HelpCircle, CheckCircle2, XCircle, Sparkles } from 'lucide-react'

const QUIZ_QUESTIONS = [
    {
        question: "Which of these has the highest carbon footprint per kg of product?",
        options: ["Beef", "Chicken", "Tofu", "Lentils"],
        correct: 0,
        explanation: "Beef production generates about 60kg of CO2 per kg of meat, significantly higher than plant-based proteins."
    },
    {
        question: "How much plastic and trash ends up in the world's oceans every year?",
        options: ["1 million tons", "8 million tons", "500,000 tons", "10 million tons"],
        correct: 1,
        explanation: "Over 8 million tons of plastic enter our oceans annually, harming marine life and ecosystems."
    },
    {
        question: "Which sector is responsible for the most global greenhouse gas emissions?",
        options: ["Transportation", "Agriculture", "Energy (Electricity & Heat)", "Manufacturing"],
        correct: 2,
        explanation: "The energy sector is responsible for roughly 73% of global emissions."
    },
    {
        question: "How much water does it take to produce a single cotton T-shirt?",
        options: ["100 liters", "500 liters", "2,700 liters", "1,000 liters"],
        correct: 2,
        explanation: "It takes about 2,700 liters of water to produce one cotton T-shirt—enough for one person to drink for 2.5 years."
    },
    {
        question: "What percentage of global food produced for human consumption is wasted?",
        options: ["10%", "20%", "33%", "50%"],
        correct: 2,
        explanation: "Approximately one-third (33%) of all food produced is lost or wasted, contributing heavily to emissions."
    }
]

export default function SustainabilityQuiz() {
    const [dailyQuestion, setDailyQuestion] = useState(null)
    const [selectedOption, setSelectedOption] = useState(null)
    const [isCorrect, setIsCorrect] = useState(null)
    const [showExplanation, setShowExplanation] = useState(false)

    useEffect(() => {
        // Simple day-to-day variation logic using the current date
        const today = new Date();
        const dayOfYear = Math.floor((today - new Date(today.getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24));
        const questionIndex = dayOfYear % QUIZ_QUESTIONS.length;
        setDailyQuestion(QUIZ_QUESTIONS[questionIndex]);

        // Reset state if it's a new day (mocked by index check)
        const savedIndex = localStorage.getItem('last_quiz_idx');
        const savedDate = localStorage.getItem('last_quiz_date');
        const todayStr = today.toDateString();

        if (savedDate === todayStr) {
            const savedChoice = localStorage.getItem('quiz_choice');
            if (savedChoice !== null) {
                const choiceIdx = parseInt(savedChoice);
                setSelectedOption(choiceIdx);
                setIsCorrect(choiceIdx === QUIZ_QUESTIONS[questionIndex].correct);
                setShowExplanation(true);
            }
        } else {
            localStorage.setItem('last_quiz_idx', questionIndex);
            localStorage.setItem('last_quiz_date', todayStr);
            localStorage.removeItem('quiz_choice');
        }
    }, [])

    const handleSelect = (idx) => {
        if (selectedOption !== null) return;

        setSelectedOption(idx);
        const correct = idx === dailyQuestion.correct;
        setIsCorrect(correct);
        setShowExplanation(true);
        localStorage.setItem('quiz_choice', idx);
    }

    if (!dailyQuestion) return null;

    return (
        <div className="premium-card fade-in" style={{
            background: 'var(--card-bg)',
            border: '1px solid var(--border-color)',
            display: 'flex',
            flexDirection: 'column',
            gap: '1.5rem'
        }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{
                    background: 'var(--accent-soft)',
                    color: 'var(--accent)',
                    padding: '8px',
                    borderRadius: '10px',
                    display: 'flex'
                }}>
                    <HelpCircle size={20} />
                </div>
                <div>
                    <h3 style={{ margin: 0, fontSize: '1.1rem' }}>Daily Eco-Quiz</h3>
                    <p style={{ margin: 0, fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: '600' }}>TEST YOUR KNOWLEDGE</p>
                </div>
            </div>

            <div style={{ fontSize: '1.05rem', fontWeight: '700', color: 'var(--text-primary)', lineHeight: '1.4' }}>
                {dailyQuestion.question}
            </div>

            <div style={{ display: 'grid', gap: '10px' }}>
                {dailyQuestion.options.map((option, idx) => {
                    let bgColor = 'var(--bg-color)';
                    let borderColor = 'var(--border-color)';
                    let textColor = 'var(--text-primary)';

                    if (selectedOption !== null) {
                        if (idx === dailyQuestion.correct) {
                            bgColor = 'rgba(16, 185, 129, 0.1)';
                            borderColor = '#10b981';
                            textColor = '#10b981';
                        } else if (idx === selectedOption) {
                            bgColor = 'rgba(239, 68, 68, 0.1)';
                            borderColor = '#ef4444';
                            textColor = '#ef4444';
                        }
                    }

                    return (
                        <button
                            key={idx}
                            onClick={() => handleSelect(idx)}
                            disabled={selectedOption !== null}
                            style={{
                                padding: '12px 16px',
                                borderRadius: '12px',
                                border: `1px solid ${borderColor}`,
                                background: bgColor,
                                color: textColor,
                                textAlign: 'left',
                                fontSize: '0.9rem',
                                fontWeight: '600',
                                cursor: selectedOption === null ? 'pointer' : 'default',
                                transition: 'all 0.2s ease',
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center'
                            }}
                        >
                            {option}
                            {selectedOption !== null && idx === dailyQuestion.correct && <CheckCircle2 size={16} />}
                            {selectedOption !== null && idx === selectedOption && idx !== dailyQuestion.correct && <XCircle size={16} />}
                        </button>
                    )
                })}
            </div>

            {showExplanation && (
                <div style={{
                    padding: '1rem',
                    background: 'var(--bg-color)',
                    borderRadius: '12px',
                    border: '1px solid var(--border-color)',
                    animation: 'fadeIn 0.5s ease'
                }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--accent)', fontWeight: '800', fontSize: '0.75rem', marginBottom: '8px', textTransform: 'uppercase' }}>
                        <Sparkles size={14} />
                        Did you know?
                    </div>
                    <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
                        {dailyQuestion.explanation}
                    </div>
                </div>
            )}
        </div>
    )
}
