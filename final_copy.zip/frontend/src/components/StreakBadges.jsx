import { Award, Lock, Star } from 'lucide-react'

export default function StreakBadges({ badges, aiInsight }) {
    if (!badges) return null;

    const completedBadges = badges.filter(b => b.completed);
    const lockedBadges = badges.filter(b => !b.completed);

    return (
        <div className="premium-card fade-in">
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '1.5rem' }}>
                <Award size={20} color="var(--accent)" />
                <h3 style={{ margin: 0, fontSize: '1.1rem' }}>Unlocked Achievements</h3>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '1rem' }}>
                {completedBadges.map((badge, index) => (
                    <div key={index} style={{
                        background: 'var(--accent-soft)',
                        padding: '1rem',
                        borderRadius: '16px',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: '8px',
                        border: '1px solid var(--accent)',
                        position: 'relative',
                        overflow: 'hidden'
                    }}>
                        <div style={{ position: 'absolute', top: '-5px', right: '-5px', opacity: 0.1 }}>
                            <Star size={40} fill="var(--accent)" color="var(--accent)" />
                        </div>
                        <div style={{ fontSize: '2rem' }}>{badge.icon}</div>
                        <div style={{ fontWeight: '800', fontSize: '0.85rem', textAlign: 'center' }}>{badge.name}</div>
                        <div style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', textAlign: 'center' }}>{badge.desc}</div>
                    </div>
                ))}

                {lockedBadges.slice(0, 1).map((badge, index) => (
                    <div key={index} style={{
                        background: 'var(--bg-color)',
                        padding: '1rem',
                        borderRadius: '16px',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: '8px',
                        border: '1px dashed var(--border-color)',
                        opacity: 0.7
                    }}>
                        <Lock size={24} color="var(--text-secondary)" style={{ marginBottom: '4px' }} />
                        <div style={{ fontWeight: '600', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Next Milestone</div>
                        <div style={{ fontSize: '0.65rem', color: 'var(--text-secondary)', textAlign: 'center' }}>{badge.desc}</div>
                    </div>
                ))}
            </div>

            {aiInsight && (
                <div style={{
                    marginTop: '1.5rem',
                    padding: '1rem',
                    background: 'var(--accent-soft)',
                    color: 'var(--text-primary)',
                    borderRadius: '12px',
                    fontSize: '0.85rem',
                    border: '1px solid var(--accent)',
                    display: 'flex',
                    gap: '10px'
                }}>
                    <Star size={18} fill="var(--accent)" color="var(--accent)" style={{ flexShrink: 0 }} />
                    <div>
                        <span style={{ fontWeight: '800', display: 'block', marginBottom: '2px', fontSize: '0.7rem', color: 'var(--accent)' }}>STRATEGIC ACHIEVEMENT INSIGHT</span>
                        {aiInsight}
                    </div>
                </div>
            )}
        </div>
    )
}
