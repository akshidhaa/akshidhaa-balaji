import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FaGlobe, FaBullseye, FaTemperatureHigh, FaRecycle, FaSolarPanel, FaLeaf, FaCity, FaUsers, FaArrowLeft } from 'react-icons/fa';

const iconMap = {
    globe: FaGlobe,
    bullseye: FaBullseye,
    'temperature-high': FaTemperatureHigh,
    recycle: FaRecycle,
    'solar-panel': FaSolarPanel,
    leaf: FaLeaf,
    city: FaCity,
    users: FaUsers
};

const AboutWidget = () => {
    const [content, setContent] = useState(null);
    const [selectedTopic, setSelectedTopic] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        axios.get('/api/about/content')
            .then(res => {
                setContent(res.data);
                setLoading(false);
            })
            .catch(err => {
                console.error("Error fetching about content:", err);
                setLoading(false);
            });
    }, []);

    if (loading) return <div className="widget-container">Loading...</div>;
    if (!content) return <div className="widget-container">Failed to load content.</div>;

    const handleTopicClick = (topic) => {
        setSelectedTopic(topic);
    };

    const goBack = () => {
        setSelectedTopic(null);
    };

    // --- VIEW: TOPIC DETAIL ---
    if (selectedTopic) {
        return (
            <div className="widget-container full-width-widget" style={{ padding: '0', background: 'var(--bg-color)' }}>
                <div
                    className="detail-header"
                    style={{
                        backgroundImage: `url(${selectedTopic.image})`,
                        backgroundPosition: 'center',
                        backgroundSize: 'cover',
                        backgroundColor: selectedTopic.color // Use category color as the solid fallback
                    }}
                >
                    <div className="overlay">
                        <button className="back-btn-overlay" onClick={goBack}>
                            <FaArrowLeft /> Back
                        </button>
                        <h1>{selectedTopic.title}</h1>
                    </div>
                </div>

                <div className="detail-content-wrapper">
                    <div
                        className="detail-body"
                        dangerouslySetInnerHTML={{ __html: selectedTopic.full_content }}
                    />
                </div>

                <style>{`
                    .detail-header {
                        height: 400px;
                        background-size: cover;
                        background-position: center;
                        position: relative;
                    }
                    .overlay {
                        background: rgba(0,0,0,0.5);
                        width: 100%;
                        height: 100%;
                        display: flex;
                        flex-direction: column;
                        justify-content: center;
                        align-items: center;
                        color: white;
                    }
                    .overlay h1 {
                        font-size: 3.5rem;
                        text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
                        margin-top: 2rem;
                    }
                    .back-btn-overlay {
                        position: absolute;
                        top: 20px;
                        left: 20px;
                        background: rgba(255,255,255,0.2);
                        border: 1px solid rgba(255,255,255,0.5);
                        color: white;
                        display: flex;
                        align-items: center;
                        gap: 0.5rem;
                        padding: 0.5rem 1rem;
                        border-radius: 20px;
                        cursor: pointer;
                        backdrop-filter: blur(5px);
                        transition: background 0.2s;
                    }
                    .back-btn-overlay:hover {
                        background: rgba(255,255,255,0.4);
                    }
                    .detail-content-wrapper {
                        max-width: 900px;
                        margin: -60px auto 40px;
                        background: var(--card-bg);
                        border-radius: 12px;
                        padding: 3rem;
                        box-shadow: var(--shadow-lg);
                        border: 1px solid var(--border-color);
                        position: relative;
                        z-index: 10;
                    }
                    .detail-body {
                        font-size: 1.1rem;
                        line-height: 1.8;
                        color: var(--text-primary);
                    }
                    .detail-body h2 {
                        color: var(--text-primary);
                        margin-top: 2rem;
                        margin-bottom: 1rem;
                        font-size: 1.8rem;
                    }
                    .detail-body h3 {
                        color: var(--accent);
                        margin-top: 1.5rem;
                        margin-bottom: 0.8rem;
                        font-size: 1.4rem;
                    }
                    .detail-body p {
                        margin-bottom: 1.2rem;
                    }
                    .detail-body ul, .detail-body ol {
                        margin-bottom: 1.5rem;
                        padding-left: 1.5rem;
                    }
                    .detail-body li {
                        margin-bottom: 0.5rem;
                        color: var(--text-secondary);
                    }
                    .sdg-dropdowns {
                        margin: 2rem 0;
                    }
                    .sdg-dropdowns details {
                        background: var(--card-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        margin-bottom: 1rem;
                        transition: all 0.3s ease;
                        overflow: hidden;
                    }
                    .sdg-dropdowns details[open] {
                        border-color: var(--accent);
                        box-shadow: 0 4px 12px var(--accent-soft);
                    }
                    .sdg-dropdowns summary {
                        padding: 1rem 1.5rem;
                        font-weight: 600;
                        color: var(--text-primary);
                        cursor: pointer;
                        list-style: none;
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                        transition: background 0.2s;
                        position: relative;
                    }
                    .sdg-dropdowns summary::-webkit-details-marker {
                        display: none;
                    }
                    .sdg-dropdowns summary::after {
                        content: '→';
                        font-family: serif;
                        font-size: 1.2rem;
                        transition: transform 0.3s ease;
                        color: var(--accent);
                    }
                    .sdg-dropdowns details[open] summary::after {
                        transform: rotate(90deg);
                    }
                    .sdg-dropdowns summary:hover {
                        background: var(--accent-soft);
                    }
                    .sdg-dropdown-content {
                        display: flex;
                        gap: 1.5rem;
                        padding: 1.5rem;
                        align-items: flex-start;
                        border-top: 1px solid var(--border-color);
                        background: var(--card-bg);
                    }
                    .sdg-mini-img {
                        width: 120px;
                        height: 90px;
                        object-fit: cover;
                        border-radius: 6px;
                        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                        flex-shrink: 0;
                        background: linear-gradient(135deg, #e0f2f1 0%, #b2dfdb 100%); /* Elegant aqua gradient */
                        position: relative;
                    }
                    /* Subtle pattern when image is missing */
                    .sdg-mini-img:before {
                        content: '☘';
                        position: absolute;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        font-size: 2rem;
                        color: rgba(255,255,255,0.5);
                    }
                    .sdg-dropdown-content p {
                        margin: 0;
                        color: var(--text-secondary);
                        font-size: 0.95rem;
                        line-height: 1.6;
                        padding: 0; /* Override default p padding */
                        border-top: none; /* Override default border */
                    }
                    @media (max-width: 600px) {
                        .sdg-dropdown-content {
                            flex-direction: column;
                        }
                        .sdg-mini-img {
                            width: 100%;
                            height: 150px;
                        }
                    }
                `}</style>
            </div>
        );
    }

    // --- VIEW: CARDS GRID (Full Green Background) ---
    return (
        <div className="about-split-container">
            <div className="cards-content-layer">
                <h2 className="section-title">Explore Sustainability</h2>

                <div className="cards-grid">
                    {content.topics.map(topic => {
                        const IconComponent = iconMap[topic.icon] || FaGlobe;
                        return (
                            <div key={topic.id} className="floating-card">
                                <div className="card-image-container">
                                    <img
                                        src={topic.image}
                                        alt={topic.title}
                                        className="card-banner-img"
                                        referrerPolicy="no-referrer"
                                        onError={(e) => {
                                            e.target.style.opacity = '0'; // Hide the broken image smoothly
                                            e.target.parentElement.style.background = `linear-gradient(135deg, ${topic.color}22 0%, ${topic.color}44 100%)`; // Use a tinted background of the theme color
                                        }}
                                    />
                                    <div className="card-icon-circle" style={{ backgroundColor: topic.color }}>
                                        <IconComponent />
                                    </div>
                                </div>
                                <h3 className="card-title">{topic.title}</h3>
                                <p className="card-desc">{topic.short_desc}</p>
                                <button className="more-btn" onClick={() => handleTopicClick(topic)}>
                                    MORE
                                </button>
                            </div>
                        );
                    })}
                </div>
            </div>

            <style>{`
                .about-split-container {
                    position: relative;
                    min-height: calc(100vh - 80px); /* Adjust based on navbar height */
                    width: 100%;
                    background: linear-gradient(135deg, #78C2AD 0%, #4CA1AF 100%); /* Full Green Gradient */
                    overflow: auto; /* Allow scrolling content */
                    padding-bottom: 4rem;
                }
                .cards-content-layer {
                    position: relative;
                    z-index: 2;
                    max-width: 1400px;
                    margin: 0 auto;
                    padding: 3rem 2rem;
                }
                .section-title {
                    text-align: center;
                    font-size: 2.5rem;
                    color: white; /* White text on green background */
                    margin-bottom: 4rem;
                    font-weight: 800;
                    letter-spacing: 1px;
                    text-shadow: 0 2px 4px rgba(0,0,0,0.1);
                }
                .cards-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
                    gap: 2.5rem;
                    justify-content: center;
                }
                .floating-card {
                    background: var(--card-bg);
                    padding: 0; /* Remove padding for image layout */
                    border-radius: 12px;
                    box-shadow: var(--shadow-md);
                    border: 1px solid var(--border-color);
                    text-align: center;
                    position: relative;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    transition: transform 0.3s ease, box-shadow 0.3s ease;
                    overflow: hidden; /* Clip image corners */
                }
                .floating-card:hover {
                    transform: translateY(-10px);
                    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
                }
                .card-image-container {
                    width: 100%;
                    height: 180px;
                    position: relative;
                }
                .card-banner-img {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                }
                .card-icon-circle {
                    position: absolute;
                    bottom: -30px; /* Float partially over image and content */
                    left: 50%;
                    transform: translateX(-50%);
                    width: 70px;
                    height: 70px;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: white;
                    font-size: 1.8rem;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
                    border: 4px solid white;
                    z-index: 5;
                }
                .card-title {
                    margin-top: 40px; /* Space for icon overflow */
                    margin-bottom: 0.5rem;
                    padding: 0 1rem;
                    font-size: 1.1rem;
                    font-weight: 700;
                    letter-spacing: 1px;
                    text-transform: uppercase;
                    color: var(--text-primary);
                }
                .card-desc {
                    padding: 0 1.5rem 1.5rem;
                    color: var(--text-secondary);
                    font-size: 0.9rem;
                    line-height: 1.5;
                    font-style: italic;
                    margin-bottom: 1rem;
                }
                .more-btn {
                    background: none;
                    border: none;
                    border-bottom: 2px solid var(--text-primary);
                    padding-bottom: 2px;
                    font-weight: 700;
                    text-transform: uppercase;
                    letter-spacing: 1px;
                    cursor: pointer;
                    font-size: 0.9rem;
                    color: var(--text-primary);
                    transition: all 0.2s;
                    margin-bottom: 1.5rem;
                }
                .more-btn:hover {
                    color: var(--accent);
                    border-color: var(--accent);
                }
            `}</style>
        </div>
    );
};

export default AboutWidget;
