import { useState, useEffect } from 'react'
import axios from 'axios'
import { Sun, Wind, Search, ChevronDown, MapPin, Sparkles } from 'lucide-react'
import { Line } from 'react-chartjs-2'
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    Title,
    Tooltip,
    Legend
} from 'chart.js';

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    Title,
    Tooltip,
    Legend
);

export default function CountriesWidget({ selectedCountryId, setSelectedCountryId, aiInsight }) {
    const [countries, setCountries] = useState([])
    const [countryData, setCountryData] = useState(null)
    const [expanded, setExpanded] = useState(false)
    const [searchTerm, setSearchTerm] = useState('')

    // Fetch available countries
    useEffect(() => {
        axios.get('/api/countries')
            .then(res => {
                setCountries(res.data)
                if (res.data.length > 0 && !selectedCountryId) {
                    setSelectedCountryId(res.data[0].id)
                }
            })
            .catch(err => console.error(err))
    }, [])

    // Fetch specific country data when selection changes
    useEffect(() => {
        if (!selectedCountryId) return;
        axios.get(`/api/country/${selectedCountryId}`)
            .then(res => setCountryData(res.data))
            .catch(err => console.error(err))
    }, [selectedCountryId])

    if (!countryData) return <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-secondary)' }}>Analyzing region...</div>

    const filteredCountries = countries.filter(c =>
        c.name.toLowerCase().includes(searchTerm.toLowerCase())
    )

    const renderTrendGraph = () => {
        if (!countryData.trend_data) return <p>No data</p>;
        const data = {
            labels: countryData.trend_data.years,
            datasets: [
                {
                    label: 'Clean Energy',
                    data: countryData.trend_data.renewables,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0
                },
                {
                    label: 'Fossil Fuels',
                    data: countryData.trend_data.coal,
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0
                },
            ],
        };

        const options = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                }
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Year',
                        color: 'var(--text-secondary)',
                        font: { size: 10, weight: 'bold' }
                    },
                    grid: { display: false },
                    ticks: { color: 'var(--text-secondary)', font: { size: 10 } }
                },
                y: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Percentage (%)',
                        color: 'var(--text-secondary)',
                        font: { size: 10, weight: 'bold' }
                    },
                    grid: { color: 'var(--border-color)', borderDash: [4, 4] },
                    ticks: { color: 'var(--text-secondary)', font: { size: 10 } }
                }
            }
        };
        return <div style={{ height: '120px', width: '100%', marginTop: '10px' }}><Line options={options} data={data} /></div>
    }

    return (
        <div className="fade-in">
            {/* Country Selector */}
            <div style={{ position: 'relative', marginBottom: '1.5rem' }}>
                <button
                    onClick={() => setExpanded(!expanded)}
                    style={{
                        background: 'var(--bg-color)',
                        border: '1px solid var(--border-color)',
                        padding: '12px 16px',
                        borderRadius: '12px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        width: '100%',
                        cursor: 'pointer',
                        transition: 'var(--transition)'
                    }}
                >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <img src={countryData.flag} alt={countryData.name} style={{ width: '24px', height: '16px', objectFit: 'cover', borderRadius: '2px' }} />
                        <span style={{ fontWeight: '700', color: 'var(--text-primary)' }}>{countryData.name}</span>
                    </div>
                    <ChevronDown size={18} color="var(--text-secondary)" />
                </button>

                {expanded && (
                    <div style={{
                        position: 'absolute', top: '110%', left: 0, width: '240px', background: 'var(--card-bg)',
                        borderRadius: '16px', boxShadow: 'var(--shadow-lg)', zIndex: 1000,
                        padding: '12px', animation: 'fadeIn 0.2s', border: '1px solid var(--border-color)'
                    }}>
                        <div style={{ display: 'flex', alignItems: 'center', background: 'var(--bg-color)', borderRadius: '10px', padding: '8px 12px', marginBottom: '12px' }}>
                            <Search size={16} color="var(--text-secondary)" />
                            <input
                                type="text" placeholder="Search countries..." autoFocus
                                value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                                style={{ border: 'none', background: 'transparent', marginLeft: '10px', width: '100%', outline: 'none', fontSize: '0.9rem', color: 'var(--text-primary)' }}
                            />
                        </div>
                        <div style={{ maxHeight: '200px', overflowY: 'auto' }}>
                            {filteredCountries.map(c => (
                                <div key={c.id}
                                    onClick={() => { setSelectedCountryId(c.id); setExpanded(false); setSearchTerm(''); }}
                                    style={{
                                        padding: '10px 12px', cursor: 'pointer', borderRadius: '8px', display: 'flex', alignItems: 'center', gap: '12px',
                                        background: selectedCountryId === c.id ? 'var(--accent-soft)' : 'transparent',
                                        color: selectedCountryId === c.id ? 'var(--accent)' : 'var(--text-primary)',
                                        transition: 'all 0.2s'
                                    }}
                                >
                                    <img src={c.flag} alt={c.name} style={{ width: '20px', height: '12px', objectFit: 'cover', borderRadius: '2px' }} />
                                    <span style={{ fontWeight: '600', fontSize: '0.9rem' }}>{c.name}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            {/* Live Meter Concept */}
            <div style={{ background: 'var(--bg-color)', padding: '1.25rem', borderRadius: '16px', marginBottom: '1.5rem', border: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '1rem' }}>
                    <div style={{ width: '8px', height: '8px', background: countryData.environment_status === 'Good' ? '#10b981' : '#f59e0b', borderRadius: '50%', boxShadow: `0 0 10px ${countryData.environment_status === 'Good' ? '#10b981' : '#f59e0b'}` }}></div>
                    <span style={{ fontSize: '0.75rem', fontWeight: '800', color: 'var(--text-secondary)', letterSpacing: '0.05em' }}>REGIONAL ENV STATUS</span>
                </div>
                <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-primary)' }}>
                    {countryData.environment_status.toUpperCase()}
                </div>
                <p style={{ margin: '4px 0 0 0', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                    Based on real-time satellite telemetry data.
                </p>
            </div>

            {/* Quick Stats Grid */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
                <div style={{ background: 'var(--accent-soft)', borderRadius: '12px', padding: '12px', border: '1px solid var(--accent)' }}>
                    <div style={{ fontSize: '0.65rem', color: 'var(--accent)', fontWeight: '800', marginBottom: '8px', textTransform: 'uppercase' }}>Renewables</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <Sun size={18} color="var(--accent)" />
                        <span style={{ fontWeight: '800', fontSize: '1.25rem', color: 'var(--text-primary)' }}>{countryData.renewable_progress}%</span>
                    </div>
                </div>
                <div style={{ background: 'rgba(239, 68, 68, 0.05)', borderRadius: '12px', padding: '12px', border: '1px solid rgba(239, 68, 68, 0.2)' }}>
                    <div style={{ fontSize: '0.65rem', color: '#ef4444', fontWeight: '800', marginBottom: '8px', textTransform: 'uppercase' }}>Fossil Flow</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <Wind size={18} color="#ef4444" />
                        <span style={{ fontWeight: '800', fontSize: '1.25rem', color: 'var(--text-primary)' }}>{countryData.coal_dependency}%</span>
                    </div>
                </div>
            </div>

            {/* AI Context */}
            {aiInsight && (
                <div style={{ padding: '1rem', background: 'var(--card-bg)', borderRadius: '12px', fontSize: '0.85rem', color: 'var(--text-secondary)', border: '1px solid var(--border-color)', position: 'relative' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--accent)', fontWeight: '800', fontSize: '0.7rem', marginBottom: '6px', textTransform: 'uppercase' }}>
                        <Sparkles size={12} />
                        Regional Intelligence
                    </div>
                    {aiInsight}
                </div>
            )}

            {/* Trend Graph */}
            <div style={{ marginTop: '1.5rem' }}>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', fontWeight: '800', textTransform: 'uppercase', letterSpacing: '0.05em' }}>5-Year Energy Mix Trend</div>
                {renderTrendGraph()}
            </div>
        </div>
    )
}
