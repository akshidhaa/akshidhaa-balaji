import { useState, useEffect } from 'react'
import axios from 'axios'
import { Trophy, Users, Star, Medal, TrendingUp } from 'lucide-react'

export default function Leaderboard({ aiInsight }) {
    const [players, setPlayers] = useState([
        { name: "EcoWarrior_99", points: 2450, rank: 1, trend: 'up' },
        { name: "GreenQueen", points: 2100, rank: 2, trend: 'stable' },
        { name: "SolarSam", points: 1950, rank: 3, trend: 'down' },
        { name: "NatureNerd", points: 1800, rank: 4, trend: 'up' },
        { name: "CarbonKiller", points: 1650, rank: 5, trend: 'stable' }
    ])

    return (
        <div className="fade-in">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {players.map((player, idx) => (
                    <div key={idx} style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                        padding: '0.75rem',
                        borderRadius: '12px',
                        background: idx === 0 ? 'var(--accent-soft)' : 'var(--bg-color)',
                        border: idx === 0 ? '1px solid var(--accent)' : '1px solid var(--border-color)',
                        transition: 'var(--transition)'
                    }}>
                        <div style={{
                            width: '32px',
                            height: '32px',
                            borderRadius: '50%',
                            background: idx < 3 ? 'var(--primary)' : 'var(--bg-color)',
                            color: idx < 3 ? 'white' : 'var(--text-secondary)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontWeight: '800',
                            fontSize: '0.8rem',
                            border: idx >= 3 ? '1px solid var(--border-color)' : 'none'
                        }}>
                            {idx === 0 ? <Medal size={16} color="#f59e0b" /> : idx + 1}
                        </div>

                        <div style={{ flex: 1 }}>
                            <div style={{ fontWeight: '700', fontSize: '0.9rem', color: 'var(--text-primary)' }}>
                                {player.name}
                                {idx === 0 && <span style={{ marginLeft: '6px', fontSize: '0.7rem', color: 'var(--accent)', fontWeight: '800' }}>LEVEL 24</span>}
                            </div>
                            <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                                <Users size={10} />
                                Globally Tracked
                            </div>
                        </div>

                        <div style={{ textAlign: 'right' }}>
                            <div style={{ fontWeight: '800', fontSize: '1rem', color: 'var(--text-primary)' }}>
                                {player.points.toLocaleString()}
                            </div>
                            <div style={{ fontSize: '0.65rem', fontWeight: '800', color: player.trend === 'up' ? 'var(--accent)' : 'var(--text-secondary)', textTransform: 'uppercase' }}>
                                {player.points} XP
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {aiInsight && (
                <div style={{
                    marginTop: '1.25rem',
                    padding: '1rem',
                    background: 'var(--bg-color)',
                    borderRadius: '12px',
                    fontSize: '0.8rem',
                    color: 'var(--text-secondary)',
                    border: '1px solid var(--border-color)',
                    display: 'flex',
                    gap: '8px'
                }}>
                    <TrendingUp size={14} color="var(--accent)" style={{ flexShrink: 0, marginTop: '2px' }} />
                    <p style={{ margin: 0, lineHeight: '1.4' }}>
                        <span style={{ fontWeight: '800', color: 'var(--text-primary)' }}>AI LEADERBOARD ANALYSIS:</span> {aiInsight}
                    </p>
                </div>
            )}
        </div>
    )
}
