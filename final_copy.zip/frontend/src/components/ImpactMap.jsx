import { useState, useEffect } from 'react'
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'
import axios from 'axios'
import L from 'leaflet'

// Color markers generator
const getColoredIcon = (status) => {
    let color = '#7f8c8d';
    if (status.includes('Green')) color = '#2ecc71';
    if (status.includes('Orange')) color = '#f39c12';
    if (status.includes('Red')) color = '#e74c3c';

    return new L.DivIcon({
        className: 'custom-div-icon',
        html: `<div style="background-color:${color}; width:30px; height:30px; border-radius:50%; border:3px solid white; box-shadow:0 4px 15px rgba(0,0,0,0.3); display:flex; align-items:center; justify-content:center; color:white; font-size:12px; font-weight:bold; animation: pulse 2s infinite;"></div>`,
        iconSize: [30, 30],
        iconAnchor: [15, 15]
    });
};

function MapViewHandler({ center, zoom }) {
    const map = useMap();
    useEffect(() => {
        if (center) {
            map.flyTo(center, zoom, {
                duration: 2.5
            });
        }
    }, [center, zoom, map]);
    return null;
}

export default function ImpactMap() {
    const [neighbors, setNeighbors] = useState([])
    const [searchName, setSearchName] = useState('')
    const [locationInput, setLocationInput] = useState('')
    const [mapState, setMapState] = useState({
        center: [20, 0],
        zoom: 2
    })
    const [isLoading, setIsLoading] = useState(false)

    useEffect(() => {
        // Initial global data fetch
        axios.get('/api/impact-map')
            .then(res => setNeighbors(res.data))
            .catch(err => console.error(err))
    }, [])

    const handleSearch = async (e) => {
        e.preventDefault();
        if (!locationInput) return;
        setIsLoading(true);

        try {
            // Geocoding with Nominatim
            const geoRes = await axios.get(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(locationInput)}`);
            if (geoRes.data && geoRes.data.length > 0) {
                const { lat, lon } = geoRes.data[0];
                const newLat = parseFloat(lat);
                const newLng = parseFloat(lon);

                setMapState({
                    center: [newLat, newLng],
                    zoom: 14 // Neighborhood level zoom
                });

                // Fetch dynamic "neighbors" around this location
                const neighborsRes = await axios.get(`/api/impact-map?lat=${newLat}&lng=${newLng}`);
                setNeighbors(neighborsRes.data);
            } else {
                alert("Location not found! Try searching for a city or country.");
            }
        } catch (err) {
            console.error("Search failed", err);
            alert("Error locating area. Please try again.");
        } finally {
            setIsLoading(false);
        }
    }

    return (
        <div className="impact-map-container" style={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: '800px', background: 'var(--bg-color)', padding: '20px' }}>

            {/* Control Panel Box: Name and Region */}
            <div className="impact-controls-box" style={{
                background: 'var(--card-bg)',
                padding: '25px',
                borderRadius: '20px',
                boxShadow: 'var(--shadow-lg)',
                marginBottom: '20px',
                border: '1px solid var(--border-color)'
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '20px' }}>
                    <div style={{ fontSize: '2.5rem' }}>🌍</div>
                    <div>
                        <h2 style={{ margin: 0, color: 'var(--text-primary)', fontSize: '1.8rem' }}>Neighborhood Impact Map</h2>
                        <p style={{ margin: 0, color: 'var(--text-secondary)' }}>Locate your impact and see your neighbors' sustainability score</p>
                    </div>
                </div>

                <form onSubmit={handleSearch} style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr 150px', gap: '15px' }}>
                    <div className="input-group">
                        <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 'bold', color: 'var(--text-secondary)', marginBottom: '8px', textTransform: 'uppercase' }}>Your Name</label>
                        <div style={{ position: 'relative' }}>
                            <span style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', opacity: 0.5 }}>👤</span>
                            <input
                                type="text"
                                placeholder="Enter your name"
                                value={searchName}
                                onChange={(e) => setSearchName(e.target.value)}
                                style={{ width: '100%', padding: '12px 12px 12px 35px', borderRadius: '10px', border: '1px solid var(--border-color)', background: 'var(--bg-color)', color: 'var(--text-primary)', outline: 'none', fontSize: '1rem' }}
                            />
                        </div>
                    </div>
                    <div className="input-group">
                        <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 'bold', color: 'var(--text-secondary)', marginBottom: '8px', textTransform: 'uppercase' }}>Region / Country / City</label>
                        <div style={{ position: 'relative' }}>
                            <span style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', opacity: 0.5 }}>📍</span>
                            <input
                                type="text"
                                placeholder="Search any place in the world..."
                                value={locationInput}
                                onChange={(e) => setLocationInput(e.target.value)}
                                style={{ width: '100%', padding: '12px 12px 12px 35px', borderRadius: '10px', border: '1px solid var(--border-color)', background: 'var(--bg-color)', color: 'var(--text-primary)', outline: 'none', fontSize: '1rem' }}
                                required
                            />
                        </div>
                    </div>
                    <button type="submit" disabled={isLoading} style={{
                        alignSelf: 'end',
                        height: '48px',
                        background: '#2ecc71',
                        color: 'white',
                        border: 'none',
                        borderRadius: '10px',
                        fontWeight: 'bold',
                        cursor: 'pointer',
                        transition: 'all 0.3s',
                        boxShadow: '0 4px 15px rgba(46, 204, 113, 0.3)'
                    }}>
                        {isLoading ? '...' : 'LOCATE'}
                    </button>
                </form>
            </div>

            {/* Legend Bar */}
            <div style={{
                padding: '10px 20px',
                background: 'var(--card-bg)',
                display: 'flex',
                justifyContent: 'center',
                gap: '30px',
                borderRadius: '12px',
                marginBottom: '15px',
                boxShadow: 'var(--shadow-sm)',
                border: '1px solid var(--border-color)'
            }}>
                <div className="legend-item"><span style={{ background: '#2ecc71' }}></span> Radiant (Green)</div>
                <div className="legend-item"><span style={{ background: '#f39c12' }}></span> Improving (Orange)</div>
                <div className="legend-item"><span style={{ background: '#e74c3c' }}></span> Needs Attention (Red)</div>
            </div>


            {/* Map Area */}
            <div style={{ flex: 1, position: 'relative' }}>
                <MapContainer center={mapState.center} zoom={mapState.zoom} scrollWheelZoom={true} style={{ height: '550px', width: '100%' }}>
                    <MapViewHandler center={mapState.center} zoom={mapState.zoom} />
                    <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />

                    {neighbors.map((n, i) => (
                        <Marker key={i} position={[n.lat, n.lng]} icon={getColoredIcon(n.status)}>
                            <Popup>
                                <div style={{ minWidth: '220px', padding: '5px' }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                                        <h3 style={{ margin: 0, fontSize: '1.1rem', color: 'var(--text-primary)' }}>{n.user}</h3>
                                        <div style={{
                                            background: n.score > 80 ? '#2ecc71' : n.score > 50 ? '#f39c12' : '#e74c3c',
                                            color: 'white',
                                            padding: '2px 8px',
                                            borderRadius: '20px',
                                            fontSize: '0.9rem',
                                            fontWeight: 'bold'
                                        }}>
                                            {n.score}
                                        </div>
                                    </div>
                                    <div style={{ fontSize: '0.9rem', color: '#7f8c8d' }}>
                                        <p style={{ margin: '5px 0' }}><strong>Main Impact:</strong> {n.action}</p>
                                        <p style={{ margin: '5px 0' }}><strong>Effort Level:</strong> {n.impact}</p>
                                        <hr style={{ border: 'none', borderTop: '1px solid #eee', margin: '10px 0' }} />
                                        <span style={{
                                            display: 'block',
                                            textAlign: 'center',
                                            fontWeight: 'bold',
                                            color: n.status.includes('Green') ? '#27ae60' : n.status.includes('Orange') ? '#d35400' : '#c0392b'
                                        }}>
                                            {n.status}
                                        </span>
                                    </div>
                                </div>
                            </Popup>
                        </Marker>
                    ))}
                </MapContainer>
            </div>

            <style>{`
                .legend-item {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    font-weight: 600;
                    color: var(--text-primary);
                    font-size: 0.85rem;
                }
                .legend-item span {
                    width: 14px;
                    height: 14px;
                    border-radius: 50%;
                    border: 2px solid white;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
                }
                .leaflet-container {
                    background: #f0f2f5;
                    border-radius: 15px;
                    box-shadow: inset 0 0 20px rgba(0,0,0,0.05);
                }
                .custom-div-icon {
                    background: transparent;
                    border: none;
                }
                @keyframes pulse {
                    0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(0,0,0,0.2); }
                    70% { transform: scale(1.1); box-shadow: 0 0 0 10px rgba(0,0,0,0); }
                    100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(0,0,0,0); }
                }
            `}</style>
        </div>
    )
}
