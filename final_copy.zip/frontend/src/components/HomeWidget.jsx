import { useState, useEffect } from 'react'
import axios from 'axios'
import WorldMap from './WorldMap'
import { SearchIcon } from './Icons'

export default function HomeWidget({ onViewReport }) {
    const [globalData, setGlobalData] = useState([])
    const [selectedCountry, setSelectedCountry] = useState(null)
    const [searchTerm, setSearchTerm] = useState('')
    const [activeTab, setActiveTab] = useState('action_status') // 'action_status' or 'sdg_goals'
    const [selectedSdg, setSelectedSdg] = useState(null) // 'sdg_1', 'sdg_2', etc.

    useEffect(() => {
        axios.get('/api/global-map-data') // Now returns full rankings_db with status & issues
            .then(res => setGlobalData(res.data))
            .catch(err => console.error(err))
    }, [])

    const filteredData = globalData.filter(c =>
        c.name.toLowerCase().startsWith(searchTerm.toLowerCase())
    )

    // SDG Data (Labels & Colors)
    const sdgGoals = Array.from({ length: 17 }, (_, i) => ({
        id: `sdg_${i + 1}`,
        label: `Goal ${i + 1}`,
        icon: `/assets/sdg_icons/sdg${i + 1}.png`, // Assuming icons exist or using placeholders
        color: ['#E5243B', '#DDA63A', '#4C9F38', '#C5192D', '#FF3A21', '#26BDE2', '#FCC30B', '#A21942', '#FD6925', '#DD1367', '#FD9D24', '#BF8B2E', '#3F7E44', '#0A97D9', '#56C02B', '#00689D', '#19486A'][i]
    }));

    return (
        <div className="home-widget-container">
            {/* Hero Section */}
            <div style={{ marginBottom: '20px', textAlign: 'center' }}>
                <h2 style={{ fontSize: '2rem', fontWeight: '800', marginBottom: '10px', color: 'var(--text-primary)' }}>Find Your Country's Impact</h2>
                <p style={{ color: 'var(--text-secondary)', maxWidth: '600px', margin: '0 auto' }}>Explore the sustainable development status of nations worldwide.</p>
            </div>

            {/* Sub-Navigation Tabs */}
            <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', marginBottom: '30px' }}>
                <button
                    onClick={() => { setActiveTab('action_status'); setSelectedSdg(null); }}
                    style={{
                        padding: '10px 25px',
                        borderRadius: '30px',
                        border: 'none',
                        background: activeTab === 'action_status' ? 'var(--accent)' : 'var(--nav-btn-hover)',
                        color: activeTab === 'action_status' ? 'white' : 'var(--text-secondary)',
                        fontWeight: 'bold',
                        cursor: 'pointer',
                        transition: 'all 0.3s'
                    }}
                >
                    SD Action Status
                </button>
                <button
                    onClick={() => setActiveTab('sdg_goals')}
                    style={{
                        padding: '10px 25px',
                        borderRadius: '30px',
                        border: 'none',
                        background: activeTab === 'sdg_goals' ? 'var(--accent)' : 'var(--nav-btn-hover)',
                        color: activeTab === 'sdg_goals' ? 'white' : 'var(--text-secondary)',
                        fontWeight: 'bold',
                        cursor: 'pointer',
                        transition: 'all 0.3s'
                    }}
                >
                    SDG Goals
                </button>
            </div>

            {/* SDG Grid Selector (Only in SDG Goals Tab) */}
            {activeTab === 'sdg_goals' && (
                <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(100px, 1fr))',
                    gap: '10px',
                    marginBottom: '30px',
                    animation: 'fadeIn 0.5s'
                }}>
                    {sdgGoals.map(goal => (
                        <div
                            key={goal.id}
                            onClick={() => setSelectedSdg(goal.id === selectedSdg ? null : goal.id)}
                            style={{
                                background: goal.color,
                                color: 'white',
                                padding: '10px',
                                borderRadius: '8px',
                                cursor: 'pointer',
                                textAlign: 'center',
                                fontSize: '0.8rem',
                                fontWeight: 'bold',
                                opacity: selectedSdg && selectedSdg !== goal.id ? 0.4 : 1,
                                transform: selectedSdg === goal.id ? 'scale(1.05)' : 'scale(1)',
                                transition: 'all 0.2s',
                                boxShadow: selectedSdg === goal.id ? '0 5px 15px rgba(0,0,0,0.2)' : 'none'
                            }}
                        >
                            {goal.label}
                        </div>
                    ))}
                </div>
            )}

            {/* Search Bar (Keep it available) */}
            <div style={{ maxWidth: '500px', margin: '0 auto 30px auto', position: 'relative' }}>
                <div style={{ display: 'flex', alignItems: 'center', background: 'var(--card-bg)', padding: '10px 20px', borderRadius: '30px', boxShadow: 'var(--shadow-md)', border: '2px solid var(--accent)' }}>
                    <SearchIcon color="var(--accent)" />
                    <input
                        type="text"
                        placeholder="Search for a country..."
                        style={{ border: 'none', background: 'transparent', marginLeft: '10px', fontSize: '1rem', width: '100%', outline: 'none', color: 'var(--text-primary)' }}
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                {searchTerm && (
                    <div style={{ position: 'absolute', top: '110%', left: 0, width: '100%', background: 'var(--card-bg)', borderRadius: '15px', padding: '10px', boxShadow: 'var(--shadow-lg)', zIndex: 10000, maxHeight: '300px', overflowY: 'auto', border: '1px solid var(--border-color)' }}>
                        {filteredData.length > 0 ? (
                            filteredData.map(c => (
                                <div key={c.id} onClick={() => { setSelectedCountry(c); setSearchTerm(''); }} style={{ padding: '10px', cursor: 'pointer', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ fontWeight: '500', color: 'var(--text-primary)' }}>{c.name}</span>
                                    <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{c.status}</span>
                                </div>
                            ))
                        ) : <div style={{ padding: '10px', textAlign: 'center', color: 'var(--text-secondary)' }}>No matches found</div>}
                    </div>
                )}
            </div>

            {/* Map & Info Grid */}
            <div className="home-grid" style={{ display: 'grid', gridTemplateColumns: selectedCountry ? '2fr 1fr' : '1fr', gap: '30px', transition: 'all 0.5s ease' }}>

                {/* Map - Pass selectedSdg prop */}
                <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
                    <WorldMap
                        data={globalData}
                        onCountryClick={setSelectedCountry}
                        selectedSdg={selectedSdg}
                        activeTab={activeTab}
                    />
                </div>

                {/* Country Intel Panel */}
                {selectedCountry && (
                    <div className="card country-intel-panel" style={{ animation: 'slideIn 0.3s ease-out' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '20px' }}>
                            <div>
                                <h3 style={{ fontSize: '1.8rem', marginBottom: '5px', color: 'var(--text-primary)' }}>{selectedCountry.name}</h3>
                                <span style={{
                                    background: selectedCountry.status === '1.5°C Paris Compatible' ? 'var(--accent)' : '#ef4444',
                                    color: 'white', padding: '4px 12px', borderRadius: '15px', fontSize: '0.8rem', fontWeight: 'bold'
                                }}>
                                    {selectedCountry.status}
                                </span>
                            </div>
                            <button onClick={() => setSelectedCountry(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.5rem', color: 'var(--text-primary)', opacity: 0.5 }}>×</button>
                        </div>

                        {/* If specific SDG selected, show that score specifically */}
                        {selectedSdg && (
                            <div style={{ marginBottom: '20px', background: 'var(--bg-color)', padding: '15px', borderRadius: '10px', borderLeft: '5px solid var(--accent)' }}>
                                <div style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '5px' }}>
                                    {`SDG ${selectedSdg.split('_')[1]} PERFORMANCE`}
                                </div>
                                <div style={{ fontSize: '2.5rem', fontWeight: '800', color: 'var(--text-primary)' }}>
                                    {selectedCountry[selectedSdg]} <span style={{ fontSize: '1rem' }}>/ 100</span>
                                </div>
                            </div>
                        )}

                        <div style={{ marginBottom: '20px' }}>
                            <div style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '5px' }}>OVERALL SCORE</div>
                            <div style={{ fontSize: '3rem', fontWeight: '800', color: 'var(--text-primary)' }}>{selectedCountry.overall_score || selectedCountry.score}<span style={{ fontSize: '1rem', color: 'var(--text-secondary)' }}>/100</span></div>
                        </div>

                        <div>
                            <div style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '10px' }}>MAJOR ISSUES</div>
                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                                {selectedCountry.issues && selectedCountry.issues.map((issue, i) => (
                                    <span key={i} style={{ background: 'var(--accent-soft)', color: 'var(--text-primary)', border: '1px solid var(--border-color)', padding: '6px 12px', borderRadius: '8px', fontSize: '0.9rem', fontWeight: '600' }}>
                                        ⚠️ {issue}
                                    </span>
                                ))}
                            </div>
                        </div>

                        <button
                            onClick={() => onViewReport(selectedCountry)}
                            style={{ width: '100%', marginTop: '30px', padding: '12px', background: 'var(--primary)', color: 'white', border: 'none', borderRadius: '10px', fontWeight: 'bold', cursor: 'pointer', transition: 'transform 0.2s' }}
                            onMouseOver={(e) => e.target.style.transform = 'scale(1.02)'}
                            onMouseOut={(e) => e.target.style.transform = 'scale(1)'}
                        >
                            View Full Report →
                        </button>
                    </div>
                )}
            </div>
        </div>
    )
}
