export const LeafIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M21 3C16 3 11 8 11 15C11 17.5 12 21 12 21C12 21 8.5 20 6 20C2.5 20 2 17 2 17C2 17 4 17 5 15C6 13 6 10 9 7C12 4 16 3 21 3Z" stroke="#2ecc71" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M11 15C11 15 13 11 18 10" stroke="#2ecc71" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const SunIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="12" cy="12" r="5" stroke="#f1c40f" strokeWidth="2" />
        <path d="M12 1V3M12 21V23M4.22 4.22L5.64 5.64M18.36 18.36L19.78 19.78M1 12H3M21 12H23M4.22 19.78L5.64 18.36M18.36 5.64L19.78 4.22" stroke="#f1c40f" strokeWidth="2" strokeLinecap="round" />
    </svg>
);

export const WindIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M9.59 4.59A2 2 0 1 1 11 8H2M12.59 19.41A2 2 0 1 0 14 16H2M9.9 12.1A2 2 0 1 1 12 14H2" stroke="#3498db" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const DropIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2.69L6.5 10C5.07 11.91 4.25 14.19 4.25 16.5C4.25 20.64 7.7 24 11.97 24C16.24 24 19.72 20.64 19.72 16.5C19.72 14.19 18.9 11.91 17.5 10L12 2.69Z" fill="#3498db" fillOpacity="0.4" stroke="#3498db" strokeWidth="2" />
    </svg>
);

export const CarIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M19 17H21M5 17H3M19 17C17.8954 17 17 17.8954 17 19C17 20.1046 17.8954 21 19 21C20.1046 21 21 20.1046 21 19C21 17.8954 20.1046 17 19 17ZM5 17C3.89543 17 3 17.8954 3 19C3 20.1046 3.89543 21 5 21C6.10457 21 7 20.1046 7 19C7 17.8954 6.10457 17 5 17ZM15 12H9M19 17V12L16 6H8L5 12V17" stroke="#e74c3c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const ReceiptIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1-2-1Z" stroke="#34495e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M8 6h8M8 10h8M8 14h4" stroke="#34495e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const UsersIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="#34495e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="9" cy="7" r="4" stroke="#34495e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87" stroke="#34495e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" stroke="#34495e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const TrophyIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6" stroke="#f39c12" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18" stroke="#f39c12" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M4 22h16" stroke="#f39c12" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M12 17v5" stroke="#f39c12" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M12 17a6 6 0 0 1-6-6V4h12v7a6 6 0 0 1-6 6Z" stroke="#f39c12" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const SirenIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2L2 22h20L12 2z" stroke="#e74c3c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M12 8v6M12 18h.01" stroke="#e74c3c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const MedalIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="12" cy="8" r="7" stroke="#8e44ad" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M8.21 13.89L7 23l5-3 5 3-1.21-9.12" stroke="#8e44ad" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const SearchIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="11" cy="11" r="8" stroke="#7f8c8d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M21 21L16.65 16.65" stroke="#7f8c8d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);
