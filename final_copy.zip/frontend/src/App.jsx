import { useState, useEffect } from 'react'
import axios from 'axios'
import './index.css'
import ActionLog from './components/ActionLog'
import Leaderboard from './components/Leaderboard'
import AdventureMap from './components/AdventureMap'
import Coach from './components/Coach'
import ImpactMap from './components/ImpactMap'
import CountriesWidget from './components/CountriesWidget'
import HeaderWidgets from './components/HeaderWidgets'
import StreakBadges from './components/StreakBadges'
import ImpactStats from './components/ImpactStats'
import EcoTipsCarousel from './components/EcoTipsCarousel'
import HomeWidget from './components/HomeWidget'
import AboutWidget from './components/AboutWidget'
import Dashboard from './components/Dashboard'

import CountryReport from './components/CountryReport'
import CountryProfileWidget from './components/CountryProfile/CountryProfileWidget'
import RankingsWidget from './components/Rankings/RankingsWidget'
import { LayoutDashboard, Home, Shield, Award, Map, Info, Trophy, User } from 'lucide-react'

function App() {
    const [activeTab, setActiveTab] = useState('home')
    const [selectedCountryId, setSelectedCountryId] = useState('india')
    const [dashboardData, setDashboardData] = useState(null)
    const [viewingReport, setViewingReport] = useState(null)
    const [aiSummary, setAiSummary] = useState(null)
    const [darkMode, setDarkMode] = useState(false)

    useEffect(() => {
        if (darkMode) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }, [darkMode]);

    useEffect(() => {
        if (!selectedCountryId) return;

        const fetchData = async () => {
            try {
                const [dashRes, aiRes] = await Promise.all([
                    axios.get(`/api/dashboard-preview?country=${selectedCountryId}`),
                    axios.get(`/api/dashboard/summary?country=${selectedCountryId}`)
                ]);
                setDashboardData(dashRes.data);
                setAiSummary(aiRes.data);
            } catch (err) {
                console.error(err);
            }
        };

        fetchData();
    }, [selectedCountryId])

    return (
        <div className="app-container">
            <header className="app-header">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%', maxWidth: '1400px', margin: '0 auto' }}>
                    <div className="nav-brand" style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '1.25rem', fontWeight: '800', letterSpacing: '-0.02em', color: 'var(--text-primary)' }}>
                        <div style={{ background: 'var(--accent)', padding: '6px', borderRadius: '8px' }}>
                            <Shield size={20} color="white" fill="white" />
                        </div>
                        EcoCatalyst
                    </div>

                    <nav className="main-nav" style={{ display: 'flex', gap: '4px' }}>
                        {[
                            { id: 'home', label: 'Home', icon: Home },
                            { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
                            { id: 'country_profile', label: 'Profile', icon: User },
                            { id: 'rankings', label: 'Rankings', icon: Trophy },
                            { id: 'adventure', label: 'Adventure', icon: Award },
                            { id: 'map', label: 'Map', icon: Map },
                            { id: 'about', label: 'About', icon: Info },
                        ].map(tab => (
                            <button
                                key={tab.id}
                                className={`nav-link ${activeTab === tab.id ? 'active' : ''}`}
                                onClick={() => { setActiveTab(tab.id); setViewingReport(null); }}
                                style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                            >
                                <tab.icon size={16} />
                                {tab.label}
                            </button>
                        ))}
                    </nav>

                    <div className="header-widgets" style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                        <button
                            onClick={() => setDarkMode(!darkMode)}
                            style={{
                                background: 'var(--bg-color)',
                                border: '1px solid var(--border-color)',
                                cursor: 'pointer',
                                padding: '8px',
                                borderRadius: '10px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                transition: 'var(--transition)',
                                color: 'var(--text-primary)'
                            }}
                        >
                            {darkMode ? '☀️' : '🌙'}
                        </button>
                        <HeaderWidgets selectedCountryId={selectedCountryId} activeTab={activeTab} />
                    </div>
                </div>
            </header>

            <main style={{ padding: '2rem 1rem', maxWidth: '1400px', margin: '0 auto', width: '100%' }}>
                {activeTab === 'home' && (
                    viewingReport ? (
                        <CountryReport
                            country={viewingReport}
                            onBack={() => setViewingReport(null)}
                        />
                    ) : (
                        <HomeWidget
                            onViewReport={(country) => {
                                setViewingReport(country);
                                setSelectedCountryId(country.id);
                            }}
                        />
                    )
                )}

                {activeTab === 'country_profile' && <CountryProfileWidget />}

                {activeTab === 'rankings' && <RankingsWidget />}

                {activeTab === 'dashboard' && (
                    <Dashboard
                        dashboardData={dashboardData}
                        aiSummary={aiSummary}
                        selectedCountryId={selectedCountryId}
                        setSelectedCountryId={setSelectedCountryId}
                    />
                )}

                {activeTab === 'adventure' && <AdventureMap />}

                {activeTab === 'map' && <ImpactMap />}

                {activeTab === 'about' && <AboutWidget />}
            </main>
        </div>
    )
}

export default App
