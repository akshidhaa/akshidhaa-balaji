# Sustainability Tracker Updates Plan

This plan outlines the changes to the Live Status Meter, Neighborhood Impact Map, and Eco-Adventure Game to meet the new requirements.

## Proposed Changes

### Backend Updates
#### [MODIFY] [app.py](file:///c:/Users/AKSHIDHAABALAJI/Downloads/sustainability_tracker_v2/backend/app.py)
 - Update `countries_db` with adjusted labels for environment status (mapping to "Good", "Moderate", "Hazard").
 - Update `adventure_state` levels:
   - Level 1: 200 points, 5 seconds.
   - Level 2: 500 points, 10 seconds.
   - Level 3: 1000 points, 15 seconds.

---

### Frontend Updates
#### [MODIFY] [CountriesWidget.jsx](file:///c:/Users/AKSHIDHAABALAJI/Downloads/sustainability_tracker_v2/frontend/src/components/CountriesWidget.jsx)
 - Update `renderMeter` to display "Good", "Moderate", and "Hazard" labels.
 - Adjust color and rotation logic to align with these labels.

#### [MODIFY] [ImpactMap.jsx](file:///c:/Users/AKSHIDHAABALAJI/Downloads/sustainability_tracker_v2/frontend/src/components/ImpactMap.jsx)
 - Add a dedicated UI box for "Name and Region" selection.
 - Improve the search/locate logic to highlight colored impact (Green, Red, Orange).
 - Ensure the world map is the primary view for global impacts.

#### [MODIFY] [AdventureMap.jsx](file:///c:/Users/AKSHIDHAABALAJI/Downloads/sustainability_tracker_v2/frontend/src/components/AdventureMap.jsx)
 - Rename the game to "5-Second tree plant challenge".
 - Implement the 3-level progression with specific point and time targets.
 - Add tree pop-in animations (already exists, will polish).
 - Add Level Complete and Final Victory sounds.
 - Implement a "Try again" screen on failure.
 - Final summary screen showing total points and success sound.

---

## Verification Plan

### Automated Tests
 - No automated tests currently exist for these UI-heavy features. I will verify manually.

### Manual Verification
 1. **Live Meter:**
    - Navigate to Dashboard.
    - Select India, Brazil, and USA from the dropdown.
    - Verify the meter moves and shows labels: "Hazard" (India), "Good" (Brazil), "Moderate" (USA - or adjusted).
 2. **Impact Map:**
    - Navigate to Impact Map.
    - Enter a name and location (e.g., "Paris, France").
    - Verify the map flies to the location and displays markers with correct colors (Green/Red/Orange).
 3. **Eco-Adventure Game:**
    - Navigate to Adventure.
    - Start Level 1.
    - Verify it requires 200 points in 5 seconds (SPACE bar bashing).
    - If failed, verify "Try again" message.
    - If passed, verify Level Complete sound and Next Level progression.
    - Complete all 3 levels and verify Final Victory sound and summary.
