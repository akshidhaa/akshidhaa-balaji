import json
from carbon_db import get_carbon_footprint

def test_calculation():
    print("Testing Carbon Calculation Logic...")
    
    # Mock detected items from Gemini
    mock_items = [
        {"name": "Beef Steak", "category": "Meat"},
        {"name": "Organic Bananas", "category": "Fruit"},
        {"name": "Milk 1L", "category": "Dairy"},
        {"name": "Unknown Widget", "category": "Household"}
    ]
    
    total_carbon = 0.0
    details = []
    
    print(f"\nProcessing {len(mock_items)} items:")
    for item in mock_items:
        name = item.get("name", "Unknown")
        category = item.get("category", "Other")
        
        # Logic mirroring app.py
        footprint, match = get_carbon_footprint(name)
        if footprint == 0.0:
             print(f"  - '{name}' not found exact. Trying category '{category}'...")
             footprint, match = get_carbon_footprint(category)
             
        if footprint == 0.0:
            print(f"  - Category '{category}' also not found. Using default.")
            footprint = 1.0 
            
        print(f"  + Item: {name} -> Match: {match} -> Footprint: {footprint}kg")
        total_carbon += footprint
        details.append(f"{name} ({footprint}kg)")
        
    print(f"\nTotal Carbon: {total_carbon}kg")
    
    # Assertions
    # Beef (60) + Bananas (0.7) + Milk (3.0) + Household (2.0) = 65.7
    expected = 60.0 + 0.7 + 3.0 + 2.0
    print(f"Expected: {expected}kg")
    
    if abs(total_carbon - expected) < 0.1:
        print("✅ PASSED: Calculation is correct.")
    else:
        print("❌ FAILED: Calculation mismatch.")

if __name__ == "__main__":
    test_calculation()
