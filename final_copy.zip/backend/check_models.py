import os
import google.generativeai as genai

GEMINI_API_KEY = "AIzaSyAUOJT54VsSXQaG5HPZ1-WIsqi7ha7wy3g"
genai.configure(api_key=GEMINI_API_KEY)

print("Listing available models...")
try:
    with open("models_utf8.txt", "w", encoding="utf-8") as f:
        for m in genai.list_models():
            if 'generateContent' in m.supported_generation_methods:
                print(m.name)
                f.write(m.name + "\n")
except Exception as e:
    print(f"Error: {e}")
