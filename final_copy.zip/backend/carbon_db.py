
# Carbon Footprint Database (kg CO2e per kg/unit)
# Sources: BBC, Our World in Data, various LCA studies
# This provides deterministic, "correct" values for common items.

carbon_db = {
    # --- Meats & Proteins ---
    "beef": 60.0,
    "lamb": 24.0,
    "mutton": 24.0,
    "cheese": 21.0,
    "chocolate": 19.0,
    "coffee": 17.0,
    "prawns": 12.0,
    "shrimp": 12.0,
    "palm oil": 8.0,
    "pig meat": 7.0,
    "pork": 7.0,
    "poultry": 6.0,
    "chicken": 6.0,
    "olive oil": 6.0,
    "fish": 5.0,
    "eggs": 4.5,
    "rice": 4.0,
    "milk": 3.0,
    "cane sugar": 3.0,
    "groundnuts": 2.5,
    "peanuts": 2.5,
    "wheat": 1.4,
    "rye": 1.4,
    "tomatoes": 1.4,
    "corn": 1.0,
    "cassava": 1.0,
    "soymilk": 0.9,
    "peas": 0.9,
    "bananas": 0.7,
    "root vegetables": 0.4,
    "apples": 0.4,
    "citrus fruit": 0.3,
    "nuts": 0.3,
    
    # --- Common Grocery Items (mapped to closest category) ---
    "bread": 1.2, # Wheat based
    "bagel": 1.2,
    "pasta": 1.3,
    "noodles": 1.3,
    "pizza": 5.0, # Cheese + Dough
    "burger": 4.0, # Beef/Bun mix average
    "sandwich": 2.5, # Mixed
    "salad": 1.5, # Mixed greens + dressing
    "yogurt": 2.2,
    "butter": 12.0,
    "cream": 2.5,
    "ice cream": 3.0,
    
    "chips": 2.5, # Processed potato/corn
    "crisps": 2.5,
    "fries": 2.5,
    "biscuits": 2.0,
    "cookies": 2.0,
    "cake": 3.0,
    
    "soda": 0.5, # Packaging + sugar
    "cola": 0.5,
    "juice": 1.0, # Fruit processing
    "beer": 1.2,
    "wine": 1.5,
    "water": 0.2, # Mostly bottle
    
    "soap": 1.5,
    "shampoo": 2.0,
    "detergent": 2.0,
    "toilet paper": 1.5,
    "tissue": 1.5,
    
    # --- Generic Categories (Fallback) ---
    "meat": 15.0,
    "dairy": 5.0,
    "fruit": 0.5,
    "vegetable": 0.5,
    "drink": 0.8,
    "alcohol": 1.5,
    "snack": 2.0,
    "household": 2.0,
    "electronics": 50.0, # High impact
    "clothing": 10.0,
    
    # --- Energy & Fossil Fuels (Harmful Items) ---
    "coal": 100.0, # Extremely high
    "petrol": 75.0,
    "diesel": 80.0,
    "gasoline": 75.0,
    "natural gas": 60.0,
    "plastic": 15.0, # Per kg
    "single-use plastic": 20.0,
    "fossil fuel": 85.0,
    
    # --- Hazardous & Harmful Items ---
    "bomb": 500.0,
    "nuclear weapon": 10000.0,
    "nuclear weapons": 10000.0,
    "ammunition": 50.0,
    "battery": 15.0,
    "batteries": 15.0,
    "gun": 100.0,
    "guns": 100.0,
    "weapon": 150.0,
    "weapons": 150.0,
    "chemical": 25.0,
    "chemicals": 30.0,
    "lead-acid battery": 25.0,
    "toxic waste": 200.0,
    "hazardous material": 150.0,
    "hazardous waste": 200.0,
    "pesticide": 40.0,
    "pesticides": 40.0,
    
    "misc": 1.0
}

def get_carbon_footprint(item_name):
    """
    Look up item in database with fuzzy matching.
    Returns: (footprint_value, match_name)
    """
    item_lower = item_name.lower().strip()
    
    # 1. Exact Match
    if item_lower in carbon_db:
        return carbon_db[item_lower], item_lower
        
    # 2. Substring Match (e.g. "organic bananas" -> "bananas")
    for key in carbon_db:
        if key in item_lower or item_lower in key:
            # Prefer the longer match if multiple (e.g. "beef dict" vs "beef")
            # For now, just return the first reasonable match
             return carbon_db[key], key
             
    # 3. Default
    return 0.0, None # Not found
