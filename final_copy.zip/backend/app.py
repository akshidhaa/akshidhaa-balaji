import os
import json
import random
from flask import Flask, request, jsonify
from flask_cors import CORS
import firebase_admin
from firebase_admin import credentials, db
from iso_mapping import iso3_to_iso2
import google.generativeai as genai
from carbon_db import get_carbon_footprint, carbon_db

app = Flask(__name__)
CORS(app)

# --- Gemini API Setup ---
# TODO: PASTE YOUR GEMINI API KEY BELOW (Replace the placeholder text)
GEMINI_API_KEY = "AIzaSyAUOJT54VsSXQaG5HPZ1-WIsqi7ha7wy3g"

# Configure Gemini with the provided key
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

# --- Configuration & Firebase Setup ---
# In a real scenario, you'd use a service account key file.
# For this hackathon demo, we'll try to connect, but fall back to in-memory storage if no creds.
FIREBASE_CRED_PATH = os.environ.get('FIREBASE_CRED_PATH', 'firebase_credentials.json')
from about_content import about_data

# --- About Section Data ---
# Loaded from about_content.py

# --- New API Endpoints ---

@app.route('/api/about/content', methods=['GET'])
def get_about_content():
    return jsonify(about_data)

if os.path.exists(FIREBASE_CRED_PATH):
    try:
        cred = credentials.Certificate(FIREBASE_CRED_PATH)
        firebase_admin.initialize_app(cred, {
            'databaseURL': os.environ.get('FIREBASE_DB_URL', 'https://your-project-id.firebaseio.com/')
        })
        USE_FIREBASE = True
        print("Connected to Firebase Realtime Database.")
    except Exception as e:
        print(f"Failed to initialize Firebase: {e}. Using in-memory storage.")
else:
    print("No Firebase credentials found. Using in-memory storage for demo.")
    USE_FIREBASE = False

# --- In-Memory Storage (Fallback) ---
# Data structure mirrors what we would have in Firebase
mock_db = {
    'users': {},
    'actions': [],
    'leaderboard': [],
    'eco_tips': [
        "Switch to LED bulbs to save 75% on lighting energy.",
        "Use a reusable water bottle to save 1,460 plastic bottles a year.",
        "Unplug electronics when not in use to reduce phantom energy load.",
        "Compost food scraps to reduce landfill methane emissions.",
        "Shop locally to reduce transportation emissions."
    ],
    'challenges': [
        {"id": 1, "title": "Zero Waste Week", "description": "Produce no trash for a week!", "points": 500},
        {"id": 2, "title": "Bike to Work/School", "description": "Cycle instead of driving for 3 days.", "points": 300},
        {"id": 4, "title": "Tree Guardian", "description": "Plant 10 trees in your forest.", "points": 1000}
    ],
    'adventure_state': {
        "level": 1,
        "guardian_xp": 0,
        "trees": [
            {"id": 1, "type": "Oak", "x": 50, "y": 80, "growth": 100} # Initial tree
        ],
        "reward_inventory": [],
        "unlocked_species": ["Oak", "Pine", "Sakura"],
        "levels": [
            {"level": 1, "target": 200, "time_limit": 5, "rule": "Level 1: 200 points 5 seconds plant 20 trees fast"},
            {"level": 2, "target": 500, "time_limit": 10, "rule": "Level 2: 500 points 10 seconds"},
            {"level": 3, "target": 1000, "time_limit": 15, "rule": "Level 3: 1000 points 15 seconds"}
        ],
        "total_game_time": 0,
        "total_game_points": 0
    }
}

# --- Helper Functions ---
def get_leaderboard():
    if USE_FIREBASE:
        ref = db.reference('leaderboard')
        return ref.get() or []
    return sorted(list(mock_db['leaderboard']), key=lambda x: x['score'], reverse=True)

def update_leaderboard(user_id, points):
    if USE_FIREBASE:
        ref = db.reference(f'leaderboard/{user_id}')
        current = ref.get() or {'user_id': user_id, 'score': 0}
        current['score'] += points
        ref.set(current)
    else:
        # Check if user exists in mock leaderboard
        found = False
        for entry in mock_db['leaderboard']:
            if entry['user_id'] == user_id:
                entry['score'] += points
                found = True
                break
        if not found:
            mock_db['leaderboard'].append({'user_id': user_id, 'score': points, 'name': f"User {user_id}"})

def log_action_db(action_data):
    if USE_FIREBASE:
        ref = db.reference('actions')
        ref.push(action_data)
    else:
        mock_db['actions'].append(action_data)

# --- Routes ---

@app.route('/')
def home():
    return jsonify({"message": "Sustainability Tracker API is running!", "firebase_connected": USE_FIREBASE})

@app.route('/api/actions', methods=['GET', 'POST'])
def handle_actions():
    if request.method == 'POST':
        data = request.json
        user_id = data.get('user_id', 'guest')
        action_type = data.get('action') # e.g., "recycled_bottle"
        impact_score = data.get('impact', 10) # default points
        
        # Calculate impact metrics (mock logic for now)
        co2_saved = impact_score * 0.5 # kg
        
        entry = {
            'user_id': user_id,
            'action': action_type,
            'impact_points': impact_score,
            'co2_saved_kg': co2_saved,
            'timestamp': '2023-10-27T10:00:00Z' # In real app, use datetime.now()
        }
        
        
        log_action_db(entry)
        update_leaderboard(user_id, impact_score)
        
        # Update Tree Forest Progress (Legacy support for Dashboard)
        adv = mock_db['adventure_state']
        adv['guardian_xp'] += impact_score
        
        if action_type == 'planted_tree':
            new_tree = {
                "id": len(adv['trees']) + 1,
                "type": str(random.choice(adv['unlocked_species'])),
                "x": random.randint(10, 90),
                "y": random.randint(40, 90),
                "growth": 100
            }
            adv['trees'].append(new_tree)
        
        adventure_update = None
        if action_type == 'planted_tree':
            adventure_update = "A new tree has bloomed in your forest!"

        return jsonify({
            "status": "success", 
            "data": entry, 
            "message": f"Action logged! You saved {co2_saved}kg CO2.",
            "adventure_update": adventure_update
        })
    
    # GET request
    if USE_FIREBASE:
        ref = db.reference('actions')
        return jsonify(ref.get() or {})
    return jsonify(mock_db['actions'])

@app.route('/api/leaderboard', methods=['GET'])
def leaderboard():
    return jsonify(get_leaderboard())

@app.route('/api/calculate-impact', methods=['POST'])
def calculate_product_impact():
    """
    Calculates carbon footprint and suggests XP for a custom product.
    """
    data = request.json
    product_name = data.get('product', '').strip()
    
    if not product_name:
        return jsonify({"error": "Product name is required"}), 400
        
    footprint, match = get_carbon_footprint(product_name)
    
    # Scaling: XP = max(10, 100 - (footprint * 2)) 
    suggested_xp = max(0, round(100 - (footprint * 1.5)))
    
    # Identify Harmful Items
    harmful_keywords = [
        "coal", "petrol", "diesel", "gasoline", "plastic", "fossil fuel", "beef",
        "bomb", "nuclear", "weapon", "weapons", "ammunition", "battery", "batteries", 
        "hazard", "toxic", "pesticide", "gun", "guns", "chemical", "chemicals"
    ]
    is_harmful = any(kw in product_name.lower() or (match and kw in match.lower()) for kw in harmful_keywords)
    
    # Special case: If not found in DB AND contains harmful-sounding words, force harmful
    if not match and any(kw in product_name.lower() for kw in ["oil", "gas", "smoke", "waste"]):
        is_harmful = True

    # Force low/zero XP for harmful items
    if is_harmful or footprint > 40:
        suggested_xp = 0 # No reward for high-impact items
        is_sustainable = False
        status_text = "NOT SUSTAINABLE"
    elif footprint > 0 and footprint < 5:
        is_sustainable = True
        status_text = "SUSTAINABLE"
    elif footprint == 0 and not is_harmful:
        # Unknown but not obviously harmful
        is_sustainable = True
        status_text = "SUSTAINABLE (ESTIMATED)"
    else:
        is_sustainable = False
        status_text = "MODERATE IMPACT"


    # Generate Tip
    if is_harmful:
        tip = f"⚠️ {product_name.capitalize()} is a high-emission item linked to significant environmental damage. Swapping this for renewable or plant-based alternatives can reduce your footprint by over 90%!"
    elif footprint < 1:
        tip = f"🌟 Excellent choice! {product_name.capitalize()} is highly sustainable and helps keep the planet green."
    elif footprint > 20:
        tip = f"⚠️ {product_name.capitalize()} has a high environmental cost. Consider alternatives to save CO2!"
    else:
        tip = "This item has a manageable impact. Choosing it over higher-carbon alternatives is a great step!"
         
    return jsonify({
        "product": product_name,
        "matched_with": match if match else "general assumption",
        "carbon_footprint_kg": round(footprint, 2) if footprint > 0 else 1.0,
        "suggested_xp": suggested_xp,
        "is_sustainable": is_sustainable,
        "status_text": status_text,
        "tip": tip
    })





@app.route('/api/adventure', methods=['GET'])
def adventure_progress():
    """
    Returns the state of the user's digital eco-world.
    """
    return jsonify(mock_db['adventure_state'])

@app.route('/api/adventure/score', methods=['POST'])
def save_adventure_score():
    data = request.json
    # Log the score for demo purposes
    print(f"SAVING ADVENTURE SCORE: {data}")
    return jsonify({"status": "success", "message": "Adventure progress synchronized!"})


@app.route('/api/impact-map', methods=['GET'])
def impact_map():
    """
    Returns geo-tagged impact data for the neighborhood map.
    Supports ?lat=&lng= to return localized "nearest" neighbors.
    """
    lat = request.args.get('lat')
    lng = request.args.get('lng')
    
    if lat and lng:
        # Generate mock "nearest" neighbors around the provided coordinate
        lat, lng = float(lat), float(lng)
        localized_data = []
        names = ["Saurav", "Anita", "John", "Mei", "Elena", "Carlos", "Fatima", "Kenji", "Zara", "Liam"]
        actions = ["Solar Roof", "No Car Day", "Composting", "Rainwater Harvesting", "LED Upgrade", "Rooftop Garden", "Cycle to Work", "Plastic Free"]
        
        for i in range(15):
            score = random.randint(20, 100)
            if score > 80:
                status = "Radiant (Green)"
            elif score > 50:
                status = "Improving (Orange)"
            else:
                status = "Needs Attention (Red)"
                
            localized_data.append({
                "lat": lat + (random.uniform(-0.02, 0.02)), # Tighter radius for "neighborhood"
                "lng": lng + (random.uniform(-0.02, 0.02)),
                "action": random.choice(actions),
                "user": random.choice(names),
                "impact": random.choice(["High", "Moderate", "High", "Exceptional"]),
                "status": status,
                "score": score
            })
        return jsonify(localized_data)

    # Default Global Data
    map_data = [
        {"lat": 40.7128, "lng": -74.0060, "action": "Tree Planting", "user": "Alice", "impact": "High", "status": "Radiant (Green)", "score": 95},
        {"lat": 51.5074, "lng": -0.1278, "action": "Garden Project", "user": "Londoner", "impact": "High", "status": "Radiant (Green)", "score": 88},
        {"lat": 28.6139, "lng": 77.2090, "action": "EV Charging Hub", "user": "Aarav", "impact": "High", "status": "Radiant (Green)", "score": 92},
        {"lat": -23.5505, "lng": -46.6333, "action": "Water Saving", "user": "Maria", "impact": "Moderate", "status": "Improving (Orange)", "score": 65}
    ]
    return jsonify(map_data)

@app.route('/api/region-config', methods=['GET'])
def region_config():
    """
    Returns localized challenges and tips based on region.
    """
    region = request.args.get('region', 'global')
    
    if region.lower() == 'california':
        local_tips = ["Conserve water due to drought.", "Use solar power."]
    elif region.lower() == 'new york':
        local_tips = ["Take the subway instead of cabs.", "Compost in city bins."]
    else:
        local_tips = mock_db['eco_tips']
        
    return jsonify({"region": region, "tips": local_tips})

# --- Countries Widget Data & Routes ---

countries_db = {
    "IND": {
        "name": "India",
        "flag": "🇮🇳",
        "environment_status": "Hazard",
        "coal_dependency": 75,
        "renewable_progress": 42, 
        "ev_adoption": 8,
        "climate_risks": ["Extreme Heatwaves", "Monsoon Variability"],
        "green_hydrogen_status": "National Green Hydrogen Mission launched. Target: 5 MMT by 2030.",
        "carbon_credits": 120,
        "trend_data": {
            "years": [2020, 2021, 2022, 2023, 2024],
            "renewables": [20, 25, 30, 38, 42],
            "coal": [80, 78, 77, 76, 75]
        },
        "tips": [
            "Use natural ventilation to reduce AC load.",
            "Switch to 5-star rated appliances.",
            "Support local solar rooftop initiatives."
        ]
    },
    "USA": {
        "name": "USA",
        "flag": "🇺🇸",
        "environment_status": "Moderate",
        "coal_dependency": 20,
        "renewable_progress": 25,
        "ev_adoption": 15,
        "climate_risks": ["Wildfires", "Hurricanes"],
        "green_hydrogen_status": "Major investments via Inflation Reduction Act.",
        "carbon_credits": 350,
        "trend_data": {
            "years": [2020, 2021, 2022, 2023, 2024],
            "renewables": [15, 18, 20, 22, 25],
            "coal": [30, 28, 25, 22, 20]
        },
        "tips": [
            "Upgrade to a heat pump for heating/cooling.",
            "Choose EV or hybrid for your next vehicle.",
            "Reduce meat consumption."
        ]
    },
    "DEU": {
        "name": "Germany",
        "flag": "🇩🇪",
        "environment_status": "Safe",
        "coal_dependency": 30,
        "renewable_progress": 55,
        "ev_adoption": 25,
        "climate_risks": ["Floods", "Heatwaves"],
        "green_hydrogen_status": "Leader in hydrogen technology and imports.",
        "carbon_credits": 410,
        "trend_data": {
            "years": [2020, 2021, 2022, 2023, 2024],
            "renewables": [40, 45, 48, 52, 55],
            "coal": [35, 33, 32, 31, 30]
        },
        "tips": [
            "Use public transport (Deutschlandticket).",
            "Properly sort recycling (Pfand system).",
            "Insulate homes for winter efficiency."
        ]
    },
    "BRA": {
        "name": "Brazil",
        "flag": "🇧🇷",
        "environment_status": "Good",
        "coal_dependency": 5,
        "renewable_progress": 85,
        "ev_adoption": 2,
        "climate_risks": ["Deforestation", "Droughts"],
        "green_hydrogen_status": "High potential due to abundant renewables.",
        "carbon_credits": 200,
        "trend_data": {
            "years": [2020, 2021, 2022, 2023, 2024],
            "renewables": [80, 81, 82, 84, 85],
            "coal": [6, 6, 5, 5, 5]
        },
        "tips": [
            "Support sustainable products from the Amazon.",
            "Reduce water usage during dry seasons.",
            "Use ethanol fuel where available."
        ]
    },
    "GBR": {
        "name": "UK",
        "flag": "🇬🇧",
        "environment_status": "Good",
        "coal_dependency": 2,
        "renewable_progress": 45,
        "ev_adoption": 20,
        "climate_risks": ["Floods", "Heatwaves"],
        "green_hydrogen_status": "Focus on industrial clusters.",
        "carbon_credits": 300,
        "trend_data": {
            "years": [2020, 2021, 2022, 2023, 2024],
            "renewables": [30, 35, 40, 42, 45],
            "coal": [5, 4, 3, 2, 2]
        },
        "tips": [
            "Improve home insulation.",
            "Reduce food waste.",
            "Use active travel (walking/cycling)."
        ]
    },
    "JPN": {
        "name": "Japan",
        "flag": "🇯🇵",
        "environment_status": "Moderate",
        "coal_dependency": 30,
        "renewable_progress": 22,
        "ev_adoption": 5,
        "climate_risks": ["Typhoons", "Heatwaves"],
        "green_hydrogen_status": "Pioneer in hydrogen society vision.",
        "carbon_credits": 280,
        "trend_data": {
            "years": [2020, 2021, 2022, 2023, 2024],
            "renewables": [18, 19, 20, 21, 22],
            "coal": [32, 32, 31, 30, 30]
        },
        "tips": [
            "Practice 'Cool Biz' fashion to reduce AC.",
            "Reduce single-use plastics.",
            "Use energy-efficient bath heating."
        ]
    }
}


# --- Advanced Header Widgets Data (Check by Country) ---
community_impact = {
    "india": {
        "trees_planted": 12450,
        "plastic_avoided_kg": 5600,
        "co2_saved_tons": 320,
        "volunteers": 850
    },
    "usa": {
        "trees_planted": 8500,
        "plastic_avoided_kg": 12000,
        "co2_saved_tons": 550,
        "volunteers": 1200
    },
    "germany": {
        "trees_planted": 5000,
        "plastic_avoided_kg": 8900,
        "co2_saved_tons": 400,
        "volunteers": 600
    },
    "brazil": {
        "trees_planted": 25000,
        "plastic_avoided_kg": 3000,
        "co2_saved_tons": 800,
        "volunteers": 2000
    },
    "uk": {
        "trees_planted": 4200,
        "plastic_avoided_kg": 4500,
        "co2_saved_tons": 250,
        "volunteers": 450
    },
    "japan": {
        "trees_planted": 3100,
        "plastic_avoided_kg": 6700,
        "co2_saved_tons": 300,
        "volunteers": 300
    }
}

neighborhood_challenges = {
    "india": [
        {"id": 1, "name": "Greenwood Apts (Mumbai)", "action": "Composting", "score": 1200, "rank": 1},
        {"id": 2, "name": "Sunnydale School (Delhi)", "action": "No Plastic", "score": 950, "rank": 2},
        {"id": 3, "name": "TechPark Office (Bangalore)", "action": "Carpooling", "score": 800, "rank": 3}
    ],
    "usa": [
        {"id": 1, "name": "Brooklyn Co-op", "action": "Rooftop Garden", "score": 1500, "rank": 1},
        {"id": 2, "name": "Austin High", "action": "Recycling Drive", "score": 1100, "rank": 2},
        {"id": 3, "name": "SF Tech Hub", "action": "Bike to Work", "score": 900, "rank": 3}
    ],
    "germany": [
        {"id": 1, "name": "Berlin Kiez", "action": "Urban Gardening", "score": 1300, "rank": 1},
        {"id": 2, "name": "Munich Uni", "action": "Energy Saving", "score": 1050, "rank": 2},
        {"id": 3, "name": "Hamburg Port", "action": "Clean Harbor", "score": 980, "rank": 3}
    ],
    "brazil": [
        {"id": 1, "name": "Rio Beach Cleanup", "action": "Waste Removal", "score": 2000, "rank": 1},
        {"id": 2, "name": "Amazon Guardians", "action": "Reforestation", "score": 1800, "rank": 2},
        {"id": 3, "name": "Sao Paulo Cyclists", "action": "Car-free Day", "score": 1200, "rank": 3}
    ],
    "uk": [
        {"id": 1, "name": "London Parks", "action": "Tree Care", "score": 1100, "rank": 1},
        {"id": 2, "name": "Manchester Uni", "action": "Zero Waste", "score": 950, "rank": 2},
        {"id": 3, "name": "Bristol Community", "action": "Solar Energy", "score": 850, "rank": 3}
    ],
    "japan": [
        {"id": 1, "name": "Tokyo Ward", "action": "Sorting Trash", "score": 1400, "rank": 1},
        {"id": 2, "name": "Kyoto Temple", "action": "Traditional Garden", "score": 1200, "rank": 2},
        {"id": 3, "name": "Osaka Youth", "action": "River Cleanup", "score": 1000, "rank": 3}
    ]
}

eco_emergency = {
    "india": {
        "active": True,
        "type": "Heatwave Alert",
        "severity": "High",
        "location": "North India",
        "tips": ["Stay hydrated", "Avoid direct sun between 12-4 PM", "Wear light cotton clothes"]
    },
    "usa": {
        "active": True,
        "type": "Hurricane Watch",
        "severity": "Moderate",
        "location": "Florida Coast",
        "tips": ["Secure loose objects", "Stock up on batteries/water", "Stay tuned to alerts"]
    },
    "germany": {
        "active": False,
        "type": "None",
        "severity": "Low",
        "location": "Germany",
        "tips": ["Good air quality today.", "Perfect for outdoor activities."]
    },
    "brazil": {
        "active": True,
        "type": "Deforestation Alert",
        "severity": "Critical",
        "location": "Amazon Basin",
        "tips": ["Report illegal logging", "Support certified wood products", "Spread awareness"]
    },
    "uk": {
        "active": False,
        "type": "None",
        "severity": "Low",
        "location": "UK",
        "tips": ["Rain expected, carry an umbrella.", "Good day for indoor energy audit."]
    },
    "japan": {
        "active": True,
        "type": "Typhoon Warning",
        "severity": "High",
        "location": "Okinawa",
        "tips": ["Evacuate if ordered", "Stay away from windows", "Charge devices now"]
    }

}







@app.route('/api/community-impact', methods=['GET'])
def get_community_impact():
    country = request.args.get('country', 'india').lower()
    return jsonify(community_impact.get(country, community_impact['india']))

@app.route('/api/neighborhood-challenges', methods=['GET'])
def get_neighborhood_challenges():
    country = request.args.get('country', 'india').lower()
    return jsonify(neighborhood_challenges.get(country, neighborhood_challenges['india']))

@app.route('/api/eco-emergency', methods=['GET'])
def get_eco_emergency():
    country = request.args.get('country', 'india').lower()
    return jsonify(eco_emergency.get(country, eco_emergency['india']))

# --- Regional Dashboard Preview Data ---
regional_dashboard_data = {
    "india": {
        "badges": [
            {"name": "Heatwave Hero", "icon": "☀️", "desc": "Survived 40°C+ week", "completed": True},
            {"name": "Tree Planter", "icon": "🌳", "desc": "Planted 5 trees", "completed": True},
            {"name": "Water Warrior", "icon": "💧", "desc": "Saved 100L water", "completed": False},
            {"name": "Solar Saver", "icon": "🔋", "desc": "Installed solar panels", "completed": False}
        ],
        "impact_stats": {"co2_saved": 120, "water_conserved": 450},
        "tips": [
            "Use clay pots for natural water cooling.",
            "Wear Khadi/Cotton to beat the heat.",
            "Harvest rainwater before monsoon."
        ]
    },
    "usa": {
        "badges": [
            {"name": "Recycling Pro", "icon": "♻️", "desc": "Sorted 50kg waste", "completed": True},
            {"name": "EV Driver", "icon": "🚗", "desc": "1000 miles electric", "completed": True},
            {"name": "Compost Champ", "icon": "🍂", "desc": "Started composting", "completed": False},
            {"name": "Meatless Month", "icon": "🥗", "desc": "No meat for 30 days", "completed": False}
        ],
        "impact_stats": {"co2_saved": 350, "water_conserved": 1200},
        "tips": [
            "Support local farmers markets.",
            "Compost your kitchen scraps.",
            "Join a community solar project."
        ]
    },
    "germany": {
        "badges": [
            {"name": "Pfand Master", "icon": "🍾", "desc": "Returned 100 bottles", "completed": True},
            {"name": "Bike Commuter", "icon": "🚲", "desc": " cycled 500km", "completed": True},
            {"name": "Train Traveller", "icon": "🚄", "desc": "Used DB for 10 trips", "completed": False},
            {"name": "Energy Cutter", "icon": "⚡", "desc": "Reduced kWh by 10%", "completed": False}
        ],
        "impact_stats": {"co2_saved": 280, "water_conserved": 800},
        "tips": [
            "Air out rooms quickly (Stoßlüften).",
            "Shop at zero-waste stores.",
            "Use the train for intercity travel."
        ]
    },
    "brazil": {
        "badges": [
            {"name": "Forest Guardian", "icon": "🦜", "desc": "Protected local flora", "completed": True},
            {"name": "Water Saver", "icon": "💧", "desc": "Reduced usage by 20%", "completed": True},
            {"name": "Eco Tourist", "icon": "🛶", "desc": "Visited 3 eco-parks", "completed": False},
            {"name": "Plastic Free", "icon": "🥡", "desc": "Zero plastic week", "completed": False}
        ],
        "impact_stats": {"co2_saved": 400, "water_conserved": 2000},
        "tips": [
            "Avoid single-use plastics on beaches.",
            "Support indigenous crafts.",
            "Use natural light during the day."
        ]
    },
    "uk": {
        "badges": [
            {"name": "Energy Saver", "icon": "💡", "desc": "Lowered heating bill", "completed": True},
            {"name": "Gardener", "icon": "🌻", "desc": "Created bee-friendly garden", "completed": True},
            {"name": "Tea Time Eco", "icon": "☕", "desc": "Boiled only needed water", "completed": False},
            {"name": "Walk to Work", "icon": "🚶", "desc": "Walked 50km total", "completed": False}
        ],
        "impact_stats": {"co2_saved": 220, "water_conserved": 600},
        "tips": [
            "Draught-proof your doors and windows.",
            "Top up your kettle only as needed.",
            "Shop second-hand/charity shops."
        ]
    },
    "japan": {
        "badges": [
            {"name": "Mottainai Spirit", "icon": "🍱", "desc": "Zero food waste week", "completed": True},
            {"name": "Train Rider", "icon": "🚅", "desc": "Used public transit daily", "completed": True},
            {"name": "Onsen Lover", "icon": "♨️", "desc": "Shared bath culture", "completed": False},
            {"name": "Konbini Smart", "icon": "🏪", "desc": "Refused plastic bags", "completed": False}
        ],
        "impact_stats": {"co2_saved": 180, "water_conserved": 500},
        "tips": [
            "Carry a personal chopstick set (My Hashi).",
            "Separate trash into burnable/non-burnable.",
            "Use Furoshiki for gift wrapping."
        ]
    }
}

@app.route('/api/dashboard-preview', methods=['GET'])
def get_dashboard_preview():
    country = request.args.get('country', 'india').lower()
    data = regional_dashboard_data.get(country, regional_dashboard_data['india'])
    return jsonify(data)


@app.route('/api/dashboard/summary', methods=['GET'])
def get_dashboard_summary():
    """Generates AI-powered insights for the dashboard."""
    country_id = request.args.get('country', 'IND').upper() # Default India
    
    # Mock data references (would come from DB in real app)
    user_impact = {"co2": 150, "water": 500, "trees": 12}
    badges_unlocked = 5
    rank = 5
    
    # 1. Action Insight
    action_insight = f"Great job! You've saved {user_impact['co2']}kg of CO2 this week, which is 15% more than last week. Your consistent actions are making a real difference."
    
    # 2. Impact Insight
    impact_insight = "Your water savings are 20% higher than the community average! Consider sharing your water-saving tips with friends to amplify this impact."
    
    # 3. Live Status Insight
    # Fetch country data for context
    c_data = next((c for c in global_sustainability_data if c["id"] == country_id), None)
    live_status_insight = "Data unavailable for this region."
    if c_data:
        status = c_data.get("status", "Unknown")
        issue = c_data.get("issues", ["general improvements needed"])[0]
        live_status_insight = f"{c_data['name']}'s sustainability status is currently '{status}'. While renewable energy adoption is growing, addressing '{issue}' remains a critical priority for the region."
        
    # 4. Achievement Insight
    achievement_insight = f"You've unlocked {badges_unlocked} badges this month! Your 'Tree Planter' badge puts you in the top 10% of users. Keep up the momentum to unlock 'Eco-Warrior' next."
    
    # 5. Leaderboard Insight
    leaderboard_insight = f"You are currently ranked #{rank} in your region for CO2 savings! You're only 50 points away from overtaking the #4 spot."
    
    # 6. Eco-Coach Tip (Contextual)
    # Simple logic: if trees > 0, suggest related; else general
    coach_tip = "Since you've been active in planting trees, consider starting a small home compost bin. It complements your green efforts by reducing waste and nourishing soil!"

    return jsonify({
        "action_insight": action_insight,
        "impact_insight": impact_insight,
        "live_status_insight": live_status_insight,
        "achievement_insight": achievement_insight,
        "leaderboard_insight": leaderboard_insight,
        "coach_tip": coach_tip
    })


@app.route('/api/country/<country_id>', methods=['GET'])
def get_country_data(country_id):
    """Get specific sustainability data for a country."""
    c_id = country_id.upper()
    
    # Try direct ISO lookup
    country = countries_db.get(c_id)
    
    if not country:
        # Try finding by name or ISO in global data
        map_data = next((item for item in global_sustainability_data if item["id"].upper() == c_id or item["name"].upper() == c_id), None)
        
        # Also check if it's a common name like "india"
        if not map_data:
            map_data = next((item for item in global_sustainability_data if item["name"].lower() == country_id.lower()), None)

        if map_data:
            # Map statuses to meter-friendly ones
            raw_status = map_data["status"]
            status_map = {
                "1.5°C Paris Compatible": "Safe",
                "Almost Sufficient": "Good",
                "Insufficient": "Moderate",
                "Highly Insufficient": "Not Safe",
                "Critically Insufficient": "Hazardous"
            }
            env_status = status_map.get(raw_status, "Moderate")
            
            country = {
                "name": map_data["name"],
                "environment_status": env_status,
                "coal_dependency": 50,
                "renewable_progress": map_data["score"],
                "ev_adoption": 5,
                "climate_risks": map_data["issues"],
                "trend_data": {
                    "years": [2020, 2021, 2022, 2023, 2024],
                    "renewables": [20, 25, 30, 35, map_data["score"]],
                    "coal": [60, 58, 55, 52, 50]
                },
                "tips": ["Advocate for cleaner energy.", "Reduce waste locally."]
            }
        else:
            return jsonify({"error": "Country not found"}), 404
    
    # Ensure flag is a URL for consistency
    iso2 = iso3_to_iso2.get(c_id, c_id[:2]).lower()
    country['flag'] = f"https://flagcdn.com/w320/{iso2}.png"
    
    return jsonify(country)

# --- Global Sustainability Map Data (Mock Kaggle Dataset) ---
# --- Global Sustainability Map Data (Mock Kaggle Dataset - Expanded) ---
global_sustainability_data = [
    # North America
    {"id": "USA", "name": "United States", "score": 45, "status": "Insufficient", "issues": ["High per capita emissions", "Fossil fuel subsidies"], "region": "Americas"},
    {"id": "CAN", "name": "Canada", "score": 44, "status": "Highly Insufficient", "issues": ["Oil sands extraction", "Permafrost melt risks"], "region": "Americas"},
    {"id": "MEX", "name": "Mexico", "score": 52, "status": "Insufficient", "issues": ["Deforestation", "Fossil fuel reliance"], "region": "Americas"},
    {"id": "GRL", "name": "Greenland", "score": 85, "status": "1.5°C Paris Compatible", "issues": ["Ice sheet melting (External)"], "region": "Americas"},

    # South America
    {"id": "BRA", "name": "Brazil", "score": 50, "status": "Insufficient", "issues": ["Amazon deforestation", "Land use change"], "region": "Americas"},
    {"id": "ARG", "name": "Argentina", "score": 48, "status": "Highly Insufficient", "issues": ["Economic instability impacting green tech", "Methane from livestock"], "region": "Americas"},
    {"id": "CHL", "name": "Chile", "score": 60, "status": "Almost Sufficient", "issues": ["Water scarcity", "Mining impact"], "region": "Americas"},
    {"id": "COL", "name": "Colombia", "score": 58, "status": "Almost Sufficient", "issues": ["Deforestation", "Coal exports"], "region": "Americas"},
    {"id": "PER", "name": "Peru", "score": 55, "status": "Insufficient", "issues": ["Glacial melt", "Illegal mining"], "region": "Americas"},
    {"id": "VEN", "name": "Venezuela", "score": 30, "status": "Critically Insufficient", "issues": ["Oil dependency", "Economic crisis"], "region": "Americas"},
    {"id": "BOL", "name": "Bolivia", "score": 45, "status": "Insufficient", "issues": ["Deforestation", "Agriculture"], "region": "Americas"},
    {"id": "ECU", "name": "Ecuador", "score": 53, "status": "Insufficient", "issues": ["Oil drilling in Amazon", "Biodiversity loss"], "region": "Americas"},

    # Europe
    {"id": "DEU", "name": "Germany", "score": 65, "status": "Almost Sufficient", "issues": ["Coal phase-out delay", "Transport emissions"], "region": "Europe"},
    {"id": "GBR", "name": "United Kingdom", "score": 70, "status": "1.5°C Paris Compatible", "issues": ["Housing insulation", "North Sea oil licensing"], "region": "Europe"},
    {"id": "FRA", "name": "France", "score": 68, "status": "1.5°C Paris Compatible", "issues": ["Nuclear waste management", "Agricultural emissions"], "region": "Europe"},
    {"id": "ITA", "name": "Italy", "score": 62, "status": "Almost Sufficient", "issues": ["Climate adaptation", "Waste management"], "region": "Europe"},
    {"id": "ESP", "name": "Spain", "score": 64, "status": "Almost Sufficient", "issues": ["Desertification risk", "Water management"], "region": "Europe"},
    {"id": "NOR", "name": "Norway", "score": 75, "status": "1.5°C Paris Compatible", "issues": ["Oil exports", "Arctic drilling"], "region": "Europe"},
    {"id": "SWE", "name": "Sweden", "score": 78, "status": "1.5°C Paris Compatible", "issues": ["Forestry practices", "Biofuel sustainability"], "region": "Europe"},
    {"id": "FIN", "name": "Finland", "score": 76, "status": "1.5°C Paris Compatible", "issues": ["Peat usage", "Forest logging"], "region": "Europe"},
    {"id": "DNK", "name": "Denmark", "score": 77, "status": "1.5°C Paris Compatible", "issues": ["Agriculture", "Biomass reliance"], "region": "Europe"},
    {"id": "NLD", "name": "Netherlands", "score": 60, "status": "Insufficient", "issues": ["Nitrogen crisis", "Rising sea levels"], "region": "Europe"},
    {"id": "POL", "name": "Poland", "score": 42, "status": "Critically Insufficient", "issues": ["Heavy coal reliance", "Air quality"], "region": "Europe"},
    {"id": "UKR", "name": "Ukraine", "score": 45, "status": "Highly Insufficient", "issues": ["War damage reconstruction", "Old heavy industry"], "region": "Europe"},
    {"id": "RUS", "name": "Russia", "score": 25, "status": "Critically Insufficient", "issues": ["Methane leaks", "Fossil fuel economy"], "region": "Europe"},
    {"id": "BLR", "name": "Belarus", "score": 40, "status": "Highly Insufficient", "issues": ["Industrial emissions", "Lack of transparency"], "region": "Europe"},
    {"id": "TUR", "name": "Turkey", "score": 38, "status": "Critically Insufficient", "issues": ["Coal expansion", "Water stress"], "region": "Europe"},
    {"id": "CHE", "name": "Switzerland", "score": 68, "status": "Almost Sufficient", "issues": ["Glacier melting", "Financial sector emissions"], "region": "Europe"},
    {"id": "AUT", "name": "Austria", "score": 66, "status": "Almost Sufficient", "issues": ["Transport emissions", "Transit traffic"], "region": "Europe"},
    {"id": "BEL", "name": "Belgium", "score": 60, "status": "Insufficient", "issues": ["Industrial clusters", "Traffic congestion"], "region": "Europe"},
    {"id": "PRT", "name": "Portugal", "score": 65, "status": "Almost Sufficient", "issues": ["Forest fires", "Droughts"], "region": "Europe"},
    {"id": "GRC", "name": "Greece", "score": 58, "status": "Insufficient", "issues": ["Lignite phase-out", "Wildfires"], "region": "Europe"},

    # Asia
    {"id": "CHN", "name": "China", "score": 38, "status": "Highly Insufficient", "issues": ["Coal dependence", "Industrial pollution"], "region": "Asia"},
    {"id": "IND", "name": "India", "score": 55, "status": "Almost Sufficient", "issues": ["Air quality", "Waste management"], "region": "Asia"},
    {"id": "JPN", "name": "Japan", "score": 48, "status": "Insufficient", "issues": ["Fossil fuel financing", "Plastic waste"], "region": "Asia"},
    {"id": "KOR", "name": "South Korea", "score": 45, "status": "Highly Insufficient", "issues": ["Coal power", "Low renewable share"], "region": "Asia"},
    {"id": "IDN", "name": "Indonesia", "score": 40, "status": "Highly Insufficient", "issues": ["Coal exports", "Palm oil deforestation"], "region": "Asia"},
    {"id": "VNM", "name": "Vietnam", "score": 48, "status": "Insufficient", "issues": ["Coal expansion plans", "Mekong Delta risks"], "region": "Asia"},
    {"id": "THA", "name": "Thailand", "score": 46, "status": "Insufficient", "issues": ["Air pollution", "Plastic waste"], "region": "Asia"},
    {"id": "MYS", "name": "Malaysia", "score": 49, "status": "Insufficient", "issues": ["Deforestation", "Oil & Gas sector"], "region": "Asia"},
    {"id": "PHL", "name": "Philippines", "score": 50, "status": "Insufficient", "issues": ["Climate vulnerability", "Coal reliance"], "region": "Asia"},
    {"id": "PAK", "name": "Pakistan", "score": 45, "status": "Insufficient", "issues": ["Flood risks", "Water scarcity"], "region": "Asia"},
    {"id": "BGD", "name": "Bangladesh", "score": 52, "status": "Insufficient", "issues": ["Sea level rise", "Extreme weather"], "region": "Asia"},
    {"id": "SAU", "name": "Saudi Arabia", "score": 25, "status": "Critically Insufficient", "issues": ["Oil dependency", "Water desalination"], "region": "Asia"},
    {"id": "IRN", "name": "Iran", "score": 30, "status": "Critically Insufficient", "issues": ["Sanctions impact", "Fossil fuel subsidies"], "region": "Asia"},
    {"id": "IRQ", "name": "Iraq", "score": 28, "status": "Critically Insufficient", "issues": ["Gas flaring", "Water crisis"], "region": "Asia"},
    {"id": "KAZ", "name": "Kazakhstan", "score": 35, "status": "Critically Insufficient", "issues": ["Coal power", "Old industry"], "region": "Asia"},
    {"id": "MNG", "name": "Mongolia", "score": 40, "status": "Highly Insufficient", "issues": ["Air pollution", "Coal mining"], "region": "Asia"},

    # Africa
    {"id": "ZAF", "name": "South Africa", "score": 35, "status": "Critically Insufficient", "issues": ["Coal reliance", "Grid instability"], "region": "Africa"},
    {"id": "EGY", "name": "Egypt", "score": 45, "status": "Highly Insufficient", "issues": ["Water security", "Gas reliance"], "region": "Africa"},
    {"id": "NGA", "name": "Nigeria", "score": 50, "status": "Insufficient", "issues": ["Oil spills", "Gas flaring"], "region": "Africa"},
    {"id": "KEN", "name": "Kenya", "score": 65, "status": "Almost Sufficient", "issues": ["Droughts", "Geothermal expansion"], "region": "Africa"},
    {"id": "ETH", "name": "Ethiopia", "score": 60, "status": "Almost Sufficient", "issues": ["Hydro dam disputes", "Agriculture"], "region": "Africa"},
    {"id": "MAR", "name": "Morocco", "score": 68, "status": "Almost Sufficient", "issues": ["Solar expansion", "Water stress"], "region": "Africa"},
    {"id": "GHA", "name": "Ghana", "score": 55, "status": "Insufficient", "issues": ["Deforestation", "E-waste"], "region": "Africa"},
    {"id": "DZA", "name": "Algeria", "score": 35, "status": "Critically Insufficient", "issues": ["Oil & Gas reliance", "Desertification"], "region": "Africa"},
    {"id": "COD", "name": "DR Congo", "score": 50, "status": "Insufficient", "issues": ["Deforestation (Cobalt mining)", "Instability"], "region": "Africa"},

    # Oceania
    {"id": "AUS", "name": "Australia", "score": 42, "status": "Highly Insufficient", "issues": ["Coal exports", "Bushfire risks"], "region": "Oceania"},
    {"id": "NZL", "name": "New Zealand", "score": 65, "status": "Almost Sufficient", "issues": ["Agricultural methane", "Transport"], "region": "Oceania"},
    {"id": "PNG", "name": "Papua New Guinea", "score": 55, "status": "Insufficient", "issues": ["Illegal logging", "Mining"], "region": "Oceania"},

    # Others (Smaller nations filler)
    {"id": "ISL", "name": "Iceland", "score": 70, "status": "1.5°C Compatible", "issues": ["Heavy industry aluminum", "Glacier melt"], "region": "Europe"},
    {"id": "IRL", "name": "Ireland", "score": 60, "status": "Insufficient", "issues": ["Agricultural emissions", "Peat use"], "region": "Europe"},
    {"id": "CUB", "name": "Cuba", "score": 65, "status": "Almost Sufficient", "issues": ["Resource scarcity", "Sustainable agriculture"], "region": "Americas"},
    {"id": "SGP", "name": "Singapore", "score": 45, "status": "Critically Insufficient", "issues": ["Natural gas reliance", "Urban heat"], "region": "Asia"},
    {"id": "ARE", "name": "UAE", "score": 30, "status": "Critically Insufficient", "issues": ["High per capita footprint", "Fossil fuels"], "region": "Asia"},
    {"id": "QAT", "name": "Qatar", "score": 25, "status": "Critically Insufficient", "issues": ["Highest per capita CO2", "LNG exports"], "region": "Asia"},

    # --- Batch 2: Filling Gaps for "Every Country" ---
    # Eastern Europe & Baltics
    {"id": "EST", "name": "Estonia", "score": 60, "status": "Insufficient", "issues": ["Oil shale reliance", "Energy security"], "region": "Europe"},
    {"id": "LVA", "name": "Latvia", "score": 65, "status": "Almost Sufficient", "issues": ["Forestry", "Transport"], "region": "Europe"},
    {"id": "LTU", "name": "Lithuania", "score": 62, "status": "Almost Sufficient", "issues": ["Energy transition", "Waste"], "region": "Europe"},
    {"id": "CZE", "name": "Czechia", "score": 55, "status": "Insufficient", "issues": ["Coal power", "Energy efficiency"], "region": "Europe"},
    {"id": "SVK", "name": "Slovakia", "score": 58, "status": "Insufficient", "issues": ["Industrial emissions", "Car manufacturing"], "region": "Europe"},
    {"id": "HUN", "name": "Hungary", "score": 50, "status": "Insufficient", "issues": ["Rule of law concerns impacting green funds", "Nuclear dependency"], "region": "Europe"},
    {"id": "ROU", "name": "Romania", "score": 55, "status": "Insufficient", "issues": ["Illegal logging", "Energy infrastructure"], "region": "Europe"},
    {"id": "BGR", "name": "Bulgaria", "score": 48, "status": "Insufficient", "issues": ["Coal phase-out", "Pollution"], "region": "Europe"},

    # Central Asia & Middle East
    {"id": "AFG", "name": "Afghanistan", "score": 40, "status": "Critically Insufficient", "issues": ["Droughts", "Instability"], "region": "Asia"},
    {"id": "UZB", "name": "Uzbekistan", "score": 35, "status": "Critically Insufficient", "issues": ["Water usage (Cotton)", "Gas reliance"], "region": "Asia"},
    {"id": "TKM", "name": "Turkmenistan", "score": 20, "status": "Critically Insufficient", "issues": ["Massive methane leaks", "Opaque data"], "region": "Asia"},
    {"id": "ISR", "name": "Israel", "score": 58, "status": "Insufficient", "issues": ["Solar adoption lag", "Water tech"], "region": "Asia"},
    {"id": "JOR", "name": "Jordan", "score": 60, "status": "Almost Sufficient", "issues": ["Water scarcity", "Solar potential"], "region": "Asia"},

    # Africa (Expanded)
    {"id": "TZA", "name": "Tanzania", "score": 55, "status": "Insufficient", "issues": ["Deforestation", "Population growth"], "region": "Africa"},
    {"id": "UGA", "name": "Uganda", "score": 58, "status": "Insufficient", "issues": ["Oil pipeline (EACOP)", "Agriculture"], "region": "Africa"},
    {"id": "AGO", "name": "Angola", "score": 45, "status": "Highly Insufficient", "issues": ["Oil dependency", "Inequality"], "region": "Africa"},
    {"id": "MOZ", "name": "Mozambique", "score": 50, "status": "Insufficient", "issues": ["Gas projects", "Cyclone vulnerability"], "region": "Africa"},
    {"id": "ZMB", "name": "Zambia", "score": 55, "status": "Insufficient", "issues": ["Hydro drought risk", "Mining"], "region": "Africa"},
    {"id": "ZWE", "name": "Zimbabwe", "score": 40, "status": "Highly Insufficient", "issues": ["Coal power", "Agriculture"], "region": "Africa"},
    {"id": "SDN", "name": "Sudan", "score": 35, "status": "Critically Insufficient", "issues": ["Climate conflict", "Desertification"], "region": "Africa"},
    {"id": "SEN", "name": "Senegal", "score": 60, "status": "Almost Sufficient", "issues": ["Coastal erosion", "Green wall"], "region": "Africa"},

    # Americas (Central & Caribbean)
    {"id": "CRI", "name": "Costa Rica", "score": 80, "status": "1.5°C Compatible", "issues": ["Transport emissions", "Eco-tourism"], "region": "Americas"},
    {"id": "PAN", "name": "Panama", "score": 75, "status": "1.5°C Compatible", "issues": ["Canal water levels", "Forestry"], "region": "Americas"},
    {"id": "GTM", "name": "Guatemala", "score": 50, "status": "Insufficient", "issues": ["Deforestation", "Agriculture"], "region": "Americas"},
    {"id": "DOM", "name": "Dominican Republic", "score": 52, "status": "Insufficient", "issues": ["Disaster risk", "Tourism impact"], "region": "Americas"},
    {"id": "URY", "name": "Uruguay", "score": 70, "status": "1.5°C Compatible", "issues": ["Cattle methane", "Renewable grid"], "region": "Americas"},

    # --- Batch 3: Completion to 200+ Countries ---
    # Eastern Europe & Balkans
    {"id": "ALB", "name": "Albania", "score": 62, "status": "Almost Sufficient", "issues": ["Hydropower reliance", "Waste management"], "region": "Europe"},
    {"id": "BIH", "name": "Bosnia and Herzegovina", "score": 45, "status": "Highly Insufficient", "issues": ["Coal heating", "Air pollution"], "region": "Europe"},
    {"id": "HRV", "name": "Croatia", "score": 58, "status": "Insufficient", "issues": ["Tourism impact", "Waste"], "region": "Europe"},
    {"id": "MDA", "name": "Moldova", "score": 55, "status": "Insufficient", "issues": ["Energy dependence", "Agriculture"], "region": "Europe"},
    {"id": "MNE", "name": "Montenegro", "score": 50, "status": "Insufficient", "issues": ["Coal power plant", "Biodiversity"], "region": "Europe"},
    {"id": "MKD", "name": "North Macedonia", "score": 48, "status": "Highly Insufficient", "issues": ["Lignite", "Air quality"], "region": "Europe"},
    {"id": "SRB", "name": "Serbia", "score": 40, "status": "Critically Insufficient", "issues": ["Coal mining", "Industrial pollution"], "region": "Europe"},
    {"id": "SVN", "name": "Slovenia", "score": 60, "status": "Insufficient", "issues": ["Transport", "Nuclear debate"], "region": "Europe"},
    {"id": "XKX", "name": "Kosovo", "score": 35, "status": "Critically Insufficient", "issues": ["Lignite power", "Air pollution"], "region": "Europe"},
    {"id": "CYP", "name": "Cyprus", "score": 52, "status": "Insufficient", "issues": ["Water stress", "Fossil fuel electricity"], "region": "Europe"},
    {"id": "MLT", "name": "Malta", "score": 55, "status": "Insufficient", "issues": ["Transport congestion", "Energy imports"], "region": "Europe"},
    {"id": "AND", "name": "Andorra", "score": 70, "status": "1.5°C Compatible", "issues": ["Ski tourism impact", "Transport"], "region": "Europe"},
    {"id": "LIE", "name": "Liechtenstein", "score": 72, "status": "1.5°C Compatible", "issues": ["Financial sector", "Commuter traffic"], "region": "Europe"},
    {"id": "MCO", "name": "Monaco", "score": 65, "status": "Almost Sufficient", "issues": ["Urban density", "Marine protection"], "region": "Europe"},
    {"id": "SMR", "name": "San Marino", "score": 60, "status": "Insufficient", "issues": ["Transport", "Waste"], "region": "Europe"},
    {"id": "VAT", "name": "Vatican City", "score": 80, "status": "1.5°C Compatible", "issues": ["Solar rooftop", "Water conservation"], "region": "Europe"},

    # Asia (Remaining)
    {"id": "ARM", "name": "Armenia", "score": 55, "status": "Insufficient", "issues": ["Nuclear safety", "Mining"], "region": "Asia"},
    {"id": "AZE", "name": "Azerbaijan", "score": 35, "status": "Critically Insufficient", "issues": ["Oil & Gas economy", "Caspian pollution"], "region": "Asia"},
    {"id": "GEO", "name": "Georgia", "score": 58, "status": "Insufficient", "issues": ["Hydropower", "Industrial legacy"], "region": "Asia"},
    {"id": "BHR", "name": "Bahrain", "score": 28, "status": "Critically Insufficient", "issues": ["Oil dependency", "Water desalination"], "region": "Asia"},
    {"id": "KWT", "name": "Kuwait", "score": 25, "status": "Critically Insufficient", "issues": ["Extreme heat", "Oil exports"], "region": "Asia"},
    {"id": "OMN", "name": "Oman", "score": 35, "status": "Critically Insufficient", "issues": ["Oil & Gas", "Water scarcity"], "region": "Asia"},
    {"id": "YEM", "name": "Yemen", "score": 20, "status": "Critically Insufficient", "issues": ["War damage", "Water crisis"], "region": "Asia"},
    {"id": "LBN", "name": "Lebanon", "score": 45, "status": "Highly Insufficient", "issues": ["Waste crisis", "Generator pollution"], "region": "Asia"},
    {"id": "SYR", "name": "Syria", "score": 25, "status": "Critically Insufficient", "issues": ["Conflict pollution", "Drought"], "region": "Asia"},
    {"id": "KGZ", "name": "Kyrgyzstan", "score": 50, "status": "Insufficient", "issues": ["Glacier melt", "Coal heating"], "region": "Asia"},
    {"id": "TJK", "name": "Tajikistan", "score": 52, "status": "Insufficient", "issues": ["Glacier types", "Hydro reliance"], "region": "Asia"},
    {"id": "BTN", "name": "Bhutan", "score": 90, "status": "1.5°C Compatible", "issues": ["Carbon negative status", "Hydro exports"], "region": "Asia"},
    {"id": "NPL", "name": "Nepal", "score": 60, "status": "Almost Sufficient", "issues": ["Glacier melt", "Biomass burning"], "region": "Asia"},
    {"id": "LKA", "name": "Sri Lanka", "score": 58, "status": "Insufficient", "issues": ["Organic farming transition", "Waste"], "region": "Asia"},
    {"id": "MDV", "name": "Maldives", "score": 65, "status": "Almost Sufficient", "issues": ["Sea level rise", "Diesel reliance"], "region": "Asia"},
    {"id": "MMR", "name": "Myanmar", "score": 45, "status": "Highly Insufficient", "issues": ["Deforestation", "Conflict"], "region": "Asia"},
    {"id": "LAO", "name": "Laos", "score": 50, "status": "Insufficient", "issues": ["Hydro dams (Mekong)", "Mining"], "region": "Asia"},
    {"id": "KHM", "name": "Cambodia", "score": 48, "status": "Insufficient", "issues": ["Deforestation", "Hydro impacts"], "region": "Asia"},
    {"id": "BRN", "name": "Brunei", "score": 40, "status": "Highly Insufficient", "issues": ["Oil wealth", "Forest conservation"], "region": "Asia"},
    {"id": "TLS", "name": "Timor-Leste", "score": 55, "status": "Insufficient", "issues": ["Oil dependency", "Climate vulnerability"], "region": "Asia"},
    {"id": "PRK", "name": "North Korea", "score": 30, "status": "Critically Insufficient", "issues": ["Coal reliance", "Deforestation"], "region": "Asia"},

    # Africa (Remaining - Extensive)
    {"id": "BEN", "name": "Benin", "score": 55, "status": "Insufficient", "issues": ["Coastal erosion", "Agriculture"], "region": "Africa"},
    {"id": "BFA", "name": "Burkina Faso", "score": 50, "status": "Insufficient", "issues": ["Desertification", "Land degradation"], "region": "Africa"},
    {"id": "CPV", "name": "Cabo Verde", "score": 65, "status": "Almost Sufficient", "issues": ["Water scarcity", "Renewable transition"], "region": "Africa"},
    {"id": "CMR", "name": "Cameroon", "score": 50, "status": "Insufficient", "issues": ["Deforestation", "Oil"], "region": "Africa"},
    {"id": "CAF", "name": "Central African Republic", "score": 40, "status": "Highly Insufficient", "issues": ["Logging", "Instability"], "region": "Africa"},
    {"id": "TCD", "name": "Chad", "score": 35, "status": "Critically Insufficient", "issues": ["Lake Chad shrinking", "Oil"], "region": "Africa"},
    {"id": "COM", "name": "Comoros", "score": 60, "status": "Insufficient", "issues": ["Climate vulnerability", "Agriculture"], "region": "Africa"},
    {"id": "COG", "name": "Congo", "score": 55, "status": "Insufficient", "issues": ["Peatlands protection", "Oil"], "region": "Africa"},
    {"id": "CIV", "name": "Côte d'Ivoire", "score": 50, "status": "Insufficient", "issues": ["Cocoa deforestation", "Biomass"], "region": "Africa"},
    {"id": "DJI", "name": "Djibouti", "score": 55, "status": "Insufficient", "issues": ["Heat stress", "Port pollution"], "region": "Africa"},
    {"id": "GNQ", "name": "Equatorial Guinea", "score": 40, "status": "Highly Insufficient", "issues": ["Oil dependency", "Forestry"], "region": "Africa"},
    {"id": "ERI", "name": "Eritrea", "score": 45, "status": "Highly Insufficient", "issues": ["Land degradation", "Energy access"], "region": "Africa"},
    {"id": "SWZ", "name": "Eswatini", "score": 52, "status": "Insufficient", "issues": ["Sugar harvesting", "Water"], "region": "Africa"},
    {"id": "GAB", "name": "Gabon", "score": 75, "status": "1.5°C Compatible", "issues": ["Forest conservation leader", "Oil transition"], "region": "Africa"},
    {"id": "GMB", "name": "Gambia", "score": 68, "status": "1.5°C Compatible", "issues": ["Renewable projects", "Coastal risk"], "region": "Africa"},
    {"id": "GIN", "name": "Guinea", "score": 50, "status": "Insufficient", "issues": ["Bauxite mining", "Hydro"], "region": "Africa"},
    {"id": "GNB", "name": "Guinea-Bissau", "score": 52, "status": "Insufficient", "issues": ["Cashew farming", "Mangroves"], "region": "Africa"},
    {"id": "LSO", "name": "Lesotho", "score": 55, "status": "Insufficient", "issues": ["Soil erosion", "Water export"], "region": "Africa"},
    {"id": "LBR", "name": "Liberia", "score": 50, "status": "Insufficient", "issues": ["Rubber plantations", "Logging"], "region": "Africa"},
    {"id": "LBY", "name": "Libya", "score": 30, "status": "Critically Insufficient", "issues": ["Oil spills", "Water crisis"], "region": "Africa"},
    {"id": "MDG", "name": "Madagascar", "score": 45, "status": "Highly Insufficient", "issues": ["Deforestation", "Famine risk"], "region": "Africa"},
    {"id": "MWI", "name": "Malawi", "score": 55, "status": "Insufficient", "issues": ["Deforestation for charcoal", "Hydro"], "region": "Africa"},
    {"id": "MLI", "name": "Mali", "score": 48, "status": "Insufficient", "issues": ["Desertification", "Conflict"], "region": "Africa"},
    {"id": "MRT", "name": "Mauritania", "score": 50, "status": "Insufficient", "issues": ["Iron ore mining", "Desertification"], "region": "Africa"},
    {"id": "MUS", "name": "Mauritius", "score": 60, "status": "Almost Sufficient", "issues": ["Coal usage", "Tourism"], "region": "Africa"},
    {"id": "NAM", "name": "Namibia", "score": 65, "status": "Almost Sufficient", "issues": ["Green Hydrogen potential", "Drought"], "region": "Africa"},
    {"id": "NER", "name": "Niger", "score": 45, "status": "Highly Insufficient", "issues": ["Uranium mining", "Population"], "region": "Africa"},
    {"id": "RWA", "name": "Rwanda", "score": 65, "status": "Almost Sufficient", "issues": ["Plastic ban", "Dense population"], "region": "Africa"},
    {"id": "STP", "name": "Sao Tome and Principe", "score": 58, "status": "Insufficient", "issues": ["Oil exploration", "Development"], "region": "Africa"},
    {"id": "SYC", "name": "Seychelles", "score": 70, "status": "1.5°C Compatible", "issues": ["Blue economy", "Rising seas"], "region": "Africa"},
    {"id": "SLE", "name": "Sierra Leone", "score": 50, "status": "Insufficient", "issues": ["Mining", "Deforestation"], "region": "Africa"},
    {"id": "SOM", "name": "Somalia", "score": 25, "status": "Critically Insufficient", "issues": ["Charcoal trade", "Drought"], "region": "Africa"},
    {"id": "SSD", "name": "South Sudan", "score": 30, "status": "Critically Insufficient", "issues": ["Oil conflict", "Floods"], "region": "Africa"},
    {"id": "TGO", "name": "Togo", "score": 55, "status": "Insufficient", "issues": ["Phosphate mining", "Erosion"], "region": "Africa"},
    {"id": "TUN", "name": "Tunisia", "score": 60, "status": "Almost Sufficient", "issues": ["Water stress", "Solar"], "region": "Africa"},
    {"id": "BWA", "name": "Botswana", "score": 50, "status": "Insufficient", "issues": ["Coal power", "Diamond mining"], "region": "Africa"},
    {"id": "BDI", "name": "Burundi", "score": 45, "status": "Highly Insufficient", "issues": ["Land degradation", "Poverty"], "region": "Africa"},


    # Americas (Caribbean & Others)
    {"id": "BLZ", "name": "Belize", "score": 70, "status": "1.5°C Compatible", "issues": ["Coral reef protection", "Oil ban"], "region": "Americas"},
    {"id": "SLV", "name": "El Salvador", "score": 55, "status": "Insufficient", "issues": ["Geothermal", "Water pollution"], "region": "Americas"},
    {"id": "HND", "name": "Honduras", "score": 50, "status": "Insufficient", "issues": ["Deforestation", "Hurricanes"], "region": "Americas"},
    {"id": "NIC", "name": "Nicaragua", "score": 52, "status": "Insufficient", "issues": ["Canal project", "Deforestation"], "region": "Americas"},
    {"id": "PRY", "name": "Paraguay", "score": 60, "status": "Almost Sufficient", "issues": ["Hydro surplus", "Deforestation (Chaco)"], "region": "Americas"},
    {"id": "SUR", "name": "Suriname", "score": 85, "status": "1.5°C Compatible", "issues": ["Carbon negative leader", "Oil discovery"], "region": "Americas"},
    {"id": "GUY", "name": "Guyana", "score": 40, "status": "Highly Insufficient", "issues": ["Massive oil boom", "Forest protection"], "region": "Americas"},
    {"id": "JAM", "name": "Jamaica", "score": 55, "status": "Insufficient", "issues": ["Bauxite mining", "Energy costs"], "region": "Americas"},
    {"id": "HTI", "name": "Haiti", "score": 30, "status": "Critically Insufficient", "issues": ["Deforestation", "Disaster recovery"], "region": "Americas"},
    {"id": "BHS", "name": "Bahamas", "score": 60, "status": "Insufficient", "issues": ["Hurricane risk", "Diesel"], "region": "Americas"},
    {"id": "BRB", "name": "Barbados", "score": 65, "status": "Almost Sufficient", "issues": ["Renewable target 100%", "Water"], "region": "Americas"},
    {"id": "TTO", "name": "Trinidad and Tobago", "score": 35, "status": "Critically Insufficient", "issues": ["Oil & Gas", "Industrial emissions"], "region": "Americas"},

    # Oceania (Pacific Islands)
    {"id": "FJI", "name": "Fiji", "score": 65, "status": "Almost Sufficient", "issues": ["Climate leadership", "Cyclones"], "region": "Oceania"},
    {"id": "KIR", "name": "Kiribati", "score": 50, "status": "Insufficient", "issues": ["Existential sea rise", "Water"], "region": "Oceania"},
    {"id": "MHL", "name": "Marshall Islands", "score": 55, "status": "Insufficient", "issues": ["Nuclear legacy", "Sea rise"], "region": "Oceania"},
    {"id": "FSM", "name": "Micronesia", "score": 55, "status": "Insufficient", "issues": ["Waste", "Fishing"], "region": "Oceania"},
    {"id": "NRU", "name": "Nauru", "score": 40, "status": "Highly Insufficient", "issues": ["Phosphate damage", "Refugee center"], "region": "Oceania"},
    {"id": "PLW", "name": "Palau", "score": 60, "status": "Almost Sufficient", "issues": ["Marine protection", "Tourism"], "region": "Oceania"},
    {"id": "WSM", "name": "Samoa", "score": 60, "status": "Almost Sufficient", "issues": ["Renewable goals", "Cyclones"], "region": "Oceania"},
    {"id": "SLB", "name": "Solomon Islands", "score": 50, "status": "Insufficient", "issues": ["Logging", "Mining"], "region": "Oceania"},
    {"id": "TON", "name": "Tonga", "score": 55, "status": "Insufficient", "issues": ["Volcano risk", "Energy"], "region": "Oceania"},
    {"id": "TUV", "name": "Tuvalu", "score": 50, "status": "Insufficient", "issues": ["Sinking islands", "Water"], "region": "Oceania"},
    {"id": "VUT", "name": "Vanuatu", "score": 60, "status": "Almost Sufficient", "issues": ["Climate justice leader", "Disasters"], "region": "Oceania"}
]

# --- Populate Remaining Countries ---
from country_data_names import country_names
import random 

existing_ids = {item["id"] for item in global_sustainability_data}

for iso, name in country_names.items():
    if iso not in existing_ids:
        # Generate random mock data for missing countries
        score = random.randint(30, 70)
        
        # Determine status based on score
        if score >= 60: status = "Almost Sufficient"
        elif score >= 50: status = "Insufficient"
        elif score >= 40: status = "Highly Insufficient"
        else: status = "Critically Insufficient"
            
        global_sustainability_data.append({
            "id": iso,
            "name": name,
            "score": score,
            "status": status,
            "issues": ["Data unavailable"],
            "region": "Global" 
        })

@app.route('/api/global-map-data', methods=['GET'])
def get_global_map_data():
    # Return rankings_db which now has extended data (SDG scores + Status)
    # Ensure it's sorted by ID or Name for consistency if needed, but Map handles ID matching
    return jsonify(rankings_db)


# --- Country Detail Report Data ---
country_reports_db = {
    "india": {
        "title": "India's Path to Sustainability",
        "hero_image": "/assets/future_green_city.png",
        "description": "India is undertaking one of the world's most ambitious energy transitions. With a target of 500GW renewable energy by 2030, the nation is rapidly deploying solar and wind infrastructure.",
        "sections": [
            {
                "title": "Renewable Energy Revolution",
                "content": "India has achieved its NDC target of 40% non-fossil fuel capacity 9 years ahead of schedule. The International Solar Alliance (ISA), headquartered in Gurugram, showcases global leadership.",
                "image": "/assets/renewable_energy.jpg"
            },
            {
                "title": "Green Hydrogen Mission",
                "content": "The National Green Hydrogen Mission aims to make India a global hub for production and export, targeting 5 MMT per annum by 2030.",
                "image": "/assets/bg_nature.png"
            }
        ],
        "stats": {
            "renewable_share": "42%",
            "emissions_per_capita": "1.9t",
            "forest_cover": "24.6%"
        }
    },
    "usa": {
        "title": "USA: The Green Deal Era",
        "hero_image": "/assets/future_green_city.png",
        "description": "The United States is leveraging the Inflation Reduction Act to drive massive investment in green technology, EV adoption, and grid modernization.",
        "sections": [
            {
                "title": "Clean Energy Investment",
                "content": "Billions of dollars are flowing into battery manufacturing and solar supply chains, creating a domestic green economy boom.",
                "image": "/assets/renewable_energy.jpg"
            },
            {
                "title": "Conservation Efforts",
                "content": "New initiatives to protect 30% of lands and waters by 2030 are underway to preserve biodiversity.",
                "image": "/assets/bg_nature.png"
            }
        ],
        "stats": {
            "renewable_share": "25%",
            "emissions_per_capita": "14.7t",
            "forest_cover": "33.9%"
        }
    }
}

@app.route('/api/country-report/<country_id>', methods=['GET'])
def get_country_report(country_id):
    """Get detailed report for a country."""
    c_id = country_id.upper()
    
    # Try finding in global data
    map_data = next((item for item in global_sustainability_data if item["id"].upper() == c_id or item["name"].upper() == c_id), None)
    if not map_data:
        map_data = next((item for item in global_sustainability_data if item["name"].lower() == country_id.lower()), None)
    
    country_name = map_data['name'] if map_data else country_id.upper()
    score = map_data['score'] if map_data else 50
    
    # Generate Flag URL
    iso2 = iso3_to_iso2.get(map_data['id'] if map_data else c_id[:2], "IN").lower()
    flag_url = f"https://flagcdn.com/w1280/{iso2}.png"

    # Generate Metrics based on Score (Mock logic for realism)
    # Higher score -> Higher renewable, Higher forest, Lower CO2
    import random
    renewable = min(95, max(5, int(score * 0.8 + random.randint(-5, 5))))
    forest = min(80, max(10, int(score * 0.6 + random.randint(-5, 5))))
    co2 = round(max(0.5, 15 - (score / 10) + random.uniform(-1, 1)), 1)

    report = {
        "title": f"Sustainability in {country_name}",
        "hero_image": flag_url,
        "flag": flag_url,
        "description": f"{country_name} is facing unique climate challenges and opportunities. From adapting to changing weather patterns to transitioning energy sources, the journey is underway.",
        "sections": [
            {
                "title": "Climate Action Status",
                "content": f"Current data suggests {country_name} is taking steps, but more accelerated action is needed to meet Paris Agreement goals.",
                "image": "/assets/renewable_energy.jpg"
            },
            {
                "title": "Natural Heritage",
                "content": "Preserving local ecosystems is critical. Efforts to protect forests, wetlands, and marine life are essential for long-term resilience.",
                "image": "/assets/bg_nature.png"
            }
        ],
        "stats": {
            "renewable_share": f"{renewable}%",
            "emissions_per_capita": f"{co2}t",
            "forest_cover": f"{forest}%"
        }
    }
    return jsonify(report)


# --- Country Profile API ---

@app.route('/api/countries', methods=['GET'])
def get_all_countries():
    """Returns list of countries for the profile directory."""
    # Use global_sustainability_data as the base
    countries_list = []
    for c in global_sustainability_data:
        # Get ISO-2 code for flag, fallback to slicing if missing (unlikely with full map)
        iso2 = iso3_to_iso2.get(c["id"], c["id"][:2]).lower()
        
        countries_list.append({
            "id": c["id"],
            "name": c["name"],
            "flag": f"https://flagcdn.com/w320/{iso2}.png",
            "score": c["score"],
            "region": c.get("region", "Global")
        })
    return jsonify(countries_list)

def generate_mock_charts(country_id):
    """Generates consistent mock chart data based on country ID."""
    random.seed(country_id) # Consistent data per country
    
    years = [2020, 2021, 2022, 2023, 2024, 2025]
    
    # Coal Dependency (Trending down usually)
    coal_start = random.randint(20, 60)
    coal_data = [max(0, coal_start - (i * random.uniform(2, 5))) for i in range(len(years))]
    
    # Renewable Adoption (Trending up)
    renew_start = random.randint(10, 40)
    renew_data = [min(100, renew_start + (i * random.uniform(3, 8))) for i in range(len(years))]
    
    # Green Hydrogen (Starting low, exponential growth)
    hydrogen_data = [0, 1, 3, 8, 15, 25]

    # Natural Resources Data
    forest_cover = [random.randint(20, 60) + (i * random.uniform(-0.5, 0.5)) for i in range(len(years))]
    water_efficiency = [random.randint(40, 70) + (i * random.uniform(1, 3)) for i in range(len(years))]
    carbon_sequestration = [random.randint(100, 300) + (i * random.randint(5, 15)) for i in range(len(years))]
    
    return {
        "labels": years,
        "datasets": {
            "coal_dependency": coal_data,
            "renewable_adoption": renew_data,
            "green_hydrogen": hydrogen_data,
            "forest_cover": forest_cover,
            "water_efficiency": water_efficiency,
            "carbon_sequestration": carbon_sequestration
        }
    }

def generate_mock_sdgs(country_id):
    """Generates mock status for 17 SDGs with real titles and detailed indicators."""
    random.seed(country_id) # Consistent data per country
    
    sdg_data = [
        {
            "title": "No Poverty",
            "indicators": [
                {"name": "Poverty headcount ratio at $2.15/day", "scenario": "Inflation and food price spikes have pushed vulnerable populations back below the poverty line."},
                {"name": "Poverty headcount ratio at $3.65/day", "scenario": "Lack of social safety nets in rural areas impedes progress."}
            ]
        },
        {
            "title": "Zero Hunger",
            "indicators": [
                {"name": "Prevalence of undernourishment", "scenario": "Climate-induced crop failures have reduced local food availability."},
                {"name": "Prevalence of stunting in children", "scenario": "Poor access to nutritional supplements for infants."},
                {"name": "Sustainable Nitrogen Management", "scenario": "Overuse of fertilizers causing soil degradation.", "is_negative": True}
            ]
        },
        {
            "title": "Good Health and Well-being",
            "indicators": [
                {"name": "Maternal mortality ratio", "scenario": "Improved rural healthcare access has significantly lowered mortality rates."},
                {"name": "Incidence of tuberculosis", "scenario": "High population density in urban slums facilitates spread."},
                {"name": "Traffic deaths", "scenario": "Rapid urbanization without adequate road safety infrastructure."}
            ]
        },
        {
            "title": "Quality Education",
            "indicators": [
                {"name": "Net primary enrollment rate", "scenario": "Government 'Education for All' policy shows positive results."},
                {"name": "Lower secondary completion rate", "scenario": "Economic pressure forces youth to leave school for work."}
            ]
        },
        {
            "title": "Gender Equality",
            "indicators": [
                {"name": "Seats held by women in parliament", "scenario": "Quota system implementation has increased representation."},
                {"name": "Female labor force participation", "scenario": "Cultural barriers and lack of childcare facilities limit participation."}
            ]
        },
        {
            "title": "Clean Water and Sanitation",
            "indicators": [
                {"name": "Access to basic drinking water", "scenario": "Infrastructure projects in northern regions have come online."},
                {"name": "Access to basic sanitation", "scenario": "Rapid urbanization outpaces sanitation grid expansion."}
            ]
        },
        {
            "title": "Affordable and Clean Energy",
            "indicators": [
                {"name": "Population with access to electricity", "scenario": "Universal electrification program nearly complete."},
                {"name": "Share of renewable energy", "scenario": "Heavy reliance on coal persists despite new solar parks."}
            ]
        },
        {
            "title": "Decent Work and Economic Growth",
            "indicators": [
                {"name": "Adjusted GDP growth", "scenario": "Post-pandemic recovery is robust in service sectors."},
                {"name": "Unemployment rate", "scenario": "Youth unemployment remains high due to skills mismatch."}
            ]
        },
        {
            "title": "Industry, Innovation and Infrastructure",
            "indicators": [
                {"name": "Mobile broadband subscriptions", "scenario": "Digital revolution has achieved high penetration rates."},
                {"name": "Logistics performance index", "scenario": "Port congestion and poor roads hamper trade efficiency."}
            ]
        },
        {
            "title": "Reduced Inequalities",
            "indicators": [
                {"name": "Gini Coefficient", "scenario": "Wealth gap widening as tech sector grows faster than agriculture."},
                {"name": "Palma ratio", "scenario": "Top 10% income share is increasing relative to bottom 40%."}
            ]
        },
        {
            "title": "Sustainable Cities and Communities",
            "indicators": [
                {"name": "PM2.5 air pollution", "scenario": "Industrial emissions and crop burning cause severe smog."},
                {"name": "Access to improved water source", "scenario": "Urban pipe networks are aging and prone to leaks."}
            ]
        },
        {
            "title": "Responsible Consumption and Production",
            "indicators": [
                {"name": "Municipal solid waste", "scenario": "Lack of segregation at source complicates recycling efforts."},
                {"name": "Electronic waste", "scenario": "Rising gadget consumption without e-waste recycling facilities."}
            ]
        },
        {
            "title": "Climate Action",
            "indicators": [
                {"name": "CO2 emissions from fossil fuels", "scenario": "Energy demand growth is still met largely by thermal power."},
                {"name": "CO2 emissions embodied in imports", "scenario": "Importing high-carbon goods (steel, cement) for construction."}
            ]
        },
        {
            "title": "Life Below Water",
            "indicators": [
                {"name": "Ocean Health Index", "scenario": "Coastal runoff and industrial pollution affecting marine life."},
                {"name": "Fish caught from overexploited stocks", "scenario": "Illegal fishing practices remain unmonitored."}
            ]
        },
        {
            "title": "Life on Land",
            "indicators": [
                {"name": "Red List Index of species survival", "scenario": "Habitat loss due to urban expansion threatens local fauna."},
                {"name": "Permanent deforestation", "scenario": "Clearing land for palm oil and agriculture continues."}
            ]
        },
        {
            "title": "Peace, Justice and Strong Institutions",
            "indicators": [
                {"name": "Homicides per 100,000 population", "scenario": " improved policing has reduced violent crime rates."},
                {"name": "Corruption Perception Index", "scenario": "Bureaucratic transparency initiatives are slowly taking effect."}
            ]
        },
        {
            "title": "Partnerships for the Goals",
            "indicators": [
                {"name": "Government spending on health and education", "scenario": "Budget allocation below international recommended standards."},
                {"name": "Statistical performance index", "scenario": "Data collection systems modernized with digital census."}
            ]
        }
    ]
    
    # Statuses based on user reference image
    status_options = [
        {"status": "SDG Achieved", "color": "#28a745", "icon": "✓"},
        {"status": "Challenges Remain", "color": "#ffc107", "icon": "↗"},
        {"status": "Significant Challenges", "color": "#fd7e14", "icon": "→"},
        {"status": "Major Challenges", "color": "#dc3545", "icon": "↓"},
        {"status": "Regression", "color": "#000000", "icon": "↓"},
        {"status": "Information Unavailable", "color": "#6c757d", "icon": "•"}
    ]
    
    sdgs = []
    for i, item in enumerate(sdg_data, 1):
        # Overall SDG Status
        choice = random.choices(status_options, weights=[0.1, 0.2, 0.25, 0.2, 0.1, 0.05])[0]
        
        # Generate specific indicators with their own statuses
        specific_indicators = []
        for ind_data in item["indicators"]:
            # Random status for each indicator, slightly biased towards the main SDG status
            ind_choice = random.choices(status_options, k=1)[0]
            
            specific_indicators.append({
                "name": ind_data["name"],
                "status": ind_choice["status"],
                "color": ind_choice["color"],
                "icon": ind_choice["icon"],
                "scenario": ind_data["scenario"]
            })

        sdgs.append({
            "id": i,
            "title": item["title"], 
            "status": choice["status"],
            "color": choice["color"],
            "description": f"Overall status: {choice['status']}.", # Simplified description
            "specific_indicators": specific_indicators
        })
    return sdgs

@app.route('/api/country-profile/<country_id>', methods=['GET'])
def get_country_profile_detail(country_id):
    """Returns full profile for a specific country."""
    # Find basic data
    c_data = next((item for item in global_sustainability_data if item["id"].lower() == country_id.lower()), None)
    
    if not c_data:
        return jsonify({"error": "Country not found"}), 404

    # Generate rich data
    charts = generate_mock_charts(country_id)
    sdgs = generate_mock_sdgs(country_id)
    
    # Live Meter Logic
    score = c_data.get('score', 50)
    if score >= 75: meter_msg = "Environment is Safe"
    elif score >= 60: meter_msg = "Better"
    elif score >= 40: meter_msg = "Hazardous"
    else: meter_msg = "Not Safe"

    # Flag URL
    iso2 = iso3_to_iso2.get(c_data["id"], c_data["id"][:2]).lower()
    
    profile = {
        "id": c_data["id"],
        "name": c_data["name"],
        "flag_url": f"https://flagcdn.com/w640/{iso2}.png",
        "score": score,
        "score": score,
        "rank": next((r['rank_overall'] for r in rankings_db if r['id'] == c_data['id']), 0), # Actual Rank
        "total_countries": len(rankings_db) or 193, # Total Count
        "sdg_performance": sdgs,
        "live_meter": {
            "status": meter_msg,
            "score": score
        },
        "charts": charts,
        "region": c_data.get("region", "Global"),
        "description": f"{c_data['name']} is navigating complex sustainability challenges. Key focus areas include structured energy transition and biodiversity conservation.",
        "energy_mix": {
            "renewables": {
                "current": random.randint(10, 85),
                "history": [random.randint(10, 30) + x*random.randint(2, 5) for x in range(5)] # Increasing trend
            },
            "coal": {
                "current": random.randint(5, 60),
                "history": [random.randint(40, 80) - x*random.randint(1, 4) for x in range(5)] # Decreasing trend
            }
        }
    }
    
    return jsonify(profile)


# --- Rankings Widget Data & API ---

rankings_db = []

def generate_rankings_db():
    """Generates a consistent set of rankings for the session."""
    global rankings_db
    rankings_db = []
    
    print(f"Generating rankings for {len(global_sustainability_data)} countries...")
    
    for c in global_sustainability_data:
        # Determine base seed from ID to keep it consistent per country across restarts
        # but allow for variance if we want to simulate changes later
        random.seed(c["id"] + "ranking_v1")
        
        # Generate 17 SDG scores
        sdg_scores = {}
        total_score = 0
        
        # Bias scores based on the mock "status" in global data to make it realistic
        base_bias = 0
        if c.get("status") == "1.5°C Paris Compatible": base_bias = 30
        elif c.get("status") == "Almost Sufficient": base_bias = 15
        elif c.get("status") == "Critically Insufficient": base_bias = -20
        
        for i in range(1, 18):
            # Base score 50 + bias + random variance
            raw_score = 50 + base_bias + random.randint(-15, 25)
            # Clamp between 10 and 100
            final_score = max(10, min(99.9, raw_score))
            sdg_scores[f"sdg_{i}"] = round(final_score, 1)
            total_score += final_score
            
        overall_score = round(total_score / 17, 2)
        
        iso2 = iso3_to_iso2.get(c["id"], c["id"][:2]).lower()
        
        rankings_db.append({
            "id": c["id"],
            "name": c["name"],
            "flag": f"https://flagcdn.com/w320/{iso2}.png",
            "region": c.get("region", "Global"),
            "status": c.get("status", "Unknown"), # Add status
            "issues": c.get("issues", []), # Add issues
            "overall_score": overall_score,
            **sdg_scores # Unpack sdg_1 to sdg_17
        })
        
    # Sort initially by overall score
    rankings_db.sort(key=lambda x: x['overall_score'], reverse=True)
    
    # Assign initial ranks
    for idx, item in enumerate(rankings_db, 1):
        item['rank_overall'] = idx

# Generate on startup
generate_rankings_db()

@app.route('/api/rankings', methods=['GET'])
def get_rankings():
    """
    Returns filtered and sorted rankings.
    Query Params:
    - sort_by: 'overall' (default) or 'sdg_1'...'sdg_17'
    - region: 'All' (default) or specific region
    - search: Country name filter
    """
    sort_by = request.args.get('sort_by', 'overall_score') 
    if sort_by == 'overall': sort_by = 'overall_score'
    
    region = request.args.get('region', 'All')
    search = request.args.get('search', '').lower()
    
    # Filter
    filtered = rankings_db[:]
    if region != 'All':
        filtered = [r for r in filtered if r['region'] == region]
    if search:
        filtered = [r for r in filtered if search in r['name'].lower()]
        
    # Sort
    sort_key = sort_by
    # Helper to safely get Sort Value
    # If sort key is not found (e.g. invalid param), default to 0
    filtered.sort(key=lambda x: x.get(sort_key, 0), reverse=True)
    
    results = []
    for idx, item in enumerate(filtered, 1):
        results.append({
            **item,
            "rank_view": idx
        })
        
    return jsonify(results)

# --- Gemini AI Endpoints ---

@app.route('/api/eco-coach', methods=['POST'])
def eco_coach_chat():
    """
    Chat with the AI Eco-Coach.
    Expects JSON: { "query": "How do I compost?", "context": {...} }
    """
    data = request.json
    user_query = data.get('query', '')
    
    if not user_query:
        return jsonify({"coach_response": "I didn't catch that. Could you say it again?"}), 400

    try:
        # Check if API key is configured
        if not GEMINI_API_KEY or GEMINI_API_KEY == "YOUR_GEMINI_API_KEY_HERE":
             return jsonify({"coach_response": "My brain is offline! Please configure the Gemini API Key in the backend."}), 200

        model = genai.GenerativeModel('gemini-2.5-flash')
        
        # System Prompt construction
        system_prompt = """You are the 'Eco-Coach', a friendly, motivating, and knowledgeable AI assistant for a sustainability app. 
        Your goal is to help users reduce their environmental impact with practical, actionable advice.
        - Keep answers concise (under 3 sentences usually).
        - Use emojis 🌿🌍 ✨ to be engaging.
        - If the user asks about their stats, give a general encouraging response (since you don't have full database access yet).
        - Be positive and never judgmental.
        """

        model = genai.GenerativeModel(
            model_name='gemini-3-flash-preview',
            system_instruction=system_prompt
        )
        
        response = model.generate_content(user_query)
        return jsonify({"coach_response": response.text})
        
    except Exception as e:
        print(f"Gemini Error: {e}")
        return jsonify({"coach_response": "I'm having trouble connecting to the green grid right now. Try again later! 🔌"}), 500

@app.route('/api/scan-receipt', methods=['POST'])
def scan_receipt():
    print("DEBUG: /api/scan-receipt hit")
    """
    Analyze a receipt image using Gemini Vision.
    Expects multipart/form-data with 'file'.
    """
    # Import here or at top - moving PIL to top level is better practice but for now ensure it's imported
    import PIL.Image 
    
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
        
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    try:
        # Check if API key is configured
        if not GEMINI_API_KEY or GEMINI_API_KEY == "YOUR_GEMINI_API_KEY_HERE":
             return jsonify({
                 "items_detected": ["Mock Item A", "Mock Item B"],
                 "carbon_footprint_kg": 0.5,
                 "water_footprint_liters": 10,
                 "eco_score": "Moderate",
                 "suggestion": "API Key detected missing. This is a mock response."
             })

        # Load image for Gemini
        import PIL.Image
        img = PIL.Image.open(file)
        
        model = genai.GenerativeModel('gemini-3-flash-preview')

        # 1. Ask Gemini to identify items only
        prompt = """
        Analyze this receipt image. 
        Extract the list of purchased items.
        For each item, identify:
        1. The simplified Name (e.g., 'Milk', 'Beef Steak', 'Apple').
        2. The Category (Meat, Dairy, Fruit, Vegetable, Grain, Beverage, Snack, Household, Other).
        
        Return ONLY valid JSON in this format:
        {
            "items": [
                {"name": "Item Name", "category": "Category"},
                ...
            ]
        }
        """
        
        response = model.generate_content([prompt, img])
        
        # Parse JSON
        text = response.text
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0]
        elif "```" in text:
            text = text.split("```")[1].split("```")[0]
            
        data = json.loads(text.strip())
        detected_items = data.get("items", [])
        
        # 2. Calculate Carbon Footprint using Local DB
        total_carbon = 0.0
        final_items_list = []
        
        for item in detected_items:
            name = item.get("name", "Unknown")
            category = item.get("category", "Other")
            
            # Try specific lookup
            footprint, match = get_carbon_footprint(name)
            
            # Fallback to category lookup
            if footprint == 0.0:
                 footprint, match = get_carbon_footprint(category)
                 
            # Final Safety Net
            if footprint == 0.0:
                footprint = 1.0 # Default unknown assumption
                
            total_carbon += footprint
            final_items_list.append(f"{name} ({footprint}kg)")
            
        # 3. Calculate Water Footprint (Rough heuristic: Carbon * 100 liters/kg avg)
        total_water = total_carbon * 50 
        
        # 4. Determine Score
        if total_carbon < 5:
            score = "Low"
            suggestion = "Great job! Your basket is very eco-friendly."
        elif total_carbon < 15:
            score = "Moderate"
            suggestion = "Not bad! Try swapping red meat for poultry next time."
        else:
            score = "High"
            suggestion = "Consider more plant-based alternatives to reduce this footprint."
            
        # Refine suggestion based on highest impact item
        # (Simple logic: if beef detected, warn about beef)
        for item in detected_items:
            if "beef" in item.get("name", "").lower():
                suggestion = "Beef has a high carbon footprint. Swapping for chicken saves ~20kg CO2 per kg!"
                break

        return jsonify({
            "items_detected": final_items_list,
            "carbon_footprint_kg": round(total_carbon, 2),
            "water_footprint_liters": round(total_water, 0),
            "eco_score": score,
            "suggestion": suggestion
        })

    except Exception as e:
        print(f"Gemini Vision Error: {e}")
        return jsonify({
            "error": str(e),
            "items_detected": [],
            "carbon_footprint_kg": 0,
            "water_footprint_liters": 0,
            "eco_score": "Error",
            "suggestion": f"Analysis failed: {str(e)}"
        }), 500

# --- Receipt Photo Storage Endpoints ---
UPLOAD_FOLDER = 'uploads/receipts'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB
RECEIPTS_DB_FILE = 'receipts_db.json'

# Ensure upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_receipts_db():
    try:
        with open(RECEIPTS_DB_FILE, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {'receipts': []}

def save_receipts_db(data):
    with open(RECEIPTS_DB_FILE, 'w') as f:
        json.dump(data, f, indent=2)

@app.route('/api/upload-receipt', methods=['POST'])
def upload_receipt():
    try:
        # Check if file is in request
        if 'receipt' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['receipt']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type. Allowed: png, jpg, jpeg, gif'}), 400
        
        # Get user ID from form data
        user_id = request.form.get('user_id', 'anonymous')
        
        # Generate unique filename
        from datetime import datetime
        from werkzeug.utils import secure_filename
        timestamp = int(datetime.now().timestamp())
        original_filename = secure_filename(file.filename)
        unique_filename = f"{user_id}_{timestamp}_{original_filename}"
        
        # Save file
        filepath = os.path.join(UPLOAD_FOLDER, unique_filename)
        file.save(filepath)
        
        # Load receipts database
        receipts_data = load_receipts_db()
        
        # Create receipt record
        receipt_record = {
            'id': timestamp,
            'user_id': user_id,
            'filename': unique_filename,
            'filepath': filepath,
            'uploaded_at': datetime.now().isoformat(),
            'original_filename': original_filename
        }
        
        # Add to database
        receipts_data['receipts'].append(receipt_record)
        save_receipts_db(receipts_data)
        
        return jsonify({
            'success': True,
            'receipt_id': timestamp,
            'file_url': f'/api/receipts/{unique_filename}',
            'message': 'Receipt uploaded successfully'
        }), 200
        
    except Exception as e:
        print(f"Upload error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/receipts/<filename>', methods=['GET'])
def get_receipt_file(filename):
    try:
        from flask import send_from_directory
        return send_from_directory(UPLOAD_FOLDER, filename)
    except Exception as e:
        return jsonify({'error': 'File not found'}), 404

@app.route('/api/user-receipts/<user_id>', methods=['GET'])
def get_user_receipts(user_id):
    try:
        receipts_data = load_receipts_db()
        user_receipts = [r for r in receipts_data['receipts'] if r['user_id'] == user_id]
        
        # Add full URLs to receipts
        for receipt in user_receipts:
            receipt['file_url'] = f'/api/receipts/{receipt["filename"]}'
        
        return jsonify({
            'success': True,
            'count': len(user_receipts),
            'receipts': user_receipts
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/all-receipts', methods=['GET'])
def get_all_receipts():
    try:
        receipts_data = load_receipts_db()
        
        # Add full URLs to receipts
        for receipt in receipts_data['receipts']:
            receipt['file_url'] = f'/api/receipts/{receipt["filename"]}'
        
        return jsonify({
            'success': True,
            'count': len(receipts_data['receipts']),
            'receipts': receipts_data['receipts']
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
