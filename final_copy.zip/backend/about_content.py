
# Extensive content for the About section
# This file segregates the large text content from the main application logic.

about_data = {
    "topics": [
        {
            "id": "sustainable_development",
            "title": "Sustainable Development",
            "short_desc": "A holistic approach to meeting present needs without compromising the future.",
            "icon": "globe", # FontAwesome class suffix: fa-globe
            "color": "#4CAF50",
            "image": "https://images.pexels.com/photos/1072824/pexels-photo-1072824.jpeg?auto=compress&cs=tinysrgb&w=800",
            "full_content": """
                <h2>What is Sustainable Development?</h2>
                <p>Sustainable development is the organizing principle for meeting human development goals while simultaneously sustaining the ability of natural systems to provide the natural resources and ecosystem services on which the economy and society depend. The desired result is a state of society where living conditions and resources are used to continue to meet human needs without undermining the integrity and stability of the natural system.</p>
                
                <h3>The Three Pillars</h3>
                <p>Sustainable development can be thought of in terms of three spheres, dimensions, domains or pillars: the environment, the economy and society. The three-sphere framework was initially proposed by the economist René Passet in 1979.</p>
                <ul>
                    <li><strong>Environmental Sustainability:</strong> Ecological integrity is kept, all of earth's environmental systems are kept in balance while natural resources within them are consumed by humans at a rate where they are able to replenish themselves.</li>
                    <li><strong>Economic Sustainability:</strong> Human communities across the globe are able to maintain their independence and have access to the resources that they require, financial and other, to meet their needs. Economic systems are intact and activities are available to everyone, such as secure sources of livelihood.</li>
                    <li><strong>Social Sustainability:</strong> Universal human rights and basic necessities are attainable by all people, who have access to enough resources to keep their families and communities healthy and secure. Healthy communities have just leaders who ensure personal, labour and cultural rights are respected and all people are protected from discrimination.</li>
                </ul>

                <h3>History and Context</h3>
                <p>The concept of sustainable development was described by the 1987 Bruntland Commission Report as "development that meets the needs of the present without compromising the ability of future generations to meet their own needs."</p>
                <p>Sustainability can be defined as the practice of maintaining world processes of productivity indefinitely—natural or human-made—by replacing resources used with resources of equal or greater value without degrading or endangering natural biotic systems. Sustainable development ties together concern for the carrying capacity of natural systems with the social, political, and economic challenges faced by humanity.</p>

                <h3>Current Challenges</h3>
                <p>We face a number of challenges in achieving sustainable development. These include:</p>
                <ul>
                    <li><strong>Climate Change:</strong> Rising global temperatures are causing sea levels to rise and weather patterns to become more extreme.</li>
                    <li><strong>Water Scarcity:</strong> Billions of people lack access to clean drinking water.</li>
                    <li><strong>Hunger and Poverty:</strong> Despite global wealth, millions still live in extreme poverty.</li>
                    <li><strong>Loss of Biodiversity:</strong> Species are going extinct at an alarming rate due to habitat loss and pollution.</li>
                </ul>
            """
        },
        {
            "id": "sdg_overview",
            "title": "The SD Goals",
            "short_desc": "The 17 global goals designed to be a blueprint to achieve a better and more sustainable future for all.",
            "icon": "bullseye",
            "color": "#2196F3",
            "image": "https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?w=800&q=80",
            "full_content": """
                <h2>The 2030 Agenda</h2>
                <p>The Sustainable Development Goals (SDGs), also known as the Global Goals, were adopted by the United Nations in 2015 as a universal call to action to end poverty, protect the planet, and ensure that by 2030 all people enjoy peace and prosperity.</p>
                
                <h3>A Shared Blueprint</h3>
                <p>The 17 SDGs are integrated—they recognize that action in one area will affect outcomes in others, and that development must balance social, economic and environmental sustainability.</p>
                <p>Countries have committed to prioritize progress for those who're furthest behind. The SDGs are designed to end poverty, hunger, AIDS, and discrimination against women and girls.</p>
                
                <h3 style="margin-top: 2.5rem; color: #2196F3;">Sustainable Development Goals</h3>
                <p>Click on each goal to learn more about our global mission:</p>

                <div class="sdg-dropdowns">
                    <details>
                        <summary>Goal 1: No Poverty</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=400&q=80" alt="No Poverty" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>End poverty in all its forms everywhere. This involves targeting the most vulnerable, increasing basic resources and services, and supporting communities affected by economic and environmental shocks.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 2: Zero Hunger</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1488459716781-31db52582fe9?w=400&q=80" alt="Zero Hunger" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>End hunger, achieve food security and improved nutrition and promote sustainable agriculture. We aim to ensure all people have access to safe, nutritious and sufficient food all year round.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 3: Good Health and Well-being</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=400&q=80" alt="Good Health" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Ensure healthy lives and promote well-being for all at all ages. Key targets include reducing maternal mortality, ending preventable deaths of newborns and children, and combating communicable diseases.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 4: Quality Education</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=400&q=80" alt="Quality Education" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Ensure inclusive and equitable quality education and promote lifelong learning opportunities for all. This goal ensures that all girls and boys complete free, equitable and quality primary and secondary education.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 5: Gender Equality</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?w=400&q=80" alt="Gender Equality" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Achieve gender equality and empower all women and girls. This involves ending all forms of discrimination and violence against women and girls and ensuring equal opportunities in leadership and decision-making.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 6: Clean Water and Sanitation</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=400&q=80" alt="Clean Water" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Ensure availability and sustainable management of water and sanitation for all. We work towards universal and equitable access to safe and affordable drinking water and adequate sanitation.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 7: Affordable and Clean Energy</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1466611653911-95282fc3656b?w=400&q=80" alt="Clean Energy" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Ensure access to affordable, reliable, sustainable and modern energy for all. This includes increasing substantially the share of renewable energy in the global energy mix.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 8: Decent Work and Economic Growth</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=400&q=80" alt="Decent Work" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Promote sustained, inclusive and sustainable economic growth, full and productive employment and decent work for all. This goal focuses on creating higher levels of economic productivity through diversification and innovation.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 9: Industry, Innovation and Infrastructure</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1485083269755-a7b559a4fe5e?w=400&q=80" alt="Industry and Innovation" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Build resilient infrastructure, promote inclusive and sustainable industrialization and foster innovation. Developing quality, reliable, sustainable and resilient infrastructure is key to supporting economic development.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 10: Reduced Inequality</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1531206715517-5c0ba140b2b8?w=400&q=80" alt="Reduced Inequality" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Reduce inequality within and among countries. This requires improving the regulation and monitoring of global financial markets and institutions and encouraging development assistance.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 11: Sustainable Cities and Communities</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.pexels.com/photos/169647/pexels-photo-169647.jpeg?auto=compress&cs=tinysrgb&w=400" alt="Sustainable Cities" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Make cities and human settlements inclusive, safe, resilient and sustainable. We focus on ensuring access for all to adequate, safe and affordable housing and basic services and upgrading slums.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 12: Responsible Consumption and Production</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1542601906990-b4d3fb7d5b73?w=400&q=80" alt="Responsible Consumption" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Ensure sustainable consumption and production patterns. This involves reducing our ecological footprint by changing the way we produce and consume goods and resources.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 13: Climate Action</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400&q=80" alt="Climate Action" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Take urgent action to combat climate change and its impacts. This goal focuses on strengthening resilience and adaptive capacity to climate-related hazards and natural disasters in all countries.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 14: Life Below Water</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1582967788606-a171c1080cb0?w=400&q=80" alt="Life Below Water" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Conserve and sustainably use the oceans, seas and marine resources for sustainable development. This includes preventing and significantly reducing marine pollution of all kinds.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 15: Life on Land</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=400&q=80" alt="Life on Land" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Protect, restore and promote sustainable use of terrestrial ecosystems, sustainably manage forests, and halt and reverse land degradation and biodiversity loss.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 16: Peace, Justice and Strong Institutions</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1447069387593-a5de0862481e?w=400&q=80" alt="Peace and Justice" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Promote peaceful and inclusive societies for sustainable development, provide access to justice for all and build effective, accountable and inclusive institutions.</p>
                        </div>
                    </details>
                    <details>
                        <summary>Goal 17: Partnerships for the Goals</summary>
                        <div class="sdg-dropdown-content">
                            <img src="https://images.unsplash.com/photo-1521791136064-7986c2959663?w=400&q=80" alt="Partnerships" class="sdg-mini-img" referrerPolicy="no-referrer" />
                            <p>Strengthen the means of implementation and revitalize the Global Partnership for Sustainable Development. Successful development requires partnerships between governments, the private sector and civil society.</p>
                        </div>
                    </details>
                </div>
                
                <h3>Key Principles</h3>
                <ul>
                    <li><strong>Universality:</strong> The goals apply to all countries, rich and poor.</li>
                    <li><strong>Integration:</strong> The goals are interconnected. We cannot achieve one without achieving the others.</li>
                    <li><strong>Transformation:</strong> Achieving the goals requires a fundamental change in how we live, work, and do business.</li>
                </ul>

                <h3>Monitoring Progress</h3>
                <p>The creativity, knowhow, technology and financial resources from all of society is necessary to achieve the SDGs in every context. The UN monitors progress through a set of global indicators, and countries produce Voluntary National Reviews to share their experiences.</p>
            """
        },
        {
            "id": "climate_action",
            "title": "Climate Action",
            "short_desc": "Urgent measures to combat climate change and its impacts.",
            "icon": "temperature-high",
            "color": "#FF5722",
            "image": "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&q=80",
            "full_content": """
                <h2>The Climate Crisis</h2>
                <p>Climate change is the defining crisis of our time and it is happening even more quickly than we feared. But we are far from powerless in the face of this global threat. As Secretary-General António Guterres pointed out in September 2019, "the climate emergency is a race we are losing, but it is a race we can win".</p>
                
                <h3>Causes of Climate Change</h3>
                <p>Fossil fuels – coal, oil and gas – are by far the largest contributor to global climate change, accounting for over 75 per cent of global greenhouse gas emissions and nearly 90 per cent of all carbon dioxide emissions.</p>
                <p>As greenhouse gas emissions blanket the Earth, they trap the sun's heat. This leads to global warming and climate change. The world is now warming faster than at any point in recorded history.</p>
                
                <h3>Impacts</h3>
                <ul>
                    <li><strong>Hotter Temperatures:</strong> As greenhouse gas concentrations rise, so does the global surface temperature.</li>
                    <li><strong>More Severe Storms:</strong> Destructive storms have become more intense and more frequent in many regions.</li>
                    <li><strong>Increased Drought:</strong> Climate change is changing water availability, making it scarcer in more regions.</li>
                    <li><strong>A Warming, Rising Ocean:</strong> The ocean soaks up most of the heat from global warming, threatening marine life.</li>
                    <li><strong>Loss of Species:</strong> Climate change poses risks to the survival of species on land and in the ocean.</li>
                </ul>

                <h3>What Can We Do?</h3>
                <p>Everyone can help limit climate change. From the way we travel, to the electricity we use, the food we eat, and the things we buy, we can make a difference.</p>
            """
        },
        {
            "id": "circular_economy",
            "title": "Circular Economy",
            "short_desc": "Designing out waste and pollution, keeping products and materials in use.",
            "icon": "recycle",
            "color": "#009688",
            "image": "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=800&q=80",
            "full_content": """
                <h2>Redefining Growth</h2>
                <p>The circular economy is a systems solution framework that tackles global challenges like climate change, biodiversity loss, waste, and pollution. It is based on three principles, driven by design:</p>
                <ol>
                    <li>Eliminate waste and pollution</li>
                    <li>Circulate products and materials (at their highest value)</li>
                    <li>Regenerate nature</li>
                </ol>
                
                <h3>Moving Beyond 'Take-Make-Waste'</h3>
                <p>In our current economy, we take materials from the Earth, make products from them, and eventually throw them away as waste – the process is linear. In a circular economy, by contrast, we stop waste being produced in the first place.</p>
                
                <h3>The Butterfly Diagram</h3>
                <p>The circular economy system diagram, known as the butterfly diagram, illustrates the continuous flow of technical and biological materials through the 'value circle'.</p>
                
                <h3>Benefits</h3>
                <ul>
                    <li><strong>For the Environment:</strong> Reduces greenhouse gas emissions and preserves nature.</li>
                    <li><strong>For Businesses:</strong> Reduces costs, creates new profit pools, and builds resilience.</li>
                    <li><strong>For People:</strong> Increases disposable income and improves living conditions.</li>
                </ul>
            """
        },
        {
            "id": "renewable_energy",
            "title": "Renewable Energy",
            "short_desc": "Energy from sources that are naturally replenishing.",
            "icon": "solar-panel",
            "color": "#FFC107",
            "image": "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&q=80",
            "full_content": """
                <h2>Powering the Future</h2>
                <p>Renewable energy is energy derived from natural sources that are replenished at a higher rate than they are consumed. Sunlight and wind, for example, are such sources that are constantly being replenished. Renewable energy sources are plentiful and all around us.</p>
                
                <h3>Types of Renewable Energy</h3>
                <ul>
                    <li><strong>Solar Energy:</strong> The most abundant of all energy resources and can even be harnessed in cloudy weather.</li>
                    <li><strong>Wind Energy:</strong> Harnesses the kinetic energy of moving air by using large wind turbines located on land (onshore) or in sea or freshwater (offshore).</li>
                    <li><strong>Geothermal Energy:</strong> Utilizes the accessible thermal energy from the Earth's interior.</li>
                    <li><strong>Hydropower:</strong> Harnesses the energy of water moving from higher to lower elevations.</li>
                    <li><strong>Ocean Energy:</strong> Derives energy from technologies that use the kinetic and thermal energy of seawater - waves or currents.</li>
                    <li><strong>Bioenergy:</strong> Produced from a variety of organic materials, called biomass, such as wood, charcoal, dung and other manures for heat and power production.</li>
                </ul>
                
                <h3>Why Transition?</h3>
                <p>Fossil fuels are non-renewable resources that take hundreds of millions of years to form. Burning fossil fuels creates harmful greenhouse gas emissions. Transitioning to renewable energy is vital to addressing the climate crisis.</p>
            """
        },
        {
            "id": "biodiversity",
            "title": "Biodiversity",
            "short_desc": "The variety of life on Earth, essential for healthy ecosystems.",
            "icon": "leaf",
            "color": "#8BC34A",
            "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80",
            "full_content": """
                <h2>The Web of Life</h2>
                <p>Biodiversity is the variety of all life on Earth. Interaction between these creates the natural world we know. It includes genetic, species, and ecosystem diversity.</p>
                
                <h3>Why It Matters</h3>
                <p>Biodiversity provides functioning ecosystems that supply oxygen, clean air and water, pollination of plants, pest control, wastewater treatment and many ecosystem services.</p>
                <ul>
                    <li><strong>Food Security:</strong> Biodiversity in agriculture is crucial for adapting to climate change.</li>
                    <li><strong>Health:</strong> Many medicines are derived from natural sources.</li>
                    <li><strong>Economy:</strong> At least 40% of the world's economy and 80% of the needs of the poor are derived from biological resources.</li>
                </ul>
                
                <h3>Threats</h3>
                <p>The main drivers of biodiversity loss are:</p>
                <ol>
                    <li>Changes in land and sea use</li>
                    <li>Direct exploitation of organisms</li>
                    <li>Climate change</li>
                    <li>Pollution</li>
                    <li>Invasive alien species</li>
                </ol>
            """
        },
        {
            "id": "sustainable_cities",
            "title": "Sustainable Cities",
            "short_desc": "Urban areas designed to minimize environmental impact.",
            "icon": "city",
            "color": "#607D8B",
            "image": "https://images.pexels.com/photos/169647/pexels-photo-169647.jpeg?auto=compress&cs=tinysrgb&w=800",
            "full_content": """
                <h2>Urbanizing World</h2>
                <p>More than half the world's population lives in cities. By 2050, it is projected that two-thirds of all humanity—6.5 billion people—will be urban. Sustainable development cannot be achieved without significantly transforming the way we build and manage our urban spaces.</p>
                
                <h3>Key Elements</h3>
                <ul>
                    <li><strong>Green Buildings:</strong> Structures designed to be energy efficient and water conserving.</li>
                    <li><strong>Public Transportation:</strong> Efficient, affordable and accessible public transit systems to reduce car reliance.</li>
                    <li><strong>Waste Management:</strong> Comprehensive recycling and composting programs.</li>
                    <li><strong>Green Spaces:</strong> Parks and gardens to improve air quality and mental health.</li>
                    <li><strong>Renewable Energy Integration:</strong> Solar panels on rooftops and other localized energy generation.</li>
                </ul>
                
                <h3>The Goal</h3>
                <p>Making cities sustainable means creating career and business opportunities, safe and affordable housing, and building resilient societies and economies. It involves investment in public transport, creating green public spaces, and improving urban planning and management in participatory and inclusive ways.</p>
            """
        },
        {
            "id": "social_equity",
            "title": "Social Equity",
            "short_desc": "Fairness and justice in the distribution of resources and opportunities.",
            "icon": "users",
            "color": "#9C27B0",
            "image": "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800&q=80",
            "full_content": """
                <h2>Leaving No One Behind</h2>
                <p>Social equity is the state of affairs in which all people within a specific society or isolated group have the same status in certain respects, including civil rights, freedom of speech, property rights and equal access to certain social goods and services.</p>
                
                <h3>Intersectionality</h3>
                <p>Sustainable development requires addressing systematic barriers. Whether it's gender, race, ethnicity, or economic status, inequality hinders human potential and economic growth.</p>
                
                <h3>Dimensions of Equity</h3>
                <ul>
                    <li><strong>Procedural Equity:</strong> Fairness in the decision-making process.</li>
                    <li><strong>Distributional Equity:</strong> Fairness in the distribution of benefits and burdens.</li>
                    <li><strong>Structural Equity:</strong> Addressing the underlying causes of inequality.</li>
                </ul>
                
                <h3>Global Action</h3>
                <p>Goal 10 of the SDGs aims to reduce inequality within and among countries. This includes empowering and promoting the social, economic and political inclusion of all, irrespective of age, sex, disability, race, ethnicity, origin, religion or economic or other status.</p>
            """
        }
    ]
}
